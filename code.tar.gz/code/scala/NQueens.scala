object NQueens extends App {
  def inCheck(q0: (Int, Int), q1: (Int, Int)) = {
    q0._1 == q1._1 ||
    q0._2 == q1._2 ||
    (q0._1 - q1._1).abs == (q0._2 - q1._2).abs
  }


  def isSafe(q: (Int, Int), qs: List[(Int, Int)]) = {
    qs forall (q0 => !inCheck(q0, q))
  }

  
  def solveNQueens(n: Int): List[List[(Int, Int)]] = {
    def placeQueens(k: Int): List[List[(Int, Int)]] = {
      if (k == 0) List(List())
      else 
        for {
          queens <- placeQueens(k - 1)
          column <- 1 to n
          queen = (k, column)
          if (isSafe(queen, queens))
        } yield queen :: queens
    }

    placeQueens(n)
  }

  println(solveNQueens(8))
}

