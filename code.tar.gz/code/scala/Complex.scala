
class Complex[T](val re: T, val im: T)(implicit num: Numeric[T]) {
  import num._

  def this(im: T)(implicit num: Numeric[T])= this(num.zero, im)

  /*def + [U <% T](that: Complex[U]): Complex[T] = 
    new Complex(this. re + that.re, this.im + that.im)*/

  def + (that: Complex[T]): Complex[T] = 
    new Complex(this. re + that.re, this.im + that.im)

  def - [U <% T](that: Complex[U]): Complex[T] = 
    new Complex(this. re - that.re, this.im - that.im)

  def * [U <% T](that: Complex[U]): Complex[T] = 
    new Complex(
      this.re * that.re - this.im * that.im,
      this.im * that.re + this.re * that.im
    )

  def conj = new Complex(re, -im)

  def abs = math.sqrt(toDouble(re * re + im * im))

  def arg = math.atan2(toDouble(im), toDouble(re))

  override def toString = 
    re.toString + 
    (if(im > zero) " + " else if(im < zero) " - " else "") + 
    (if(im != zero) num.abs(im).toString +"i" else "")
}

object Complex {
  import scala.language.implicitConversions

  def sqrt(x: Double): Complex[Double] = {
    if (x >= 0) new Complex(math.sqrt(x), 0)
    else new Complex(0, math.sqrt(-x))
  }

  val i = new Complex(0, 1)

  implicit def intToComplex(x: Int) = {
    new Complex(x, 0)
  }

  implicit def doubleToComplex(x: Double): Complex[Double] = {
    new Complex(x, 0)
  }

  implicit def convertComplex[U <% T, T](x: Complex[U])
  (implicit num: Numeric[T]) = 
    new Complex[T](x.re, x.im)

  implicit def intComplexToDoubleComplex(x: Complex[Int]) = 
    convertComplex[Int, Double](x)


  def main(args: Array[String]): Unit = {
    val x = new Complex(1,-3.0)
    val y = new Complex(1,1)
    println(y + x)
    println(convertComplex[Int, Double](y) + x )
    println(x - y)
    println(x * y)
  }
}
