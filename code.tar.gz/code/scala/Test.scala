import scala.collection.mutable

object Test {
  def countWords(s :String): mutable.Map[String, Int] = {
    s.split("[ !,.]+\\s*")
      .foldLeft(mutable.Map.empty[String,Int]) { (map, word) =>
        val lower = word.toLowerCase
        if (map.contains(lower)) map(lower) += 1
        else map(lower) = 1
        map
      }
  }

  def main(args:Array[String]) {
    println(countWords("See Spot run! Run, Spot. Run!"))
  }

}

class Point(val x:Double, val y:Double) {
  override def toString() = "(" + x + ", " + y + ")"
}
