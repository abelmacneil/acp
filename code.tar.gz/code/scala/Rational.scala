class Rational[+T](n: T, d: T)
(implicit integral: Integral[T]) extends Ordered[Rational[T]] {
  import integral._

  require(d != 0)

  private val g = gcd(n.abs, d.abs)
  val numer: T = n / g
  val denom: T = d / g

  def this(n: T)(implicit int: Integral[T]) = this(n, int.fromInt(1))

  def + (that: Rational[T]): Rational[T] =
    new Rational[T](
      numer * that.denom + that.numer * denom,
      denom * that.denom
    )

  def + (i: T): Rational[T] = 
    new Rational[T](numer + i * denom, denom)

  def - (that: Rational[T]): Rational[T] =
    new Rational[T](
      numer * that.denom - that.numer * denom,
      denom * that.denom
    )

  def - (i: T): Rational[T] =
    new Rational[T](numer - i * denom, denom)

  def * (that: Rational[T]): Rational[T] =
    new Rational[T](numer * that.numer, denom * that.denom)

  def * (i: T): Rational[T] =
    new Rational[T](numer * i, denom)

  def / (that: Rational[T]): Rational[T] = 
    new Rational[T](numer * that.denom, denom * that.numer)

  def / (i: T): Rational[T] =
    new Rational[T](numer, denom * i)

  def compare(that: Rational[T]): Int =
    (numer * that.denom - that.numer * denom).toInt

  def max(that: Rational[T]): Rational[T] = 
    if (this < that) that else this

  override def toString: String = numer.toString +"/"+ denom.toString

  private def gcd(a: T, b: T): T = 
    if (b == 0) a else gcd(b, a % b)
}

object Rational {
  import scala.language.implicitConversions
  implicit def integralToRational[T](x: T)
  (implicit int: Integral[T]): Rational[T] = 
    new Rational[T](x, int.fromInt(1))

  implicit def intToRational(x: Int): Rational[Int] = 
    new Rational(x, 1)

  def main(args: Array[String]): Unit = {
    val x = new Rational(1,2)
    println(integralToRational(1) + x)
    println(1 + x)
  }
}
