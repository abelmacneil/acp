object Euler22 extends App {

  val sum = 
    scala.io.Source.fromFile("names.txt").mkString
    .drop(1).dropRight(3).split("\",\"").sorted
    .zipWithIndex.foldLeft(0) { (sum, pair) => 
      sum + (pair._2 + 1) * pair._1.foldLeft(0)(_ + _ - 'A' + 1)
    }

  println(sum)
}
