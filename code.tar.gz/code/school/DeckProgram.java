import java.io.*;


public class DeckProgram{

	public static void main(String args []){
		Deck d = new Deck();
		d.shuffle();
		System.out.println();
		d.print(System.out);
	}
}

class Card {
	String suit;
    String val;
	Card next;
	public Card (String suit, String val){
		this.suit = suit;
		this.val = val;
		this.next = null;
	}
	public void print(){
		print(System.out);
	}
	public void print(PrintStream p){
		p.println(suit + ":" + val);
	}
	public String toString(){
		return suit + ":" + val;
	}
}

class Deck {
	public static final String [] SUITS = "C D H S".split("\\s+");
	public static final String [] VALS = "2 3 4 5 6 7 8 9 10 J Q K A".split("\\s+");
	private static final int MAX_DEPTH = 1;
	private	Card curCard;
	private	Card head;
	
	public Deck (){
		head = null;
		curCard = null;
		for (int i = 0; i < Deck.SUITS.length; i++)
			for (int j = 0 ;j < Deck.VALS.length; j++)
				this.add(new Card(Deck.SUITS[i],Deck.VALS[j]));
	}
	
	public void print (PrintStream p){
		Card temp = curCard;
		int i = 0;
		while (temp != null){
		    p.println(i + " => "+ temp);
			temp = temp.next;
			i++;
		}
	}

	public void add(Card card){
		card.next = curCard;
		curCard = card;
	}
	public Card deal(){
		Card c = curCard;
		curCard = curCard.next;
		return c;
	}

	public void shuffle(){
		shuffle(0);
	}
	private void shuffle(int recDepth){
		System.out.println("-----------------");
		int depth1 = (int) (Math.random() * 45) + 1,
			depth2 = (int) (Math.random() * (depth1 - 1)),
			i = 0;
		System.out.println(depth1 + ":" + depth2);
		Card temp = curCard;
		Card first = null, 
			preFirst = null,
			second = null,
			preSecond = null;
		while ( i <= depth1){
		   	temp = temp.next;
			System.out.println(i + ":" +temp);
			if (i == depth2){
				first = temp;
			}else if (i == depth2 - 1){
				preFirst = temp;
			}else if (i == depth1){
				second = temp;
			}else if (i == depth1 - 1)
				preSecond = temp;
			i++;
		}
	
		/*System.out.println("First " + first +" : "+ first.next);
		  System.out.println("Second " + second +" : "+ second.next);*/
		System.out.println(second == null);
		if( preFirst != null)
			preFirst.next = second;
		if(preSecond != null)
			preSecond.next = first;

		temp = second.next;
		second.next = first.next;
		first.next = temp;
		Card temp2 = first;
		first = second;
		second = temp2;
		/*System.out.println("First " + first +" : "+ first.next);
		System.out.println( "Second " + second +" : "+ second.next);
		System.out.println("--------------");*/

		if (recDepth < MAX_DEPTH)
			shuffle(recDepth + 1);
	}

}
