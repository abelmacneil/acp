import hsa_new.*;
import java.awt.*;
class Fib{
	static Console c = new Console();
	static void arrayCopy(int [] one ,int[] two){
		for(int i = 0; i < one.length; i++){
			one[i] = two[i];
		}
	}
	static void printTriFib(int n){
		 int maxlen = 4;
		int [] row = new int[n + 1];
		c.print(" 0|");
		
		c.println(1);
		c.print(" 1|");
		
		c.println("1   1");
		row[0] = 1;
		row[1] = 2;
		row[2] = 1;
		c.print(" 2|");
		
		c.print(1);
		for (int j = 1; j < 3; j++)
			c.print(row[j], maxlen);
			
		
		c.println();
		int[] currow = new int[n + 1];
		for (int i = 2; i < n; i++){
			c.print(i + 1, 2);
			c.print("|");
			int j;
			
			c.print(1);
			currow[0] = 1;
			for(j = 0; j < i ; j++){
				currow[j + 1] = row[j] + row[j + 1];
				c.print(currow[j + 1],maxlen);
			}
			currow[j + 1] = 1;
			c.println("  " + currow[j + 1]);
			arrayCopy(row, currow);
		}
	}
	public static void main(String [] args){
		printTriFib(10);
	}

}
