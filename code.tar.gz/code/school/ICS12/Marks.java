// The "Marks" class.
import java.awt.*;
import hsa.Console;

public class Marks
{
    static Console c;           // The output console

    public static void main (String[] args)
    {
	c = new Console ();

	double marks[] [];
	double studAvg[];
	double studSum = 0;
	double sum = 0;
	/*c.print("Enter the nubmer of students");*/
	int numStudents =  /*c.readInt()*/6;
	marks = new double [numStudents] [4];
	studAvg = new double [numStudents];
	for (int i = 0 ; i < numStudents ; i++)
	{
	    for (int j = 0 ; j < 4 ; j++)
	    {
		marks [i] [j] = c.readDouble ();
		studSum += marks [i] [j];
	    }
	    studAvg [i] = studSum / 4;
	    sum += studAvg [i];
	}
	for (int i = 0 ; i < numStudents ; i++)
	{
	    c.print ("Student " + (i + 1) + " marks: ");
	    for (int j = 0 ; j < 4 ; j++)
	    {
		c.print (marks [i] [j] + ", ");
	    }
	    c.print ("Average: " + studAvg [i]);
	}
	c.println ("Class Average: " + (sum / numStudents));


    } // main method
} // Marks class
