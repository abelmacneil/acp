#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Abel_2
#
# Created:     11/02/2013
# Copyright:   (c) Abel_2 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

class Graph(object):
    vertices = []
    adj = []
    def __init__(self, maximum):
        self.max = maximum
        self.vertices = []
        self.adj = [[2 for i in range(self.max)] for j in range(self.max)]
        self.numVertices = 0
        self.ways = 0
    def printAdj(self):
        for y in self.adj:
            for x in y:
                print x,
            print
    def addVertex(self, vertex):
        self.vertices.append(vertex)
        self.adj[self.numVertices][self.numVertices] = 0
        #print self.numVertices, len(self.adj[0])
        for i in range(self.numVertices):
            self.adj[i][self.numVertices] = 2
            self.adj[self.numVertices][i] = 2

        self.numVertices += 1
        #self.printAdj()
    def search(self, key):
        for i in range(self.numVertices):
            if self.vertices[i] == key:
                return i
        return -1
    def addEdge(self, vertex1, vertex2):
        index1 = self.search(vertex1)
        index2 = self.search(vertex2)
        self.adj[index1][index2] = 1
        self.adj[index2][index1] = 1
    def hasEdge(self, vertex1, vertex2):
        index1 = self.search(vertex1)
        index2 = self.search(vertex2)
        return self.adj[index1][index2] == 1
    def printGraph(self, vertex):
        if vertex == self.vertices[0] and vertex != None:
            return vertex
        for i in reversed(range(self.search(vertex))):
            if not self.hasEdge(vertex ,self.vertices [i]):
                pass #print str(vertex) , "->" , str(self.printGraph(self.vertices [i])),
            else:
                self.ways += 1
    def printWays(self):
        self.printGraph(self.vertices[-1])
        print self.ways

string = ""
size = int(raw_input())
g = Graph(size)
string = raw_input()
num1 = 0
num2 = 0
while string != "0 0":
    num1 = int(string[:string.find(' ')])
    num2 = int(string[string.find(' '):])
    if num1 not in g.vertices:
        g.addVertex(num1)
    if num2 not in g.vertices:
        g.addVertex(num2)
    g.addEdge(num1,num2)
    string = raw_input()

g.printAdj()
g.printWays()

##g = Graph(4)
##g.addVertex(1)
##g.addVertex(2)
##g.addVertex(3)
##g.addVertex(4)
##g.addEdge(1,4)
##g.addEdge(1,2)
##g.addEdge(2,3)
##g.addEdge(2,4)
##g.addEdge(3,4)
##g.printAdj()
##g.printSelf()
##print g.ways
