#dictionary representing relationship between friends


#friendOf = {1:2, 2:3, 3:1, 10:11, 100:10, 11:100}
friendOf = {}
string = ""
string = raw_input()
num1 = 0
num2 = 0
while string != "0 0":
    num1 = int(string[:string.find(' ')])
    num2 = int(string[string.find(' '):])
    friendOf[num1] = num2
    string = raw_input()

print friendOf

def inCircle(friend1, friend2, depth=0):
    if (friendOf[friend1] == friend2):
        print depth,
        return True
    elif (depth > len(friendOf)):
        return False
    else:
        return inCircle(friendOf[friend1], friend2, depth + 1)

print inCircle(3,3)