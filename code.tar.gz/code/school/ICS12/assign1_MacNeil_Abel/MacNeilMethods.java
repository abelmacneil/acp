// The "MacNeilMathods" class.
import java.awt.*;
import hsa.Console;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/**
 * A MacNeil
 * Feb 11, 2013
 * This program calulates palindromic prime numbers,
 * Armstrong numbers, Lucas Numbers, whether or not
 * a number is perfect, abundant or deficient or 
 * or whether a number is a palindrome or not
 */
public class MacNeilMethods
{
    static Console c;           // The output console

    /**
    * Returns the given number reversed
    * ex reverseNum(20034) = 43002
    */
    static long reverseNum (long n)
    {
	String s = new Long (n).toString ();
	char[] arr = s.toCharArray ();
	s = "";
	for (int i = arr.length - 1 ; i > -1 ; i--)
	    s += arr [i];

	return Long.parseLong (s);
    } //end reverseNum


    /**
    * Returns whether or not the number is a palindrome
    */
    static boolean isPalindrome (long n)
    {
	return (reverseNum (n) == n);
    } //end isPalendrome


    /**
     * Returns whether or not the given number is an Armstrong Number
     */
    static boolean isArmstrong (long n)
    {
	String s = new Long (n).toString ();
	long sum = 0;
	for (int i = 0 ; i < s.length () ; i++)
	{
	    sum += Math.pow (Long.parseLong (new Character (s.charAt (i)).toString ()), s.length ());
	}
	return sum == n;
    } //end isArmstrong


    /**
     * Prints all the lucas numbers up to and including the nth element
     */
    static void printLucasNums (long n)
    {
	long x = 2, y = 1, z = 0, temp = 0;
	c.print (x + " " + y + " ");
	for (int i = 0 ; i <= n ; i++)
	{
	    z = x + y;
	    temp = x;
	    x = y;
	    y = z;
	    c.print (z, new Long (z).toString ().length () + 1);
	}
    } // end printLucasNums


    /**
     * Returns a List of factors of the given number, includes 1 and itself
     */
    static List getFactors (long n)
    {
	List factors = new ArrayList ();
	for (long i = 1 ; i <= Math.sqrt (n) ; i++)
	{
	    if (n % i == 0)
	    {
		factors.add (new Long (i));
		if (n / i != i)
		    factors.add (new Long (n / i));
	    }
	}

	return factors;
    } //end getFactors


    /**
     * Returns whether or not the given number, n, is a prime number
     */
    static boolean isPrime (long n)
    {
	for (long i = 1 ; i <= Math.sqrt (n) ; i++)
	{
	    if (n % i == 0 && i != 1 && i != n)
	    {
		return false;
	    }
	}
	return true;
    } // end isPrime


    /**
      *Returns the sum of the divisors (factors) of the given numbers
      */
    static long sumOfDivisors (long n)
    {
	long sum = 0;
	List divisors = getFactors (n);
	long val = 0;
	for (int i = 0 ; i < divisors.size () ; i++)
	{
	    val = ((Long) divisors.get (i)).longValue ();
	    if (val != n)
		sum += val;
	}
	return sum;
    } // end sumOfDivisors


    /**
     *Returns whenther or not the given number is a perfect number
     */
    static boolean isPerfect (long n)
    {
	return sumOfDivisors (n) == n;
    } // end isPerfect


    /**
     *Returns whenther or not the given number is abundant
     */
    static boolean isAbundant (long n)
    {
	return sumOfDivisors (n) > n;
    } // end isAbundant


    
	/**
	 *Returns whenther or not the given number is deficient
	 */
	static boolean isDeficient (long n)
    {
	return sumOfDivisors (n) < n;
    } // end isDeficient


    /**
     * Main method that starts the program
     */
    public static void main (String[] args)
    {
	c = new Console ();
	long min, max;
	int input;
	do
	{
	    max = min = input = 0;
	    //menu that displays options to the user
	    c.println ("Enter the question you would like to see: ");
	    c.println ("1: Palindromic Primes");
	    c.println ("2: Armstrong Numbers");
	    c.println ("3: Lucas Numbers");
	    c.println ("4: Check whether a number is perfect, abundant or deficient");
	    c.println ("5(bonus): Check whether a number is a palindrome or not");

	    input = c.readInt ();

	    switch (input)
	    {
		case 1:
		    {
			//get the range of numbers, print all the palindromic primes between them
			c.println ("Enter the min and max to find palindromic primes: ");
			min = c.readLong ();
			max = c.readLong ();
			for (long i = min ; i <= max ; i++)
			    if (isPrime (i) && isPrime (reverseNum (i)))
				c.print (i, new Long (i).toString ().length () + 1);
			break;
		    }
		case 2:
		    {
			//get the range of numbers, print all the Armstrong numbers between them
			c.println ("Enter the min and max for the Armstrong numbers: ");
			min = c.readLong ();
			max = c.readLong ();
			for (long i = min ; i <= max ; i++)
			    if (isArmstrong (i))
				c.print (i, new Long (i).toString ().length () + 1);
			break;
		    }
		case 3:
		    {
			//get a number from the user and print all the Lucas Numbers until that term in the sequence
			c.println ("Up to what term would you like to print the Lucas Numbers: ");
			max = c.readLong ();
			printLucasNums (max);
			break;
		    }
		case 4:
		    {
			//get a number from the user and determine whether or not the number is perfect, abundant or deficient
			c.println ("Enter the number you would like to find out is perfect, abundant or deficient: ");
			max = c.readLong ();
			if (isPerfect (input))
			    c.println (input + " is perfect!");
			else if (isAbundant (input))
			    c.println (input + " is abundant!");
			else if (isDeficient (input))
			    c.println (input + " is deficient!");
			break;
		    }
		case 5:
		    c.println ("Enter a number that is a palendrome: ");
		    max = c.readLong ();
		    if (isPalindrome (max))
			c.println ("The number is a palindrome.");
		    else
			c.println ("The number is not a palindrome.");
		     break;
		default:
		    //for all other input exit the program
		    c.println ("Goodbye!");
		    System.exit (0);
	    }
	    //ask the user whether or not they wnat to continue
	    c.println ("\nEnter 1 to start over, any other number to exit");
	    input = c.readInt ();
	    c.clear();
	}
	while (input == 1);
    } // main method
} // MacNeilMathods class


