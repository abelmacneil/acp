// The "ArrayExercise" class.
import java.awt.*;
import hsa.Console;

public class ArrayExercise
{
    static Console c;           // The output console

    public static void main (String[] args)
    {
	c = new Console ();

	int length = c.readInt ();
	double grades[] = new double [length];
	double sum = 0;
	double min = -1;
	double max = 101;
	for (int i = 0 ; i < length ; i++)
	{
	    grades [i] = c.readDouble ();
	    if (i == 0)
	    {
		min = grades [i];
		max = grades [i];
	    }
	    if (grades [i] > max)
		max = grades [i];
	    if (grades [i] < min)
		min = grades [i];
	    sum += grades [i];
	}
	c.println ("Average: " + (sum / length) + " Max: " + max + " Min: " + min);
    } // main method
} // ArrayExercise class


