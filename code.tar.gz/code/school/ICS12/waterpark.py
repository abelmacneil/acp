class Node(object):
    parents = []
    children = []
    isRoot = False
    tree = []
    def __init__(self,tree,tag):
        isRoot = False
        isLeaf = False
        self.tag = tag
        self.tree = tree
    def setParents(self):
        parents = []
        for n in tree:
            print "n:" + str(n.tag),
            for c in n.children:
                print "s:" + str(self.tag),
                if c.tag == self.tag and n.tag != self.tag:
                    self.parents.append(n)
            print
    def addChild(self, node):
        if self.children == node.children and len(self.children) != 0:
            print True,'k'
        self.children.append(node)
        if self.children == node.children:
            print True


tree = []

node = Node(tree, 1)
node.isRoot = True
tree.append(node)
del node
node = Node(tree,2)

tree[0].addChild(node)
for p in tree[0].children:
    print p.tag
node.setParents()
tree.append(node)

node = Node(tree,3)
tree[1].addChild(node)
node.setParents()
tree.append(node)

node = Node(tree,4)
tree[2].addChild(node)
node.setParents()
tree.append(node)

for n in reversed(tree):
    print "n:",n.tag,":",
    for p in n.parents:
        print p.tag,",",
    print
##node = Node()
##node.tag = 2
##node.parents.append(tree[0])
##node.children.append(3)
##node.children.append(4)
##tree.append(node)
##node = Node()
##node.tag = 3
##node.parents.append(2)
##node.children.append(4)
##tree.append(node)
##node = Node()
##node.tag = 4
##node.isLeaf = True
##node.parents.append(1)
##node.parents.append(2)
##node.parents.append(3)
##tree.append(node)

def findRoot(tree, node,s=""):
    ways = []
    for p in node.parents:
        if p.isRoot:
            ways.append(str(node.tag) + "->" + str(p.tag))
            return ways
        else:
            ways.append(str(node.tag) + "->" + str(p.tag) + "->" + str(findRoot(tree,p)))
    return ways

print findRoot(tree,node)

