#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      abel
#
# Created:     19/02/2013
# Copyright:   (c) abel 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def sort(arr):
    swapped = True
    while swapped:
        swapped = False
        for i in range(1,len(arr)):
            if arr[i-1] > arr[i]:
                arr[i-1], arr[i] = arr[i],arr[i-1]
                swapped = True
    return arr
def pushSwitch(lights,k,cols):
    for i in range(cols):
        if lights[k][i] == lights[k+1][i]:
            lights[k][i] = 0
        else:
            lights[k][i] = 1
    return lights

def main():

    print bool(1)
    row = 4
    col = 3
    lights = [
            [0,0,1],
            [0,1,1],
            [1,0,1],
            [0,0,1]]
    for i in pushSwitch(lights,0,col):
        print i


    for k in range(row):
        for i in range(col):
            pass

if __name__ == '__main__':
    main()
