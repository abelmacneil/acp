// The "Test" class.
import java.awt.*;
import hsa.Console;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class LoopsAssignment1
{
    static Console c;           // The output console

    static void printPowersOfTen (long n)
    {
	for (int i = 0 ; i <= n ; i++)
	{
	    c.println (Math.pow (10, i));
	}

    }


    static void printFib (long n)
    {
	long a = 0, b = 1, d = 0, temp = 0;
	c.println (a + "   " + b);
	for (long i = 0 ; i <= n ; i++)
	{
	    d = a + b;
	    temp = a;
	    a = d;
	    b = temp;
	    c.print (d, new Long (d).toString ().length () + 1);
	}
    }


    static List getFactors (long n)
    {
	List factors = new ArrayList ();
	for (int i = 1 ; i < Math.sqrt (n) + 1 ; i++)
	    if (n % i == 0)
	    {
		if (factors.indexOf (new Long (i)) == -1)
		    factors.add (new Long (i));
		if (n / i != i && factors.indexOf (new Long (n / i)) == -1)
		    factors.add (new Long (n / i));
	    }
	return factors;
    }


    static boolean isPrime (long n)
    {
	for (long i = 2 ; i < Math.sqrt (n) + 1 ; i++)
	    if (n % i == 0 && n != i)
		return false;
	return getFactors (n).size () <= 2;
    }


    static void printPrimes (long n)
    {
	for (long i = 1 ; i <= n ; i++)
	    if (isPrime (i))
		c.print (i, new Long (i).toString ().length () + 1);
    }


    static void printNum (String num, int size, char ch)
    {
	for (int i = 0 ; i < num.length () ; i++)
	{
	    for (int y = 0 ; y < size ; y++)
	    {
		c.setCursor (y + 1, size * i + i + 1);
		for (int x = 0 ; x < size ; x++)
		{
		    if (num.charAt (i) == '0')
		    {
			if (inBoundsZero (x, y, size))
			    c.print (ch);
			else
			    c.print (' ');
		    }
		    else if (num.charAt (i) == '1')
		    {
			if (inBoundsOne (x, y, size))
			    c.print (ch);
			else
			    c.print (' ');
		    }
		    else if (num.charAt (i) == '2')
		    {
			if (inBoundsTwo (x, y, size))
			    c.print (ch);
			else
			    c.print (' ');
		    }
		    else if (num.charAt (i) == '3')
		    {
			if (inBoundsThree (x, y, size))
			    c.print (ch);
			else
			    c.print (' ');
		    }
		    else if (num.charAt (i) == '4')
		    {
			if (inBoundsFour (x, y, size))
			    c.print (ch);
			else
			    c.print (' ');
		    }
		    else if (num.charAt (i) == '5')
		    {
			if (inBoundsFive (x, y, size))
			    c.print (ch);
			else
			    c.print (' ');
		    }
		    else if (num.charAt (i) == '6')
		    {
			if (inBoundsSix (x, y, size))
			    c.print (ch);
			else
			    c.print (' ');
		    }
		    else if (num.charAt (i) == '7')
		    {
			if (inBoundsSeven (x, y, size))
			    c.print (ch);
			else
			    c.print (' ');
		    }
		    else if (num.charAt (i) == '8')
		    {
			if (inBoundsEight (x, y, size))
			    c.print (ch);
			else
			    c.print (' ');
		    }
		    else if (num.charAt (i) == '9')
		    {
			if (inBoundsNine (x, y, size))
			    c.print (ch);
			else
			    c.print (' ');
		    }
		}
	    }
	}
    }


    static boolean inBoundsZero (int x, int y, int size)
    {
	return (y == 0 || y == size - 1 || x == 0 || x == size - 1);
    }


    static boolean inBoundsOne (int x, int y, int size)
    {
	return x == size - 1;
    }


    static boolean inBoundsTwo (int x, int y, int size)
    {
	return (y == 0 || y == size - 1 || x == size - y - 1);
    }


    static boolean inBoundsThree (int x, int y, int size)
    {
	return (y == 0 || y == size - 1 || y == size / 2 || x == size - 1);
    }


    static boolean inBoundsFour (int x, int y, int size)
    {
	return (y == size / 2 || (x == 0 && y < size / 2) || x == size - 1 || y == size / 2);
    }


    static boolean inBoundsFive (int x, int y, int size)
    {
	return (y == 0 || y == size / 2 || (x == 0 && y < size / 2) || (x == size - 1 && y >= size / 2) || y == size - 1);

    }


    static boolean inBoundsSix (int x, int y, int size)
    {
	return (y == 0 || y == size / 2 || x == 0 || (x == size - 1 && y >= size / 2) || y == size - 1);
    }


    static boolean inBoundsSeven (int x, int y, int size)
    {
	return (y == 0 || x == size - y - 1);
    }


    static boolean inBoundsEight (int x, int y, int size)
    {
	return (y == 0 || y == size / 2 || x == 0 || x == size - 1 || y == size - 1);
    }


    static boolean inBoundsNine (int x, int y, int size)
    {
	return (y == 0 || y == size / 2 || (x == 0 && y < size / 2) || x == size - 1 || y == size - 1);
    }


    public static void main (String[] args)
    {
	c = new Console (20, 125);
	char choice = ' ';
	long size = 0;
	do
	{
	    c.println ("Please Enter the choice you want: (1,2,3,4,5) (Any thing else to exit) ");
	    choice = c.readChar ();
	    size = 0;
	    if (choice == '1')
	    {
		c.println ("Print the powers 10 up what exponent? ");
		size = c.readInt ();
		printPowersOfTen (size);
	    }

	    else if (choice == '2')
	    {
		c.print ("Enter the number you want printed: ");
		String input = c.readString ();
		c.print ("Enter the size of the numbers: ");
		size = c.readInt ();
		while (size <= 5)
		{
		    c.println ("Size must be greater than 5");
		    size = c.readInt ();
		}
		c.print ("Enter the character you want printed: ");
		choice = c.getChar ();
		c.clear ();
		printNum (input, (int) size, choice);
	    }
	    else if (choice == '3')
	    {
		c.print ("Up to what term of the Fibanacci sequence would you like to display: ");
		size = c.readInt ();
		printFib (size);
	    }
	    else if (choice == '4')
	    {
		c.print ("What number do you want to be factored: ");
		size = c.readInt ();
		List l = getFactors (size);
		Collections.sort (l);
		c.println (l.toString ());
	    }
	    else if (choice == '5')
	    {
		c.println ("Up to what number would you like to display prime numbers: ");
		size = c.readInt ();
		printPrimes (size);
	    }
	    else
		System.exit (0);
	    c.println ("\nDo you want to start again? (y/n) ");
	    choice = c.getChar ();
	    c.clear ();
	}
	while (choice == 'y' || choice == 'Y');
    } // main method
} // Test class


