// The "MacNeilArrays" class.
import java.awt.*;
import hsa.Console;

public class MacNeilArrays
{
    static Console c;           // The output console
    
    public static void main (String[] args)
    {
	c = new Console ();
	
	// Place your program here.  'c' is the output console
    } // main method
} // MacNeilArrays class
