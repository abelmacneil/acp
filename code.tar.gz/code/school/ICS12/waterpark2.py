class Node(object):
    isRoot = False
    tree = []
    parent = []
    child =[]
    def __init__(self,tree,tag):
        isRoot = False
        isLeaf = False
        self.tag = tag
        self.tree = tree

    def addChild(self,node):
        self.child = node
    def addParent(self, node):
        self.parent = node

tree = []
def addNode(tree,node,child,isRoot=False):
    if isRoot:
        node.isRoot = True
    else:
        tree[-1].addChild(node)
        node.addParent(tree[-1])
    if child != 0:
        node.addChild(child)
        child.addParent(node)
    tree.append(node)
addNode(tree,Node(tree,1),Node(tree,2),True)



def getTree(tree, node):
    if node.parent.isRoot:
        return str(node.tag) + "->" + str(node.parent.tag)
    else:
        return str(node.tag) + "->"+str(getTree(tree,node.parent))

print getTree(tree,tree[-1])
##node = Node(tree, 1)
##node.isRoot = True
##tree.append(node)
##
##node = Node(tree,2)
##tree[0].child = node
##node.parent = tree[0]
##tree.append(node)
##
##node = Node(tree,3)
##tree[1].child = node
##node.parent = tree[1]
##tree.append(node)
##
##node = Node(tree,4)
##tree[2].child = node
##node.parent = tree[2]
##tree.append(node)



##node = Node()
##node.tag = 2
##node.parents.append(tree[0])
##node.children.append(3)
##node.children.append(4)
##tree.append(node)
##node = Node()
##node.tag = 3
##node.parents.append(2)
##node.children.append(4)
##tree.append(node)
##node = Node()
##node.tag = 4
##node.isLeaf = True
##node.parents.append(1)
##node.parents.append(2)
##node.parents.append(3)
##tree.append(node)

##def findRoot(tree, node,s=""):
##    ways = []
##    for p in node.parents:
##        if p.isRoot:
##            ways.append(str(node.tag) + "->" + str(p.tag))
##            return ways
##        else:
##            ways.append(str(node.tag) + "->" + str(p.tag) + "->" + str(findRoot(tree,p)))
##    return ways
##
##print findRoot(tree,node)

