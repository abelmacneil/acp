import java.io.*;
import java.util.*;

public class Search {
	private String [] titles;
	private	Integer [] refs;

	public Search(){
		BufferedReader in = null;
		List<String> titleList = null;
    	List<Integer> refList = null;
		try {
		    in = new BufferedReader(new FileReader("data.txt"));
			titleList = new ArrayList<String>();
			refList = new ArrayList<Integer>();
			String line = in.readLine();
			while (line != null){
				refList.add(Integer.parseInt(line));
				line = in.readLine();
				titleList.add(line.trim());
				line = in.readLine();
			}
			in.close();
		} catch (Exception x){
			System.err.println("An error occured...");
		}
	
		titles = titleList.toArray(new String[titleList.size()]);
		refs = refList.toArray(new Integer [refList.size()]);
		
	}
	
	public String getTitle(int refNum){
		int index = binSearch(refs, refNum, 0 , refs.length, 0);
		if (index == -1)
			return "Not Found";
		else
			return titles[index];
	}
	public int getRefNum(String title){
		int index = binSearch(titles, title, 0 , titles.length, 0);
		if (index == -1)
			return -1;
		else
			return refs[index];
	}

	public static  <T extends Comparable<T>> int binSearch(T[] arr, T key, int begin, int end, int depth){
		int mid = (begin + end) / 2;
		int cmp = arr[mid].compareTo(key);
		if (depth > Math.log(arr.length) / Math.log(2))
			return -1;
		if (cmp == 0)
			return (begin + end) / 2;
		else if (cmp < 0)
			return binSearch(arr,key,mid, end, depth + 1);
		else if (cmp > 0)
			return binSearch(arr, key, begin, mid, depth + 1);
		else 
			return -1;
	}
	public void printAll(PrintStream p){
		for (int i = 0; i < titles.length; i++)
			p.printf("%3d:%s\n" ,refs[i], titles[i]);
	}
	public static void main(String args[]) {
		Search s = new Search();
		if (args.length == 0)
			s.printAll(System.out);
		else{
			try{
				System.out.println(s.getTitle(Integer.parseInt(args[0])));
			}catch (NumberFormatException x){
				System.out.println(s.getRefNum(args[0]));
			}
			
		}
	}
}
