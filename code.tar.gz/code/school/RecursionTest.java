class RecursionTest {
	static void print(Object o){
		System.out.println(o.toString());
	}
	static void printTri(int n){
		if (n == 0){
			return;
		}
		printLine(n - 1);
	}
	static void printLine(int n){
		if (n == 1){
			System.out.println('*');
		}
		else{
			printTri(n - 1);
			System.out.print('*');
		}
	}
	static int sumDigits(int n){
		if (n % 10 == n)
			return n;
		return n % 10 + sumDigits(n / 10);
	}
	static void printReverse(int n, int base){
		if (n % base == n){
			if (n % base >= 10)
				System.out.print((char) (55 + n));
			else 
				System.out.print(n);
			return;
		}
		if (n % base >= 10)
				System.out.print((char) (55 + n % base));
		else 
			System.out.print(n % base);
		printReverse(n/base, base);
	}
	static double horner(double a[], double x, int i){
		if (i == a.length - 1)
			return a[i];
		return a[i] + x * horner(a,x, i + 1);
	}
	public static void main(String [] args){
		double a[] = {1,2,3,4,5,};
		System.out.println(horner(a,0,0));
	}
}
