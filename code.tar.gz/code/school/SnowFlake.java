import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class SnowFlake extends JApplet

{ //Instantiate variables
    int level = 0;
    int x1 = 20, y1 = 280;
    int x2 = 160, y2 = 20;
    int x3 = 300, y3 = 280;

    public void init ()
    {
	String levelStr = JOptionPane.showInputDialog ("Enter the depth of recursion: ");
	level = Integer.parseInt (levelStr); //Sets the level of recursion, input by user
    }


    public void paint (Graphics g)
    {
	setBackground (Color.lightGray); //Colors background light gray
	g.setColor (Color.red); //Colors the lines blue

	//Order of points - important to be correct so snowflake doesn't grow inward
	drawFlake (level, x1, y1, x3, y3, g); //Draws bottom portion of flake
	drawFlake (level, x2, y2, x1, y1, g); //Draws left side of flake
	drawFlake (level, x3, y3, x2, y2, g); //Draws right side of the flake
    }


    // Draws the flake recursively. The base case is order 1 for which a simple straight line is drawn.
    // Otherwise three intermediate points are computed, and each line segment is drawn.
    public void drawFlake (int order, double x1, double y1, double x5, double y5, Graphics g)
    {
	double deltaX, deltaY, x2, y2, x3, y3, x4, y4;

	if (order == 1)
	    g.drawLine ((int) x1, (int) y1, (int) x5, (int) y5);

	else
	{
	    deltaX = x5 - x1;
	    deltaY = y5 - y1;

	    x2 = x1 + deltaX / 3;
	    y2 = y1 + deltaY / 3;

	    x3 = ((x1 + x5) / 2 + (Math.sqrt (3.0) / 6) * (y1 - y5));
	    y3 = ((y1 + y5) / 2 + (Math.sqrt (3.0) / 6) * (x5 - x1));

	    x4 = x1 + deltaX * 2 / 3;
	    y4 = y1 + deltaY * 2 / 3;

	    drawFlake (order - 1, x1, y1, x2, y2, g);
	    drawFlake (order - 1, x2, y2, x3, y3, g);
	    drawFlake (order - 1, x3, y3, x4, y4, g);
	    drawFlake (order - 1, x4, y4, x5, y5, g);
	} //end else
    }
}
