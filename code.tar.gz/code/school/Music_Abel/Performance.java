import hsa_new.*;
/**
 * Performance class.
 */
public class Performance
{
    private String arrangement;
    private Instrument solo;
    private Instrument duet_1, duet_2;
    private Instrument trio_1, trio_2, trio_3;
    private Instrument quartet_1, quartet_2, quartet_3, quartet_4;
    private Instrument quintet_1, quintet_2, quintet_3, quintet_4, quintet_5;
    private Console c;


    /**
     * constructor
     * pre: none
     * post: A soloist has been selected.
     */
    public Performance (Instrument s, Console c)
    {
	this.c = c;
	solo = s;
	arrangement = solo.makeSound ();
    }


    /**
     * constructor
     * pre: none
     * post: The members of a duet have been selected.
     */
    public Performance (Instrument d1, Instrument d2, Console c)
    {
	this.c = c;
	duet_1 = d1;
	duet_2 = d2;
	arrangement = duet_1.makeSound () + " " + duet_2.makeSound ();
    }


    /**
     * constructor
     * pre: none
     * post: The members of a trio have been selected.
     */
    public Performance (Instrument t1, Instrument t2, Instrument t3, Console c)
    {
	this.c = c;
	trio_1 = t1;
	trio_2 = t2;
	trio_3 = t3;
	arrangement = trio_1.makeSound () + " " + trio_2.makeSound () + " " + trio_3.makeSound ();
    }


    /**
    *constructor
    *pre:none
    *post:Themembers of a trio have been selected.
    */
    public Performance (Instrument t1, Instrument t2, Instrument t3, Instrument t4, Console c)
    {
	this.c = c;
	quartet_1 = t1;
	quartet_2 = t2;
	quartet_3 = t3;
	quartet_4 = t4;
	arrangement = quartet_1.makeSound () + " " + quartet_2.makeSound () + " " + quartet_3.makeSound () + " " + quartet_4.makeSound ();
    }


    /**
    *constructor
    *pre:none
    *post:Themembers of a trio have been selected.
    */
    public Performance (Instrument t1, Instrument t2, Instrument t3, Instrument t4, Instrument t5, Console c)
    {
	this.c = c;
	quintet_1 = t1;
	quintet_2 = t2;
	quintet_3 = t3;
	quintet_4 = t4;
	quintet_5 = t5;
	arrangement = quintet_1.makeSound () + " " + quintet_2.makeSound () + " " + quintet_3.makeSound () + " " + quintet_4.makeSound () + " " + quintet_5.makeSound ();
    }


    /**
     * Begins the performance.
     * pre: none
     * post: The performance has been played.
     */
    public void begin ()
    {
	c.println (arrangement);
    }


    /**
     * Returns a String that represents the performers.
     * pre: none
     * post: A string representing the performers has
     * been returned.
     */
    public String toString ()
    {
	String program = "The performance includes ";
	program += arrangement;
	return (program);
    }
}
