/**
 * Clarinet class.
 */
public class Cymbal extends Percussion
{

    /**
     * constructor
     * pre: none
     * post: An clarinet has been created.
     */
    public Cymbal (String cymbalist)
    {
	super (cymbalist);
    }


    /**
     * Returns the sound of the instrument.
     * pre: none
     * post: The sound made by the instrument is returned.
     */
    public String makeSound ()
    {
	return ("Clang Clang");
    }


    /**
     * Returns a String that represents the instrument.
     * pre: none
     * post: A string representing the instrument has
     * been returned.
     */
    public String toString ()
    {
	return (super.getMusician () + " plays " + makeSound () + ".");
    }
}
