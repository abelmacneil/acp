/*
 * Music.java
 * A program that demonstrates polymorphism.
 */
import java.awt.*;
import hsa_new.Console;

/**
 * A musical performance.
 */
public class Music
{
    static Console c;


    /**
     * Returns a selected instrument.
     * pre: none
     * post: An instrument object has been returned.
     */
    public static Instrument assignInstrument ()
    {
		String instrumentChoice, name;


		c.println ("Select an instrument for the band member. ");
		c.print ("Vocals, Piccolo, Clarinet, Drums or Cymbal (v, p, cl, d, c): ");
		instrumentChoice = c.readLine ();
		c.print ("Enter the band member's name: ");
		name = c.readLine ();
		if (instrumentChoice.equalsIgnoreCase ("V"))
		{
			return (new Vocal (name));
		}
		else if (instrumentChoice.equalsIgnoreCase ("P"))
		{
			return (new Piccolo (name));
		}
		else if (instrumentChoice.equalsIgnoreCase ("CL"))
		{
			return (new Clarinet (name));
		}
		else if (instrumentChoice.equalsIgnoreCase ("D"))
		{
			return (new Drum (name));
		}
		else //Default to Cymbal
		{
			return (new Cymbal (name));
		}

    }


    public static void main (String[] args)
    {
	c = new Console ();
	Performance band;
	Instrument bandMember1, bandMember2, bandMember3, bandMember4, bandMember5;

	String performanceChoice;

	/* assign instruments */
	bandMember1 = assignInstrument ();
	bandMember2 = assignInstrument ();
	bandMember3 = assignInstrument ();
	bandMember4 = assignInstrument ();
	bandMember5 = assignInstrument ();
	c.println (bandMember1 + " " + bandMember2 + " " + bandMember3 + " " + bandMember4 + " " + bandMember5 + "\n");

	c.print ("Would you like to hear a Solo, a Duet, a Trio, a Quartet, a Quintet or Leave? (s, d, t, qa,qi l): ");
	performanceChoice = c.readLine ();
	while (!performanceChoice.equalsIgnoreCase ("L"))
	{
	    if (performanceChoice.equalsIgnoreCase ("S"))
	    {
		band = new Performance (bandMember1, c);
	    }
	    else if (performanceChoice.equalsIgnoreCase ("D"))
	    {
		band = new Performance (bandMember1, bandMember2, c);
	    }
	    else if (performanceChoice.equalsIgnoreCase ("T"))
	    {
		band = new Performance (bandMember1, bandMember2, bandMember3, c);
	    }
	    else if (performanceChoice.equalsIgnoreCase ("QA"))
	    {
		band = new Performance (bandMember1, bandMember2, bandMember3, bandMember4, c);
	    }
	    else
	    { //default  to quintet
		band = new Performance (bandMember1, bandMember2, bandMember3, bandMember4, bandMember5, c);
	    }
	    band.begin ();

	    c.print ("Would you like to hear a Solo, a Duet, a Trio, a Quartet, a Quintet or Leave? (s, d, t, qa,qi l): ");
	    performanceChoice = c.readLine ();
	}
	c.close ();
	System.exit (0);
    }
}
