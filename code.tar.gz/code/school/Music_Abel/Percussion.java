/**
 * Woodwind class.
 */
public abstract class Percussion extends Instrument
{


    /**
     * constructor
     * pre: none
     * post: A woodwind instrument has been created.
     */
    public Percussion (String player)
    {
	super (player);
    }


    /**
     * Returns the sound of the instrument.
     * pre: none
     * post: The sound made by the instrument is returned.
     *
    public String makeSound() {
	    return("toot");
    }/
    **/
}
