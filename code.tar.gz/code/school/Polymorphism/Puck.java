

public class Puck extends Disk
{

    boolean youth, standard;
    double weight;
    public Puck (double r, double t, double weight)
    {
	super (r, t);
	this.weight = weight;
    }


    public double getWeight ()
    {
	return weight;

    }


    public String getDivision ()
    {
		if (weight <= 5.5 && weight >= 5)
			return "Standard";
		else if (weight <= 4.5 && weight >= 4.5)
			return "Youth";
		else
			return "Non Regulation";
    }


    public boolean equals (Puck p)
    {
		return (weight == p.getWeight ()&& 
			super.getRadius () == p.getRadius ()
			&& super.getThickness () == p.getThickness ());

    }


    public String toString ()
    {
	String puckString;

	puckString = "The puck has radius " + super.getRadius () +
	    ", thickness " + super.getThickness () + " and weight of " + weight + ".";
	return (puckString);

    }
}
