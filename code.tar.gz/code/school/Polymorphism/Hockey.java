// The "Hockey" class.
import java.awt.*;
import hsa.Console;

public class Hockey
{
    static Console c;           // The output console

    public static void main (String[] args)
    {
	c = new Console ();

	Puck puck = new Puck (10, 0.02, 5);

	c.println ("Puck radius: " + puck.getRadius ());
	c.println ("Puck surface area: " + puck.area ());
	c.println ("Puck volume: " + puck.volume ());
	c.println ("Puck weight: " + puck.getWeight ());
	c.println ("Puck division: " + puck.getDivision ());


	Disk puck1 = new Puck (12, 0.05, 4);
	Disk puck2 = new Puck (12, 0.07, 4.5);
	if (puck1.equals (puck2))
	{
	    c.println ("The Pucks are equal.");
	}
	else
	{
	    c.println ("The Pucks are not equal.");
	}
	c.println (puck1.toString ());
	c.println (puck2.toString ());

	// Place your program here.  'c' is the output console
    } // main method
} // Hockey class
