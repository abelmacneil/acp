import hsa_new.*;
import java.awt.*;
import java.util.*;
public class Main {
	static final int TURNS = 5;
	static final int WIDTH = 100;
	static final int SPACE = 10;
	public static void main(String args []) throws Exception{
		
		Console c = new Console();
		
		Wheel w[][] = new Wheel [3][3];
		for( int i= 0;i < w.length ;i++){
			for(int j =0;j < w[i].length; j++){
				w[i][j] = new Wheel(20 + i * WIDTH + i * SPACE , 60 + j * WIDTH + j * SPACE,WIDTH,c);
			}
		}
		
		
		for(int i = 0; i < TURNS; i++){
			for(int j = 0; j < w.length; j++){
				for(int k = 0; k < w.length; k++){
					w[j][k].draw();
				}
			}
			
			Thread.sleep(200);
			
			
			for(int j = 0; j < w.length; j++){
				for(int k = 0; k < w.length; k++){
					if ( i != TURNS - 1){
						w[j][k].erase();
					}
				}
			}
		}
		
		boolean isequal = true;
		for(int j = 0; j < w.length - 1 ; j++){
			for(int k = 0; k < w[j].length && isequal; k++){
				//System.out.println(w[j][k].currentShape.getClass());
				isequal = w[j][k].equals(w[j+1][k]);
			}	
		}
		if (isequal){
			c.println("You win");
		}
		else{
			c.println("You Lost");
		}
		isequal = true;
		for(int j = 0; j < w.length; j++){
			for(int k = 0; k < w[j].length - 1&& isequal; k++){
				//System.out.println(w[j][k].currentShape.getClass());
				isequal = w[j][k].equals(w[j][k + 1]);
			}	
		}
		if (isequal){
			c.println("You win");
		}
		else
			c.println("You Lost");
		
	}
}
abstract class Shape{
	int x ,y, size;
	Color col;
	Console c;
	public Shape(int x, int y, int size, Color col, Console c){
		this.x = x;
		this.y = y;
		this.size = size;
		this.col = col;
		this.c = c;
	}
	void draw(){
		c.setColor(col);
	}
	void erase(){
		c.setColor(Color.white);
		c.fillRect(x,y, size, size);
	}	
}
class Triangle extends Shape{
	public Triangle(int x, int y, int size, Color col, Console c){
		super(x,y,size,col,c);
	}
	void draw(){
		super.draw();
		int xp [] = {x, x + size / 2, x + size};
		int yp [] = {y + size, y, y + size};
		c.fillPolygon(xp, yp, 3);
	}
}
class Circle extends Shape {
	public Circle(int x, int y, int size, Color col, Console c){
		super(x,y,size,col,c);
	}
	void draw(){
		super.draw();
		c.fillOval(x,y,size,size);
	}
}
class Square extends Shape {
	public Square(int x, int y, int size, Color col, Console c){
		super(x,y,size,col,c);
	}
	void draw(){
		super.draw();
		c.fillRect(x,y,size,size);
	}
}
class Wheel {
	Triangle t;
	Circle ci;
	Square s;
	Shape currentShape;
	
	public Wheel (int x, int y, int size, Console c){
		t = new Triangle (x,y, size, Color.green, c);
		ci = new Circle (x,y, size, Color.blue, c);
		s = new Square (x,y, size, Color.magenta, c);
		currentShape = null;
	}
	
	void draw(){
		int rand = new Random().nextInt(3);
		switch (rand){
			case 0: currentShape = t; break;
			case 1: currentShape = ci; break;
			case 2: currentShape = s; break;
		}
		currentShape.draw();
	}
	void erase(){
		currentShape.erase();
	}
	public boolean equals(Wheel obj){
		return this.currentShape.getClass().equals(obj.currentShape.getClass());
	}
}
