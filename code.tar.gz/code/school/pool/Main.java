import java.awt.*;
import hsa_new.*;
class Main {
	public static final double TIME_INT = 0.05; //in seconds
	public static final Color BACKGROUND  = Color.green;
	public static void main(String args[]) throws Exception{
		Console c = new Console();
		c.setColor(BACKGROUND);
		c.fillRect(0,0,1000,1000);
		Ball a = new Ball(350,300,30, 145,Color.white, c);
		Ball b = new Ball(100,100,0, 0, Color.yellow, c);
		a.update(b);
		b.update(a);
		for (int i = 0; i< 100; i++){
			a.update(b);
			b.update(a);
		}
		DPoint sol = a.intersectionPoint(b);
		if (sol == null)
			c.println("Null");
		else 
			c.println(sol.getX() + "," + sol.getY());
	}
}
class Ball{
	public static final int RADIUS = 20;
	int x, y;
	Console c;
	Color col;
	Vector2D velocity;
	Vector2D acceleration;
	double direction; //in degrees
	double time = 0.05;
	DPoint poi; //point of intersection
	public Ball (int x, int y, double velocity, double direction, Color col, Console c){
		this.x = x;
		this.y = y;
		this.col = col;
		this.c = c;
		this.direction = direction;
		this.velocity = new Vector2D(velocity, direction);
		acceleration = new Vector2D(-20, direction);
	}
	void update(Ball ball){
		if (velocity.getMagnitude() >= 0){
			erase();
			velocity.setMagnitude( // vf = vi + a*t
				velocity.getMagnitude() + acceleration.getMagnitude() * Main.TIME_INT);
			x += velocity.getX();
			y -= velocity.getY();
			poi = intersectionPoint(ball);
			if (poi != null){
				System.out.println("Intersected!");
				velocity.setMagnitude(-1);
				int val = 50;
				double m = getDerivative(poi);
				double b = poi.getY() - m *poi.getX() ;
				System.out.println(getDerivative(poi));
				DPoint one = new DPoint(poi.getX() -val, 
					m*(poi.getX() - val) + b);
				DPoint two = new DPoint(poi.getX() + val, 
					m*(poi.getX() + val) + b);
				c.setColor(Color.black);
				System.out.println(one.getX() + ", " +one.getY() + " : " +two.getX() + ", " + two.getY());
				c.drawLine((int)one.getX(),(int)one.getY(), (int)two.getX(),(int) two.getY());
			}
			draw();
			try{
				Thread.sleep((int) (time * 1000));
			}catch(Exception e){}
			
		}
	}
	DPoint intersectionPoint(Ball ball){
		double step = 1;
		double error = 10;
		double val = 0;
		for (double yi = y - RADIUS; yi < y + RADIUS; yi += step){
			for (double xi = x - RADIUS; xi < x + RADIUS; xi += step){
				val = Math.pow(xi - ball.getX(),2) + Math.pow(yi - ball.getY(),2) 
					- Math.pow(xi - getX(),2) - Math.pow(yi - getY(),2);
				
				if (val < error && val > -error){
					c.setColor(Color.black);
					c.fillOval((int)xi ,(int)yi ,1,1);
					return new DPoint (xi,yi);
				}
			}
		}
		return null;
	}
	public double getDerivative(DPoint p){
		return -(p.getX() - getX())/(p.getY() - getY());
	}
	public double getX(){
		return x;
	}
	public double getY(){
		return y;
	}
	
	void draw(){
		c.setColor(col);
		for (double theta = 0; theta <= 2 * Math.PI; theta += 0.01){
			c.drawLine(x,y,(int) (RADIUS*Math.cos(theta)) + x,(int) (RADIUS * Math.sin(theta)) + y);
		}
	}
	void erase(){
		c.setColor(Main.BACKGROUND);
		for (double theta = 0; theta <= 2 * Math.PI; theta += 0.01){
			c.drawLine(x,y,(int) (RADIUS*Math.cos(theta)) + x,(int) (RADIUS * Math.sin(theta)) + y);
		}
	}
	
}class DPoint{
	double x,y;
	public DPoint (double x, double y){
		this.x = x;
		this.y = y;
	}
	public double getX(){
		return x;
	}
	public double getY(){
		return y;
	}
}
class Vector2D{
	double mag;
	double theta;
	public Vector2D (double mag, double theta){
		this.mag = mag;
		this.theta = theta;
	}
	public void setMagnitude(double mag){
		this.mag = mag;
	}
	public double getMagnitude(){
		return mag;
	}
	
	public double getX(){
		return mag * Math.cos(Math.toRadians(theta));
	}
	public double getY(){
		return mag * Math.sin(Math.toRadians(theta));
	}
}
