

import java.awt.*;
import hsa_new.*;
import java.util.*;

public class Slot{
	//Constants
	public static final int WIDTH = 100;
	public static final int MARG = 0;
	public static final Color BACKGROUND = Color.white;
	public static final int NUM = 100;
	/**
	 * Pauses the current thread for the specified amount of time
	 * in milliseconds.
	 */
	static void pause(int time){
		try {
			Thread.sleep(time);
		}catch(Exception e) {}
	}
	public static void main(String [] arg){
		Console c = new Console(35,70);
		
		
		//draw background
		c.setColor(BACKGROUND);
		c.fillRect(0,0,1000,1000);
		//this array holds all of the wheels that will be displayed 
		//on the screen
		Wheel w[][] = new Wheel[5][5];
		
		//initializing our wheels
		for(int i =0 ; i < w.length; i++){
			for(int j = 0; j < w[i].length; j++){
				w[i][j] = new Wheel(c);
				w[i][j].set(0 + i * WIDTH + i * 5, 0 + j * WIDTH + j * 5);
				
			}
		}
		
		//this loop will draw and erase the wheels simulating a slot machine
		for(int i = 0; i < NUM; i++){
			//draws each wheel in the slot machine
			for(int j =0 ; j < w.length; j++){
				for(int k = 0; k < w[j].length; k++){
					w[j][k].draw();
				}
			}
			//slowly the pause time will grow 
			pause(i * 10);
			Toolkit.getDefaultToolkit().beep();
			//erase the wheel before drawing a new wheel
			for(int j =0 ; j < w.length; j++){
				for(int k = 0; k < w[j].length; k++){
					w[j][k].erase();
				}
			}
		}
		c.close();
		System.exit(0);
	}
}
/**
 * This is the generic shape class, representing 
 * all the possible shapes drawn on the screen.
 * It is abstract because it cannot instantiated,
 * it can only be extended.
 * For example: {Shape s = new Shape();} fails.
 */
 abstract class Shape{
	//the x and y coordinates of the shape
	protected int xCo, yCo;
	//our secondary colour
	protected Color linecolor;
	//out main color
	protected Color fillcolor;
	//the output console
	protected Console c;
	
	//Main constructor only takes the output console as a parameter
	public Shape(Console c){
		this.c = c;
		xCo = 0;
		yCo = 0;
	}
	
	//sets the coordinates and colours for the shape
	public void set(int x, int y, Color lc, Color fc){
		xCo = x;
		yCo = y;
		linecolor = lc;
		fillcolor = fc;
	}
	
	//draws the shape
	public void draw(){
		c.setColor(fillcolor);
	}
	//erases the shape
	public void erase(){
		c.setColor(Slot.BACKGROUND);
		c.fillRect(xCo,yCo,Slot.WIDTH, Slot.WIDTH);	
	}
}

/**
 * The ball class
 */
class Ball extends Shape{
	
	public Ball(Console c){
		//this calls the Parent Class's
		super(c);
	}
	
	//draw the ball
	public void draw(){
		//call Parent's draw method (setting the colour)
		super.draw();
		c.fillOval(xCo,yCo,Slot.WIDTH,Slot.WIDTH);
		c.setColor(linecolor);
		c.fillOval(xCo + Slot.WIDTH/4, yCo + Slot.WIDTH/4, Slot.WIDTH/4,Slot.WIDTH/4);
	}
}

/**
 * The Rect class
 */
class Rect extends Shape{
	
	public Rect(Console c){
		super(c);
		
	}
	
	public void draw(){
		//sets the colour
		super.draw();
		//Draws the Rectangle
		c.fillRect(xCo,yCo,Slot.WIDTH,Slot.WIDTH);
		c.setColor(linecolor);//sets to the secondary colour
		//draws an X in the Rectangle
		c.drawLine(xCo,yCo,xCo + Slot.WIDTH, yCo + Slot.WIDTH);
		c.drawLine(xCo + Slot.WIDTH,yCo,xCo, yCo + Slot.WIDTH);
	}
}

/**
 * The Tria class
 */
class Tria extends Shape{
	public Tria(Console c){
		super(c);
	}
	
	public void draw(){
		super.draw();
		// the coordinates 
		int x [] = {xCo, xCo + Slot.WIDTH, xCo + Slot.WIDTH /2};
		int y [] = {yCo + Slot.WIDTH, yCo + Slot.WIDTH, yCo};
		c.fillPolygon(x,y,3);
		//draws the secondary fill
		c.setColor(linecolor);
		c.drawLine(x[0],y[0], (x[1] + x[2])/2, (y[1] + y[2])/2);
		c.drawLine(x[1],y[1], (x[0] + x[2])/2, (y[0] + y[2])/2);
		c.drawLine(x[2],y[2], (x[0] + x[1])/2, (y[0] + y[1])/2);
	}
}

/**
 * The Cherry class
 */
class Cherry extends Ball{
	public Cherry (Console c){
		super(c);
	}
	public void set(int x, int y){
		super.set(x,y,Slot.BACKGROUND, Color.RED);
	}
}

/**
 * The Grape class
 */
class Grape extends Ball{
	public Grape (Console c){
		super(c);
	}
	public void set(int x, int y){
		super.set(x,y,Slot.BACKGROUND, Color.BLUE);
	}
}

/**
 * The Square class
 */
class Square extends Rect{
	public Square (Console c){
		super(c);
	}
	//sets the coordinates using a specific set of colours
	public void set(int x, int y){
		super.set(x,y,Slot.BACKGROUND, Color.CYAN);
	}
}

/**
 * The Pyramid class
 */
class Pyramid extends Tria{
	public Pyramid (Console c){
		super(c);
	}
	public void set(int x, int y){
		super.set(x,y,Slot.BACKGROUND, Color.GREEN);
	}
}

/**
 * The Wheel class
 */
final class Wheel{
	private Cherry ch;
	private Grape gr;
	private Square sq;
	private Pyramid py;
	private int xCo, yCo;
	private Shape currentShape;
	
	public Wheel(Console c){
		ch = new Cherry(c);
		gr = new Grape(c);
		sq = new Square(c);
		py = new Pyramid(c);
		xCo = 0;
		yCo = 0;
	}
	public void set(int x, int y){
		xCo = x;
		yCo = y;
		ch.set(xCo, yCo);
		gr.set(xCo, yCo);
		sq.set(xCo, yCo);
		py.set(xCo, yCo);
	}
	public void draw(){
		int rand = new Random().nextInt(4);
		switch (rand){
			case 0: currentShape = ch; break;
			case 1: currentShape = gr; break;
			case 2: currentShape = sq; break;
			case 3: currentShape = py; break;
		}
		currentShape.draw();
	}
	public void erase(){
		currentShape.erase();
	}
}


