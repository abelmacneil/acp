import hsa_new.*;
import java.awt.*;
class PascalTri {
	static Console c = new Console();
	static void arrayCopy(int [] one ,int[] two){
		for(int i = 0; i < one.length; i++){
			one[i] = two[i];
		}
	}
	static int[] printTri(int n){
		if(n == 0){
			int []r = {1};
			return r;
		}
		else if (n == 1){
			int r [] = {1,1};
			//printArr(r);
			return r;
		}
		int r [] = printTri(n - 1);
		int nr[] = new int[r.length + 1];
		nr[0] = 1;
		for(int i = 1; i < nr.length - 1; i++){
			nr[i] = r[i - 1] + r[i];
		}
		nr[nr.length - 1] = 1;
		//printArr(nr);
		return nr;
	}
	static void printArr(int ar[]){
		for(int i = 0; i < ar.length; i++)
			c.print(ar[i] + " ");
		c.println();
	}
	static void printTri2(int n){
		 int maxlen = 4;
		int [] row = new int[n + 1];
		c.print(" 0|");
		for (int j = 0; j < n + 1; j++){
				c.print("  ");
		}
		c.println(1);
		c.print(" 1|");
		for (int j = 0; j < n; j++){
				c.print("  ");
		}
		c.println("1   1");
		row[0] = 1;
		row[1] = 2;
		row[2] = 1;
		c.print(" 2|");
		for (int j = 0; j < n - 1; j++)
			c.print("  ");
			c.print(1);
		for (int j = 1; j < 3; j++)
			c.print(row[j], maxlen);
			
		
		c.println();
		int[] currow = new int[n + 1];
		for (int i = 2; i < n; i++){
			c.print(i + 1, 2);
			c.print("|");
			int j;
			for (j = 0; j < n - i; j++)
				c.print("  ");
			c.print(1);
			currow[0] = 1;
			for(j = 0; j < i ; j++){
				currow[j + 1] = row[j] + row[j + 1];
				c.print(currow[j + 1],maxlen);
				c.print(" ");
			}
			currow[j + 1] = 1;
			c.println("  " + currow[j + 1]);
			arrayCopy(row, currow);
		}
	}
	static int pascalTriangle(int row, int col){
		return printTri(row)[col - 1];
	}
	public static void main(String [] args){
		c.setColor(Color.white);
		int n = 10;
		printTri2(n);
		int row, col;
		while(true){
			c.setCursor(n + 3, 1);
			c.print("Row: ");
			row = c.readInt();
			c.print("Column: ");
			col = c.readInt();
			c.println();
			c.println(pascalTriangle(row,col));
			c.getChar();
			c.fillRect(0,n*17 + 15, 300, 50);
		}
	}
}
