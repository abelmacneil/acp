class Recursion
{
	static int sum(int start, int stop)
	{
		if(start == stop)
			return start;
		return sum(start, stop - 1) + stop;
	}
	static int sumEven(int start, int stop)
	{
		if(stop % 2 != 0)
			stop--;
		if(start == stop)
			return stop;
		if(start > stop)
			return 0;
		return sumEven(start, stop - 2) + stop;
	}
	static int sumOdd(int start, int stop)
	{
		if(stop % 2 == 0)
			stop--;
		if(start == stop)
			return stop;
		if(start > stop)
			return 0;
		return sumOdd(start, stop - 2) + stop;
	}
	static int power(int base, int exp)
	{
		if(exp == 0)
			return 1;
		return power(base, exp - 1) * base;
	}
	
	static int datCharCounter(String str, char ch, int i)
	{
		//System.out.print(str.charAt(i) + "i:" + i);
		if(i == str.length())
			return 0;
		else if (str.charAt(i) == ch)
			return 1 + datCharCounter(str,ch, i  + 1);
		else
			return datCharCounter(str,ch, i + 1);
	}
	static void toBin(long n, int base)
	{
		if(n % base >= 10)
			System.err.print((char)(55 + n));
		else
			System.err.print(n%base);
		//System.err.print(n%base);
		if (n%base != n)
			toBin(n/base,base);
	}
	static void tri(int row, int col)
	{
			if(col == 0)
				System.out.println('*');
			else
				System.out.print('*');
			if(row == 0)
				return;
			if(col != 0)
				tri(row , col - 1);
			else
				tri(row - 1, row - 1);
	}
	static void tri2(int row, int col)
	{
		
			if(col == row)
				System.out.println('*');
			else
				System.out.print('*');
			if(row == 0)
				return;
			if(col != row)
				tri2(row - 1, row - 1);
			else
				tri2(row , col - 1);
	}
	static void pascal(int n){
		int tri[][] = new int[n][n + 1];
		tri[0][0] = 1;
		System.out.println(1);
		for(int i = 1; i < n; i++){
			System.out.print(1);
			tri[i][0] = 1;
			tri[i][i] = 1;
			for(int j = 1; j < i; j++){
				tri[i][j] = tri[i-1][j]+tri[i-1][j-1];
				System.out.print(tri[i][j]);
			}
			System.out.println(1);
		}
	}
	public static void main(String [] args)
	{
		pascal(5);
	}
}
