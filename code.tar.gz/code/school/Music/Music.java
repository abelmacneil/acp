/*
 * Music.java
 * A program that demonstrates polymorphism.
 */
import java.awt.*;
import hsa_new.Console;

/**
 * A musical performance.
 */
public class Music
{
	static Console c;


    /** 
     * Returns a selected instrument.
     * pre: none
     * post: An instrument object has been returned.
     */
    public static Instrument assignInstrument ()
    {
		String instrumentChoice, name;
		

		c.println ("Select an instrument for the band member. ");
		c.print ("Vocals, Piccolo, or Clarinet (v, p, c): ");
		instrumentChoice = c.readLine ();
		c.print ("Enter the band member's name: ");
		name = c.readLine ();
		if (instrumentChoice.equalsIgnoreCase ("V"))
		{
			return (new Vocal (name));
		}
		else if (instrumentChoice.equalsIgnoreCase ("P"))
		{
			return (new Piccolo (name));
		}
		else
		{ //default to clarinet
			return (new Clarinet (name));
		}
	}


	public static void main (String[] args)
	{
		c = new Console();
		Performance band;
		Instrument bandMember1, bandMember2, bandMember3;
		
		String performanceChoice;

		/* assign instruments */
		bandMember1 = assignInstrument ();
		bandMember2 = assignInstrument ();
		bandMember3 = assignInstrument ();
		c.println (bandMember1 + " " + bandMember2 + " " + bandMember3 + "\n");

		c.print ("Would you like to hear a Solo, a Duet, a Trio, or Leave? (s, d, t, l): ");
		performanceChoice = c.readLine ();
		while (!performanceChoice.equalsIgnoreCase ("L"))
		{
			if (performanceChoice.equalsIgnoreCase ("S"))
			{
				band = new Performance (bandMember1,c);
			}
			else if (performanceChoice.equalsIgnoreCase ("D"))
			{
				band = new Performance (bandMember1, bandMember2,c);
			}
			else
			{ //default  to trio
				band = new Performance (bandMember1, bandMember2, bandMember3,c);
			}
			band.begin ();

			c.print ("\nWould you like to hear a Solo, a Duet, a Trio, or Leave? (s, d, t, l): ");
			performanceChoice = c.readLine ();
		}
		c.close();
		System.exit(0);
	}
}
