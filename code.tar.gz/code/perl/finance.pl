#!/usr/bin/perl
use Finance::Quote;
use Finance::YahooQuote;
my $q = Finance::Quote->new();
my %quotes = (
		'GS' => 'NYSE', 
		'JPM' => 'NYSE', 
		'GOOG' => 'NASDAQ',
		'AAPL' => 'NASDAQ');
my %data = $q->fetch('USA', keys %quotes);
my $vol;
for my $quote (sort keys %quotes){
	$vol = $data{$quote, 'volume'};
	if ($vol >= 1000000){
		$vol = sprintf("%4.2fM" , $vol / 1000000);
	}
	printf "%7s:%-5s \$%7.2f VOL: %6s P/E: %5.2f\n" , 
	       		$quotes{$quote}, 
	       		$quote,
			$data{$quote, 'price'},
			$vol,
			$data{$quote, 'pe'};
}
