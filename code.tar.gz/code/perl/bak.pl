#!/usr/bin/perl -w
use warnings;
use strict;
use Finance::YahooQuote;
use File::HomeDir;
use Term::Screen;
use Term::ReadKey;
my $scr = new Term::Screen;
$scr->clrscr();

$Finance::YahooQuote::TIMEOUT = 30;

my @quotes = undef;
my @symbols = undef;
my $end = undef;
my $c = undef;
my $exit_cond = undef;
my $delay_time = 15; #in seconds
my $once_only = 0;
if ($#ARGV != -1){
	if ($ARGV[0] eq '-t'){
		shift;
		$delay_time = shift;
	}elsif ($ARGV[0] eq '-1'){
		shift;
		$once_only = 1;
	}
	@symbols = @ARGV;
}
if ($#ARGV == -1){
	open my $stock_file, File::HomeDir->my_home . "/.stocks" or die $!;
	@symbols = <$stock_file>;
	close $stock_file;
}

do {
	@quotes = getquote @symbols;
	$scr->at(0,0);
	print scalar localtime;
	print " : Updated every $delay_time seconds : Enter q to exit." if not $once_only;
	foreach (0 .. $#quotes){
		$scr->at($_ + 2, 0);
		printf "%9s:%-5s \$%6s %6s (%s)  Vol: %8s Avg Vol: %8s  MktCap: %7s P/E: %5s\n",
       			$quotes[$_][21],	#Stock Market 
       			$quotes[$_][0],		#Name of Stock
       			$quotes[$_][2],		#Stock Price
			$quotes[$_][5],		#Increase/Decrease in price
			$quotes[$_][6],		#Percent change in price
			$quotes[$_][7], 	#Volume
			$quotes[$_][8],		#Average Volume
			$quotes[$_][20],	#Market capitalization
			$quotes[$_][16];	#P/E ratio
	}
	my $end = time() + $delay_time;
	while (not $once_only and (not defined $c or not $c eq 'q') and time() < $end) {
		$c = ReadKey(-1);
	}
}while (not $once_only and (not defined $c or not $c eq 'q'));

