import Control.Monad
import Control.Monad.Trans.Class
import Control.Monad.Trans.Cont

main1 = flip runContT return $ do
  lift $ putStrLn "alpha"
  n <- callCC $ \k -> do
    when (2 < 0) $ 
      k 0
    lift $ putStrLn "haha"
    return 1
  lift $ putStrLn "beta"
  lift $ putStrLn "gamma"
  lift $ print n

main2 = flip runContT return $ do
  (k, n) <- callCC $ \k -> let f x = k (f, x)
                               in return (f, 1)
  lift $ print n 
  when (n < 5) $ 
    k (n + 1) >> return ()

main =  print $ flip runCont (\x->[x]) $ do
    a <- return 1
    b <- cont (\k -> [10,30] >>= k)
    return $ a + b
