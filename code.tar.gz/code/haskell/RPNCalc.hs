import System.Environment

solveRPN :: String -> Double
solveRPN = head . foldl foldFct [] . words
    where foldFct (x:y:xs) "^" = (x ** y):xs
          foldFct (x:y:xs) "/" = (x / y):xs
          foldFct (x:y:xs) "*" = (x * y):xs
          foldFct (x:y:xs) "+" = (x + y):xs
          foldFct (x:y:xs) "-" = (x - y):xs
          foldFct xs numStr = (read numStr):xs

solvePPN :: String -> Double
solvePPN = solveRPN . reverse

main :: IO ()
main = do 
  (str:_) <- getArgs 
  print $ solveRPN str
