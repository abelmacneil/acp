import Control.Monad.State
import System.Random

randomState :: (RandomGen g, Random a) => State g a
randomState = state random

toss3Coins ::  State StdGen (Bool,Bool,Bool)
toss3Coins = do 
  a <- randomState
  b <- randomState
  c <- randomState
  return (a,b,c)
