main :: IO ()
main = do
  lst <- sequence $ take 5 $ repeat getLine
  putStrLn $ unwords lst

