import System.IO
import System.Directory
import System.Environment
import Control.Monad
import Control.Exception
import Data.List
import qualified Data.Map as Map

todoFileName :: IO String
todoFileName = do
    homeDir <- getHomeDirectory
    return (homeDir ++ "/.todoList")

printArgError :: String -> Int -> IO ()
printArgError cmd numArgs = 
    putStrLn $ "The " ++ cmd ++ " command takes " ++ 
      (show numArgs) ++ " argument(s)."

add :: [String] -> IO ()
add [task] = do
    fileName <- todoFileName
    appendFile fileName $ task ++ "\n"
add args = printArgError "add" 1

view :: [String] -> IO ()
view [] = do
    fileName <- todoFileName
    fileConts <- readFile fileName
    let list = zipWith (\n item -> 
                          show n ++ " - " ++ item) [1..] (lines fileConts)
    putStrLn "TODO:"
    mapM_ putStrLn list

view args = printArgError "view" 0

remove :: [String] -> IO ()
remove [taskNum] = do
    fileName <- todoFileName
    fileConts <- readFile fileName
    let number = (read taskNum :: Int) - 1
        oldList = lines fileConts
        newList = delete (oldList !! number) oldList
    bracketOnError (openTempFile "." "temp")
      (\(tempName, tempHandle) -> do
        hClose tempHandle
        removeFile tempName)
      (\(tempName, tempHandle) -> do
        hPutStr tempHandle $ unlines newList
        hClose tempHandle
        removeFile fileName
        renameFile tempName fileName)
remove args = printArgError "remove" 1

pop :: [String] -> IO ()
pop [] = remove ["1"]
pop args = printArgError "pop" 0

dispatch :: String -> [String] -> IO ()
dispatch "add" = add
dispatch "view" = view
dispatch "remove" = remove
dispatch "pop" = pop


type CommandMap = Map.Map String (Int, ([String] -> IO ())

commands :: CommandMap
commands = Map.fromList $
              [ ("add",     (1, add))
              , ("remove",  (1, remove))
              , ("view",    (0,view))
              , ("pop",     (0, pop))
              ]

processArgs :: CommandMap -> [String] -> IO ()
processArgs cmdMap [] = return ()
processArgs cmdMap (x:xs) = do
    let (nArgs, fct) = case Map.lookup x cmdMap of
                        Nothing -> (0, (\x -> return ()))
                        Just n -> (n, fct)
    fct $ take nArgs xs
    processArgs cmdMap $ drop nArgs xs

main :: IO ()
main = do
    fileName <- todoFileName
    fileExists <- doesFileExist fileName
    when (not fileExists) $ do
      writeFile fileName ""
      putStrLn $ "Created " ++ fileName
    args <- getArgs
    processArgs commands args
    --(cmd:args) <- getArgs
    --dispatch cmd args
