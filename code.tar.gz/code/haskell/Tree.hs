module Tree 
  ( singleton
  , treeInsert
  , fromList
  , treeElem) where

import Data.Monoid
import qualified Data.Foldable as F
data Tree a = EmptyTree | Node a (Tree a) (Tree a)
            deriving (Show)


singleton :: (Ord a) => a -> Tree a
singleton x = Node x EmptyTree EmptyTree

treeInsert :: (Ord a) => a -> Tree a -> Tree a
treeInsert x EmptyTree = singleton x
treeInsert x (Node y left right)
  | x == y = Node x left right
  | x < y = Node y (treeInsert x left) right
  | x > y = Node y (treeInsert x right) left


fromList :: (Ord a) => [a] -> Tree a
fromList = foldr treeInsert EmptyTree

treeElem :: (Ord a) => a -> Tree a -> Bool
treeElem x EmptyTree = False
treeElem x (Node y left right)
  | x == y = True
  | x < y = treeElem x left
  | x > y = treeElem x right


instance Functor Tree where
    fmap _ EmptyTree = EmptyTree
    fmap f (Node x left right) = Node (f x) (fmap f left) (fmap f right)

instance F.Foldable Tree where
    foldMap f EmptyTree = mempty
    foldMap f (Node x l r) = F.foldMap f l `mappend`
                             f x           `mappend`
                             F.foldMap f r 


main = putStrLn $ show (fromList [1..5])
