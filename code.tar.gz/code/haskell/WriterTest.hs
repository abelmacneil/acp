import Control.Monad.Writer

gcdDebug :: Int -> Int -> Writer [String] Int
gcdDebug a 0 = writer(a, ["Finished with " ++ show a])
gcdDebug a b = do
    tell [show a ++ " mod " ++ show b]
    gcdDebug b (a `mod` b)

--main = print $ runWriter $ gcdDebug 112 3
main = do
    let (x, stuff) = runWriter $ gcdDebug 112 3 in
        print x
