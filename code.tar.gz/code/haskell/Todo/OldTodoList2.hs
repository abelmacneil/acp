import System.IO
import Control.Applicative
import System.Directory
import System.Environment
import Control.Monad
import Control.Exception
import qualified Data.List as List
import qualified Data.Map as Map
import qualified Data.Char as Char

type TodoList = [String]
type Command = [String] -> TodoList -> TodoList
type CommandMap = Map.Map String (Int, Command)

todoFileName :: IO String
todoFileName = getAppUserDataDirectory "todoList"

printArgError :: String -> Int -> IO ()
printArgError cmd numArgs = 
    putStrLn $ "The " ++ cmd ++ " command takes " ++ 
      (show numArgs) ++ " argument(s)."

fileKey :: Int
fileKey = 20

encode :: Int -> String -> String
encode key = map (Char.chr . (+key) . Char.ord)

decode :: Int -> String -> String
decode key = encode (-key)

writeNewTodoList :: TodoList -> IO ()
writeNewTodoList newList = do
    fileName <- todoFileName
    bracketOnError (openTempFile "." "temp")
      (\(tempName, tempHandle) -> do
        hClose tempHandle
        removeFile tempName)
      (\(tempName, tempHandle) -> do
        hPutStr tempHandle $ encode fileKey $ unlines newList
        hClose tempHandle
        removeFile fileName
        renameFile tempName fileName)

add :: Command
add [task] todoList = todoList ++ [task]

remove :: Command
remove [taskNum] todoList = 
    let number = (read taskNum :: Int) - 1 in
      if number >= 0 && number < length todoList then
        List.delete (todoList !! number) todoList
      else
        todoList

pop :: Command
pop _ = tail 

push :: Command
push [task] todoList = task:todoList

replace :: Command
replace [indexStr, newTask] todoList = 
    let index = read indexStr in
      if index >= 0 && index < length todoList then
        let (beginning, (_:end)) = List.splitAt (index - 1) todoList in
          beginning ++ (newTask:end)
      else
        todoList

clear :: Command
clear _ _ = []

insert :: Command
insert [indexStr, task] todoList =
    let index = read indexStr - 1
        (beg, end) = splitAt index todoList in
      beg ++ [task] ++ end

commands :: CommandMap
commands = Map.fromList $
              [ ("add",     (1, add))
              , ("remove",  (1, remove))
              , ("pop",     (0, pop))
              , ("push",    (1, push))
              , ("replace", (2, replace))
              , ("clear",   (0, clear))
              , ("insert",  (2, insert))
              ]

view :: TodoList -> IO ()
view todoList = do
    let list = zipWith (\n item -> 
          show n ++ " - " ++ item) [1..] todoList
    putStrLn "TODO:"
    mapM_ putStrLn list

processArgs :: CommandMap -> TodoList -> [String] -> IO TodoList
processArgs cmdMap todoList [] = return todoList
processArgs cmdMap todoList ("view":args) = do
    view todoList
    processArgs cmdMap todoList args
processArgs cmdMap todoList (arg:args) = do
    let (numArgs, fct) = case Map.lookup arg cmdMap of
                        Nothing -> (-1, \_ _-> return [])
                        Just (n, fct) -> (n,fct)
    if numArgs < 0 then do
      putStrLn $ "Command '" ++ arg ++ "' does not exist."
      processArgs cmdMap todoList args
    else
      processArgs cmdMap (fct (take numArgs args) todoList) $ drop numArgs args

main :: IO ()
main = do
    fileName <- todoFileName
    fileExists <- doesFileExist fileName
    when (not fileExists) $ do
      writeFile fileName ""
      putStrLn $ "Created " ++ fileName
    fmap (\x -> lines $ decode fileKey x) $ readFile fileName 
    >>= (\oldList -> return $ processArgs commands oldList) 
    >>= (\f -> f =<< getArgs) 
    >>= writeNewTodoList  


