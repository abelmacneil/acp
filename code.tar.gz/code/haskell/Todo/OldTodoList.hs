import System.IO
import System.Directory
import System.Environment
import Control.Monad
import Control.Exception
import qualified Data.List as List
import qualified Data.Map as Map

type TodoList = [String]
type Command = [String] -> IO ()
type CommandMap = Map.Map String (Int, Command)

todoFileName :: IO String
todoFileName = do
    homeDir <- getHomeDirectory
    return (homeDir ++ "/.todoList")

printArgError :: String -> Int -> IO ()
printArgError cmd numArgs = 
    putStrLn $ "The " ++ cmd ++ " command takes " ++ 
      (show numArgs) ++ " argument(s)."

writeNewTodoList :: (TodoList -> TodoList) -> IO ()
writeNewTodoList newListFct = do
    fileName <- todoFileName
    fileConts <- readFile fileName
    let oldList = lines fileConts
        newList = newListFct oldList
    bracketOnError (openTempFile "." "temp")
      (\(tempName, tempHandle) -> do
        hClose tempHandle
        removeFile tempName)
      (\(tempName, tempHandle) -> do
        hPutStr tempHandle $ unlines newList
        hClose tempHandle
        removeFile fileName
        renameFile tempName fileName)

add :: Command
add [task] = do
    fileName <- todoFileName
    appendFile fileName $ task ++ "\n"

view :: Command
view [] = do
    fileName <- todoFileName
    fileConts <- readFile fileName
    let list = zipWith (\n item -> 
                          show n ++ " - " ++ item) [1..] (lines fileConts)
    putStrLn "TODO:"
    mapM_ putStrLn list

remove :: Command
remove [taskNum] = writeNewTodoList (\oldList ->
    let number = (read taskNum :: Int) - 1 in
        List.delete (oldList !! number) oldList)

pop :: Command
pop [] = writeNewTodoList (\oldList -> tail oldList)

push :: Command
push [task] = writeNewTodoList (\oldList -> task:oldList)

replace :: Command
replace [indexStr, newTask] = writeNewTodoList (\oldList -> 
    let index = read indexStr
        (beginning, (_:end)) = List.splitAt (index - 1) oldList in
        beginning ++ (newTask:end))

clear :: Command
clear [] = writeNewTodoList (\_ -> [])

commands :: CommandMap
commands = Map.fromList $
              [ ("add",     (1, add))
              , ("remove",  (1, remove))
              , ("view",    (0, view))
              , ("pop",     (0, pop))
              , ("push",    (1, push))
              , ("replace", (2, replace))
              , ("clear",   (0, clear))
              ]

processArgs :: CommandMap -> [String] -> IO ()
processArgs cmdMap [] = return ()
processArgs cmdMap (arg:args) = do
    let (numArgs, fct) = case Map.lookup arg cmdMap of
                        Nothing -> (0, \_ -> putStrLn $ 
                                   "Command '" ++ arg ++ "' does not eargist.")
                        Just (n, fct) -> (n,fct)
    fct $ take numArgs args
    processArgs cmdMap $ drop numArgs args

main :: IO ()
main = do
    fileName <- todoFileName
    fileExists <- doesFileExist fileName
    when (not fileExists) $ do
      writeFile fileName ""
      putStrLn $ "Created " ++ fileName
    args <- getArgs
    processArgs commands args


