import Data.Char
import System.IO
import System.Environment
convert :: Integer -> Integer -> String
convert 0 _ = "0"
convert num base = reverse $ f num base 
f :: Integer -> Integer -> String
f 0  _ = "" 
f num  base = 
    (getNum $ fromIntegral $ num `mod` base) : f (num `div` base) base
  where getNum n
          | n < 10 = chr $ (ord '0') + n
          | otherwise = chr $ (ord 'A') - 10 + n

main = do
    [numStr, baseStr] <- getArgs
    let num = read numStr
        base = read baseStr in
          putStrLn $ convert num base
