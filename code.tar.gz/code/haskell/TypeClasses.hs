-- For types that can be mapped over.
-- Applying a function to a container.
class Functor f where
    -- Maps the function over the functor
    fmap :: (a -> b) -> f a -> f b
    --Law 1
    fmap id = id
    --Law 2
    fmap (f . g) = fmap f . fmap g
    

class (Functor f) => Applicative f where
    -- Puts the argument in a default context.
    pure :: a -> f a
    -- takes a functor value that has a function in it 
    -- and another functor, and extracts that function
    -- from the first functor and then maps it over the 
    -- second one.
    (<*>) :: f (a -> b) -> f a -> f b
    -- Infix style fmap
    (<$>) :: (a -> b) -> f a -> f b
    f <$> x = fmap f x
    -- Laws:
    pure id <*> v = v
    pure (.) <*> u <*> v <*> w = u <*> (v <*> w)
    pure f <*> pure x = pure (f x)
    u <*> pure y = pure ($ y) <*> u

    liftA2 :: (a -> b -> c) -> f a -> f b -> f c
    liftA2 f a b = f <$> a <*> b

class Monoid m where
    mempty :: m
    mappend :: m -> m -> m
    mconcat :: [m] -> m
    mconcat = foldr mappend mempty

class Monad m where
    return :: a -> m a
    (>>=) :: m a -> (a -> m b) -> m b
    (>>) :: m a -> m b -> m b
    x >> y = x >>= \_ -> y
    fail :: String -> m a
    fail msg = error msg

-- do Notation
foo1 = Just 3   >>= (\x ->
       Just "!" >>= (\y ->
       Just (show x ++ y)))
--is Equivalent to 
foo2 = do
    x <- Just 3
    y <- Just "!"
    Just (show x ++ y)


