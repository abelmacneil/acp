import qualified Data.Char as Char
import qualified Data.List as L
len :: (Integral a) => [b] -> a
len [] = 0
len (_:xs) = 1 +len xs


factorial :: (Integral a) => a -> a
factorial 0 = 1
factorial n = n * factorial (n - 1)

fib :: (Integral a) => a -> a
fib 0 = 1
fib 1 = 1
fib n = fib (n - 1) + fib (n - 2)

pythagoreanTriples :: (Integral a) => [(a,a,a)]
pythagoreanTriples = [(a,b,c) | c <- [1..], b <- [1..c], a <- [1..b], a^2 + b^2 == c^2]

digitSum :: Int -> Int
digitSum = sum . map Char.digitToInt . show


map'  :: (a -> b) -> [a] -> [b]
map' f = foldr (\x acc -> f x : acc) [] 

filter' :: (a -> Bool) -> [a] -> [a]
filter' p = foldr (\x acc -> if p x then x:acc else acc) [] 

some' :: (a -> Bool) -> [a] -> Bool
some' p = foldr (\x acc -> if p x then True else acc) False 

elem' ::(Eq a) => a -> [a] -> Bool
elem' e = foldr (\x acc -> if e == x then True else acc) False


piFct n = 
    (*4) $ sum $ zipWith ($) (cycle [id,negate]) $ map (\x -> 1/x ) [1,3..n*2]

groupBy :: Int -> [a] -> [[a]]
groupBy _ [] = []
groupBy 0 _ = []
groupBy n xs = take n xs : groupBy n (drop n xs)

foldl'' :: (a -> b -> a) -> a -> [b] -> a
foldl'' _ i [] = i
foldl'' f i (x:xs) = foldl'' f (f i x) xs

foldr' :: (a -> b -> b) -> b -> [a] -> b
foldr' _ i [] = i
foldr' f i (x:xs) = f x (foldr' f i xs)

factor :: (Integral a) => a -> [a]
factor n =  L.sort $ foldl (\acc x -> if n `mod` x == 0
                           then if x /= (n `div` x)
                                  then x:(n `div` x):acc
                                  else x:acc
                                  else acc) [] [1..(floor (sqrt (fromIntegral n)))]

isPrime :: (Integral a) => a -> Bool
isPrime n = (==1) . length $ filter (\x -> 
            n `mod` x == 0) [1..(floor (sqrt (fromIntegral n)))]

goodFactor :: (Integral a) => a -> [a]
goodFactor n =  foldl (\acc x -> 
                      if n `mod` x == 0
                        then if x /= (n `div` x)
                               then x:(n `div` x):acc
                               else x:acc
                               else acc) [] 
                               [2..(floor (sqrt(fromIntegral n)))]

primeFactors :: (Integral a) => a -> [a]
primeFactors n =  L.sort $ (concatMap (\x -> 
                           if isPrime x
                           then [x]
                           else primeFactors x) $ goodFactor n)

quicksort :: (Ord a) => [a] -> [a]
quicksort [] = []
quicksort (x:xs) = 
    let lesser = filter (<= x) xs
        greater = filter (> x) xs
    in quicksort lesser ++ [x] ++ quicksort greater

splitBy :: (Eq a) => [a] -> a -> [[a]]
splitBy xs y = foldr f [[]] xs
  where f c l@(x:xs)
          | c == y = []:l
          | otherwise = (c:x):xs
--  where split [] _ acc = [reverse acc]
--        split (x:xs) y acc 
--          | y == x = (:) (reverse acc) $ split xs y []
--          | otherwise = split xs y (x:acc) 
--  where split [] _ acc res = reverse ((reverse acc):res)
--        split (x:xs) y acc res
--          | y == x = split xs y [] ((reverse acc):res)
--          | otherwise = split xs y (x:acc) res
--

