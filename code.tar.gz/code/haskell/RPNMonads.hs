import Control.Monad
import Data.List

readMaybe :: (Read a) => String -> Maybe a
readMaybe str = case reads str of 
                  [(x,"")] -> Just x
                  _ -> Nothing

foldFct :: [Double] -> String -> Maybe [Double]
foldFct (x:y:ys) "/" = return ((x / y):ys)
foldFct (x:y:ys) "*" = return ((x * y):ys)
foldFct (x:y:ys) "+" = return ((x + y):ys)
foldFct (x:y:ys) "-" = return ((x - y):ys)
foldFct xs numStr = liftM (:xs) (readMaybe numStr)

solveRPN :: String -> Maybe Double
solveRPN str = do
  [result] <- foldM foldFct [] (words str)
  return result
