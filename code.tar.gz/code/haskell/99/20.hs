import Data.List as L

--11
data Many a = Single a | Multiple Int a deriving Show

encodeModified :: (Eq a) => [a] -> [Many a]
encodeModified = map helper . group
    where helper x = 
              let len = length x 
              in
                if (len == 1) 
                then Single (head x) 
                else Multiple len (head x)
--12
decodeModified :: (Eq a) => [Many a] -> [a]
decodeModified = concatMap helper 
    where 
      helper (Multiple n x) = replicate n x
      helper (Single x) = [x]

--13
encodeDirect :: (Eq a) => [a] -> [Many a]

    where helper x = 
              let len = length x 
              in
                if (len == 1) 
                then Single (head x) 
                else Multiple len (head x)
