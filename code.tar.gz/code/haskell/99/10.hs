--first 10 problems of 99 problems in haskell
--http://www.haskell.org/haskellwiki/99_questions/1_to_10

--1
myLast :: [a] -> a
myLast (x:[]) = x
myLast (_:xs) = myLast xs

--2
mySndLast :: [a] -> a
mySndLast (x:_:[]) = x
mySndLast (_:xs) = mySndLast xs

--3
elementAt :: [a] -> Int -> a
elementAt (x:_) 1 = x
elementAt (_:xs) n = elementAt xs (n - 1)

--4
myLength :: [a] -> Integer
myLength [] = 0
myLength (x:xs) = 1 + myLength xs

myLength' :: [a] -> Integer
myLength' xs = len xs 0
    where len [] acc = acc
          len (_:xs) acc =len xs (acc + 1)

--5
myReverse :: [a] -> [a]
myReverse [] = []
myReverse (x:xs) = myReverse xs ++ [x]

myReverse' :: [a] -> [a]
myReverse' xs = rev xs []
    where rev [] acc = acc
          rev (x:xs) acc = rev xs (x:acc)

--6
isPalendrome :: (Eq a) => [a] -> Bool
isPalendrome [] = True
isPalendrome (_:[]) = True
isPalendrome (x:xs) = x == myLast xs && isPalendrome (init xs)

--7
data NestedList a = Elem a | List [NestedList a]
flatten :: NestedList a -> [a]
flatten (List []) = []
flatten (Elem a) = [a]
flatten (List a) = concatMap flatten a

--8
compress :: (Eq a) => [a] -> [a]
compress xs = reverse $ comp xs []
    where comp [] acc = acc
          comp (x:xs) acc
              | x `elem` acc = comp xs acc
              | otherwise = comp xs $ x:acc

--9
pack :: (Eq a) => [a] -> [[a]]
pack [] = []
pack (x:xs) = let (fst, rest) = span (==x) xs
              in (x:fst) : pack rest

--10
encode :: (Eq a) => [a] -> [(Int, a)]
encode xs = map (\x -> (length x, head x)) (pack xs)
