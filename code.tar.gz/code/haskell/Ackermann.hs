ackermann :: Int -> Int -> Int
ackermann 0 n = n + 1
ackermann m 0 = ackermann (m - 1) 1
ackermann m n = ackermann (m - 1) $ ackermann m (n - 1) 

mccarthy91 :: Int -> Int
--mccarthy91 n = if n > 100 then n - 10 else mccarthy91 $ mccarthy91 $ n + 11
mccarthy91 n   
  | n > 100 = n - 10
  | otherwise = mccarthy91 $ mccarthy91 $ n + 11


f :: Int -> Int
f n
  | n > 10 = n - 5
  | otherwise = f . f $ n + 7
