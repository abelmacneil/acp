public class Foo {
    int bar() {
        return 42;
    }
}
