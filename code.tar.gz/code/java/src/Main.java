import java.io.*;
public class Main {
    public static void main(String []args) throws IOException {
        System.out.println(new Foo().bar());
        PrintWriter writer = new PrintWriter(
                new BufferedWriter(new FileWriter("file.txt", true)));
        writer.println("Hello");
        writer.println("Testing");
        writer.close();
    }
}
