#include <math.h>
unsigned int inline factor_sum (unsigned int n);

int main (int argc, char ** argv){

  unsigned int i, dn, sum = 0;
  for (i = 2; i < 10000; i++){
	dn = factor_sum(i);
	if (dn < i && factor_sum(dn) == i)
	  sum += i + dn;
  }
  //printf ("%d\n", sum);
  return 0;
}


unsigned int inline factor_sum (unsigned int n){
  unsigned int i, sum = 1;
  for (i = 2; i <= (unsigned int) sqrt(n); i++){
	if (n % i == 0){
	  sum += i;
	  if (i != n/i){
		sum += n/i;
	  }
	}
  }
  return sum;
}
