#include <stdlib.h>
#include <stdio.h>
#include <string.h>


void q_sort (char **arr, int low, int high);
int mystrcmp (const void * s1, const void * s2)
{
	char ** v1 = (char **) s1;
	char ** v2 = (char **) s2;
	return strcmp( *v1, *v2);
}
int main (){
	char **names = malloc(1), *tmp;
	int n = 0, i, c, sum = 0;
	long long bigsum = 0;
	FILE *file = fopen("22.txt", "r");
	while ((c = fgetc(file)) != EOF){
		i = 0;	
		fgetc(file);
		tmp = malloc(1);
		while ((c = fgetc(file)) != ',' && c != '"' && c != EOF){
			tmp = realloc(tmp, (i + 1));
			tmp[i] = (char) c;
			i++;
		}
		sum += i + 1;
		tmp[i] = '\0';
		names = realloc(names, sum + 1);
		names[n] = malloc(i);
		strcpy(names[n], tmp);
		n++;
		free(tmp);
		tmp = NULL;
		
	}
	close(file);
	qsort(names,--n,sizeof(char*), mystrcmp);
	printf("%s\n",names[0]);
	for(i = 0; i < n; i++){
		int len = strlen(names[i]);
		sum = 0;
		for (c = 0; c < len; c++)
			sum += names[i][c] - 64;
		bigsum += (i + 0) * sum;
		if (strcmp(names[i],"COLIN") == 0) printf("%d %d %d\n", sum, i+1, sum * i);
		printf("%s %d %d\n", names[i], sum, i);	
		getchar();
	}
	printf("%Li\n", bigsum);
	free(names);
	return 0;
}

void q_sort (char **arr, int low, int high)
{
	int piv, i, j;
	char *tmp;
  	if (low < high){
		i = low;
		j = high;
		piv = (i + j) / 2;
		while (i < j){
	  		while (strcmp(arr[i],arr[piv]) <= 0 && i < high) i++;
	  		while (strcmp(arr[j], arr[piv]) > 0) j--;
		  	if (i < j){
				tmp = malloc(strlen(arr[i]));
				strcpy(tmp, arr[i]);
				strcpy(arr[i], arr[j]);
				strcpy(arr[j], tmp);
				free(tmp);
				tmp = NULL;
			}
		}
		tmp = malloc(strlen(arr[i]));
		strcpy(tmp, arr[j]);
		strcpy(arr[j], arr[piv]);
		strcpy(arr[piv], tmp);
		free(tmp);
		tmp = NULL;
		q_sort(arr, low, j - 1);
		q_sort(arr, j + 1, high);
  	}
}
