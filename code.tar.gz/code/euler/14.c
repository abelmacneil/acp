#include <stdlib.h>
#include <stdio.h>

unsigned int collatz_length (unsigned int n);

int main (int argc, char ** argv){
  unsigned int i = 500001, max = 1, tmp, maxi;
  while (i < 1000000){
	tmp = collatz_length (i);
	if (tmp > max){
	  max = tmp;
	  maxi = i;
	}
	i += 2;
  }
  printf ("%d : %d\n", maxi, max);
  return 0;
}

unsigned int collatz_length (unsigned int n){
  unsigned int i = 0;
  while (n != 1){
	if (n & 1)
	  n = 3 * n + 1;
	else
	  n = n / 2;
	i++;
  }
  return ++i;
}
