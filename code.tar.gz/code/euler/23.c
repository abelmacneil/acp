#include <stdio.h>
#include <stdlib.h>

#define SWAP(a,b) do{ \
		a ^= b; \
		b ^= a; \
		a ^= b; \
	}while (0); 		

int main ()
{
	char nums[] = "012";
	int len = 3;
	int used[] = {0,0,0};
	int i = 0, a = 0;
	while (a < 6){
		printf("%s\n", nums);
		SWAP(nums[len - 1], nums[len - 2]);
		printf("%s\n", nums);
		SWAP(nums[len - 1], nums[len - 2]);
		SWAP(nums[len - 3], nums[len - 2]);
		a+=2;
	}
	return 0;
}
