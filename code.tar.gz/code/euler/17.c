#include <stdlib.h>
#include <stdio.h>

char * num_to_english (int n);
char * single_num_to_english(int n);

int main (int argc, char ** argv){
  printf("%d", 8 % 100);
  //printf("%s\n", num_to_english(atoi(argv[1])));
  return 0;
}

char * single_num_to_english (int n){
{
  switch (n) {
  case 1: 
  }
}
char * 

char * num_to_english (int n){
  if (n < 10 || n > 19)
	return single_num_to_english(n);
}
