import Data.List

perms :: (Eq a) => [a] -> [[a]]
perms [] = [[]]
perms xs = do
  x <- xs
  map (x:) (perms $ delete x xs)

main = do
  putStrLn ((perms "0123456789") !! 999999)




