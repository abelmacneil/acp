import qualified Data.List as List
import Data.Char
import System.IO

splitBy :: Eq a => a -> [a] -> [[a]]
splitBy delimiter = foldr f [[]] 
    where f c l@(x:xs) | c == delimiter = []:l
                       | otherwise = (c:x):xs


getTotalScore :: [Char] -> Int
getTotalScore names = 
    sum . zipWith (*) [1..] . map (sum . map (subtract 64 . ord)) $ 
            List.sort . splitBy ',' . filter (/='\"') $ names

--not mine
solve input = sum(zipWith (*) (map sum (List.sort(map (map (\x->toInteger(ord(x))-64)) input))) [1..])

main :: IO ()
main = do
  contents <- readFile "names.txt"
  print $ getTotalScore contents
