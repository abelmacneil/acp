package hangman.linguistics;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Used to find the most common letters in a list.
 * @author A MacNeil
 * @version Jan 27,2012.
 */
public class LetterFrequency {
    
    private int totalChars = 0;
    private List<String> wordList;
    private List<Letter> frequency;
    private LetterComparator comparator;

    /**
     * Creates a new Frequency based on the specified word list.o
     * @param wordList The list of words.
     */
    public LetterFrequency(List<String> wordList) {
        this.wordList = wordList;
        frequency = findFrequency();
        comparator = new LetterComparator();
        Collections.sort(frequency, comparator);
    }

    /**
     * Gets the List of letters based on their frequency.
     * @return The frequency of the letters.
     */
    public List<Letter> getFrequency() {
        return this.frequency;
    }

    @Override
    public String toString() {
        return frequency.toString();
    }

    /**
     * Finds the frequency of the letters.
     * @return the frequency of the letters.
     */
    private List<Letter> findFrequency() {
        List<Letter> freq = initAlphabet();
        for (String currStr : wordList) {
            for (int i = 0; i < currStr.length(); i++) {
                freq.get(currStr.charAt(i) - 'a').increment();
                totalChars++;
            }
        }
        List<Letter> lettersRemoved = new LinkedList<Letter>();
        for (Letter l : freq) {
            if (l.getInstances() == 0) {
                lettersRemoved.add(l);
            }
        }
        
        for (int i = 0; i < lettersRemoved.size(); i++) {
            freq.remove(freq.indexOf(lettersRemoved.get(i)));
        }

        return freq;
    }

    /**
     * Initializes the alphabet of characters.
     * @return The list containing the alphabet.
     */
    private List<Letter> initAlphabet() {
        List<Letter> alphabet = new LinkedList();

        for (char c = 'a'; c <= 'z'; c++) {
            alphabet.add(new Letter(c, 0));
        }
        return alphabet;
    }
}
