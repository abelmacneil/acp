package hangman.linguistics;

import java.util.Comparator;

/**
 * Used to compare letters by the number of time they appear in a list.
 * @author A MacNeil
 * @version Jan 27, 2012
 */
public class LetterComparator implements Comparator<Letter>{

    @Override
    public int compare(Letter l1, Letter l2) {
        int rank1 = l1.getInstances();
        int rank2 = l2.getInstances();

        if (rank1 > rank2){
            return -1;
        }else if (rank1 < rank2){
            return 1;
        }else{
            return 0;
        }
    }
    
}
