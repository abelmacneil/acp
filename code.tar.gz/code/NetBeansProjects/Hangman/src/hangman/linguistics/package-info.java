/**
 * A set of tools that analyze language,
 * or provide large lists of words and their definitions.
 */
package hangman.linguistics;