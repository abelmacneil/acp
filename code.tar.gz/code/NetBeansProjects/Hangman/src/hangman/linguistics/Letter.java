package hangman.linguistics;

/**
 * Use d to represent a character and the number of time it appears in a list.
 * @author A MacNeil
 * @version Jan 27,2012
 */
public class Letter {

    private Character character;
    private int numInstances;

    /**
     * Creates a new Letter based on the specified character
     * and the number of instances it occurs in a list.
     * @param c The character it represents.
     * @param numInstances The number of times the character appears in a list.
     */
    protected Letter(Character c, int numInstances) {
        this.character = c;
        this.numInstances = numInstances;
    }

    /**
     * Gets the character value of this letter.
     * @return  the character value of this letter.
     */
    public Character getCharValue() {
        return character;
    }

    /**
     * Increments the number of times this letter appears in a list.
     */
    protected void increment() {
        numInstances++;
    }

    /**
     * Gets the number of times this letter appears in a list.
     * @return the number of times this letter appears in a list.
     */
    protected int getInstances() {
        return numInstances;
    }

    @Override
    public String toString() {
        return character + ":" + numInstances;
    }
}
