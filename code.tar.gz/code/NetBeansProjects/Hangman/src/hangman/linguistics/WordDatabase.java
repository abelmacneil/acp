package hangman.linguistics;

import hangman.game.Game;
import hangman.logging.ErrorLog;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import static java.util.Collections.binarySearch;
import static java.util.Collections.sort;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * Class for loading the game's database of words.
 * 
 * @author A MacNeil
 * @see Game
 */
public class WordDatabase {

    /** 
     * The maximum length that words in the game may have.
     */
    public static final int MIN_WORD_LENGTH = 3;
    /** 
     * The minimum length that words in the game may have.
     */
    public static final int MAX_WORD_LENGTH = 28;
    /**
     * Represents the simple list of words.
     */
    public static final int SIMPLE = 0;
    /**
     * Represents the complex list of words.
     */
    public static final int COMPLEX = 1;
    /**
     * Represents the food list of words.
     */
    public static final int FOOD = 2;
    private int currType;
    private List<String>[] wordLists = new List[4];
    private final File[] WORD_FILES = {new File("src/hangman/linguistics/lists/simpleList.txt"),
        new File("src/hangman/linguistics/lists/complexList.txt"),
        new File("src/hangman/linguistics/lists/foodList.txt"),
        new File("src/hangman/linguistics/lists/definitionList.txt")};
    private List<String> currList;
    private ErrorLog err;

    /**
     * Constructs a the single instance of the class, 
     * and loads the word database. 
     */
    private WordDatabase() {
        err = new ErrorLog("src/hangman/linguistics/Errors.log");
        try {
            this.initLists();
        } catch (Exception ex) {
            err.log(ex);
        } finally {
            setList(SIMPLE);
        }
    }

    /**
     * Sets the maximum and minimum length of the words.
     * @param min The minimum word length.
     * @param max The maximum word length.
     */
    public void setWordLength(int min, int max) {
        setList(currType);
        List<String> tempList = currList;
        currList = new ArrayList<String>();
        for (String s : tempList) {
            if (s.length() >= min && s.length() <= max) {
                currList.add(s);
            }
        }
        sort(currList);
    }

    /**
     * Sets the current list to be used for generating random words.
     * @param type The type of word list.
     * @see WordDatabase#COMPLEX
     * @see WordDatabase#SIMPLE
     * @see WordDatabase#FOOD
     */
    public final void setList(int type) {
        if (type < SIMPLE || type > FOOD) {
            throw new IllegalArgumentException();
        }
        this.currType = type;
        currList = new ArrayList<String>(wordLists[type]);
    }

    /**
     * Gets the number of words in the specified list.
     * @param type The type of list to check.
     * @return THe size of the specified list.
     * @see WordDatabase#COMPLEX
     * @see WordDatabase#SIMPLE
     * @see WordDatabase#FOOD
     */
    public int getSize(int type) {
        return wordLists[type].size();
    }

    /**
     * Finds the definition of the specified word.
     * @param word The word to look up.
     * @return The definition of the word.
     */
    public String getDefinition(String word) {
        for (String str : wordLists[wordLists.length - 1]) {
            if (str.indexOf(Parser.trim(word) + " ") == 0) {
                return str;
            }
        }
        return "Definition not found.";
    }

    /**
     * Generates a random word from the current word list.
     * @return A randomly generated word.
     */
    public String getRandomWord() {

        if (currList.isEmpty()) {
            return "";
        }
        Random rng = new Random();
        return currList.get(rng.nextInt(currList.size()));
    }

    /**
     * Finds the item at the specified index.
     * @param index The location of the item.
     * @return The item at the index.
     */
    public String get(int index) {
        return currList.get(index);
    }

    /**
     * Finds the index of the specified {@code String}, using a binary search,
     * if the {@code String} is not found in any of the lists, -1 is returned.
     * @param str The {@code String} to search for.
     * @return The index of the {@code String}.
     */
    public int indexOf(String str) {
        int index;
        for (int i = 0; i < wordLists.length; i++) {
            index = binarySearch(wordLists[i], str);
            if (index != -1) {
                return index;
            }
        }
        return -1;
    }

    public int size() {
        return currList.size();
    }

    /**
     * Loads and saves the word database from an external file.
     * 
     * @throws FileNotFoundException If the file is not found.
     * @throws IOException If an IO error occurs
     */
    private void initLists() throws FileNotFoundException, IOException {
        for (int i = 0; i < wordLists.length; i++) {
            wordLists[i] = loadList(WORD_FILES[i]);
        }
    }
    /**
     * Loads a {@code List} from the specified {@code File}.
     * @param saveLocation The location of the list of words.
     * @return A {@code List} of words from the text file.
     * @throws FileNotFoundException
     * @throws IOException 
     */
    private List<String> loadList(File saveLocation) throws FileNotFoundException, IOException {
        List<String> list = new LinkedList<String>();
        BufferedReader in = new BufferedReader(new FileReader(saveLocation));
        String currWord = null;
        while ((currWord = in.readLine()) != null) {
            if (currWord.indexOf("-") == -1) {
                list.add(currWord.toLowerCase());
            }
        }
        return list;
    }

    /**
     * Gets the single instantiation of this class.
     * @return The only {@code WordDatabase}.
     */
    public static WordDatabase getInstance() {
        return WordDatabaseHolder.INSTANCE;
    }

    /**
     * Gets the current list of words used in the current game.
     * @return The list of words.
     */
    public List<String> getList() {
        return currList;
    }

    /**
     * Holds the single instance of this class.
     */
    private static class WordDatabaseHolder {

        private static final WordDatabase INSTANCE = new WordDatabase();
    }
}
