package hangman.linguistics;

/**
 * Some additional String methods.
 * @author A MacNeil
 * @version Jan27, 2012
 */
public final class Parser {

    /** Don't let anyone instantiate this class*/
    private Parser() {
    }

    /**
     * Removes all whitespace in the given string.
     * 
     * @param str the String with whitespace
     * @return startIndex copy of the given string with all whitespace stripped
     */
    public static String trim(String str) {
        String newStr = "";
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != ' ') {
                newStr += str.charAt(i);
            }
        }
        return newStr;
    }

    /**
     * Checks how many instances of the substring is in the parent string.
     * 
     * @param str the {@code String} to be checked against
     * @param subStr the substring to check for.
     * @return the number of instances of the sub string in the parent string
     */
    public static int numberOfInstances(String str, String subStr) {
        int numInstances = 0;
        int lastInstance = 0;
        int i;
        for (i = 0, lastInstance = str.indexOf(subStr, lastInstance);
                i < str.length();
                lastInstance = str.indexOf(subStr, lastInstance + 1), i++) {

            if (lastInstance == str.indexOf(subStr) && i != 0) {
                return numInstances;
            } else if (lastInstance != -1) {
                numInstances++;
            }
        }
        return -1;
    }
}
