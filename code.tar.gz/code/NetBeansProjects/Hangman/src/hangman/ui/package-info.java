/**
 * An implementation of the game hangman,
 * with a user-friendly interface.
 */
package hangman.ui;