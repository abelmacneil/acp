package hangman.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

/**
 * The thread responsible for drawing the hangman graphic.
 * @author A MacNeil
 * @version Jan 27,2012
 */
public class AnimationThread extends Thread {

    protected static final int WIDTH = HangmanFrame.WIDTH;
    protected static final int HEIGHT = 300;
    private static final int[] GAFFLE_X = {20, 200, 110, 110, 300, 300};
    private static final int[] GAFFLE_Y = {250, 250, 250, 30, 30, 60};
    private static final int HEAD_RADIUS = 25;
    private static final int STROKE_SIZE = 5;
    private BasicStroke stroke = new BasicStroke(STROKE_SIZE, 1, 1);
    private Graphics2D g2d;
    private volatile boolean running = true;
    private boolean isDrawing = false;
    private int stage = 0;
    private int sleepTime = 10;
    private int prevY;

    /**
     * Main constructor.
     * @param comp The {@code Component} to draw on.
     */
    public AnimationThread(Component comp) {
        this.g2d = (Graphics2D) comp.getGraphics();

        this.g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON); //allows for better graphics

        this.g2d.setStroke(stroke);
        setName("Animator");
    }

    /**
     * Responsible for the animations.
     */
    @Override
    public void run() {
        this.g2d.setColor(HangmanFrame.BACKGROUND_COLOUR);
        this.g2d.fillRect(0, 0, WIDTH, HEIGHT);
        while (running) {

            //if statements to draw for each stage.
            System.out.print("");
            if (stage == 1 && isDrawing) {

                g2d.setColor(Color.black);
                g2d.drawLine(GAFFLE_X[0], GAFFLE_Y[0], GAFFLE_X[1], GAFFLE_Y[1]);
                for (int i = 2; i < GAFFLE_X.length - 1; i++) {
                    g2d.drawLine(GAFFLE_X[i], GAFFLE_Y[i], GAFFLE_X[i + 1], GAFFLE_Y[i + 1]);
                }
                isDrawing = false;



            } else if (stage == 2 && isDrawing) {

                g2d.setColor(Color.red);
                int y;
                int offset = (int) (HEAD_RADIUS * 3.35);
                for (int x = -HEAD_RADIUS; x <= HEAD_RADIUS; x++) {
                    y = (int) (sqrt(pow(HEAD_RADIUS, 2) - pow(x, 2)) + offset);
                    g2d.drawOval(x + GAFFLE_X[5], y, STROKE_SIZE, STROKE_SIZE);
                    y = -(int) (sqrt(pow(HEAD_RADIUS, 2) - pow(x, 2)) - offset);

                    g2d.drawOval(x + GAFFLE_X[5], y, STROKE_SIZE, STROKE_SIZE);
                    delay(sleepTime);
                }
                isDrawing = false;

            } else if (stage == 3 && isDrawing) {

                int y;
                for (y = GAFFLE_Y[5] + 2 * HEAD_RADIUS; y < GAFFLE_Y[5] + 2 * HEAD_RADIUS + 90; y++) {
                    g2d.drawOval(GAFFLE_X[5], y, STROKE_SIZE, STROKE_SIZE);
                    delay(sleepTime);
                }
                prevY = y;
                isDrawing = false;

            } else if (stage == 4 && isDrawing) {

                for (int x = GAFFLE_X[5], y = prevY; y < prevY + 40; x--, y++) {

                    g2d.drawOval(x, y, STROKE_SIZE, STROKE_SIZE);
                    delay(sleepTime);
                }
                isDrawing = false;

            } else if (stage == 5 && isDrawing) {

                for (int x = GAFFLE_X[5], y = prevY; y < prevY + 40; x++, y++) {

                    g2d.drawOval(x, y, STROKE_SIZE, STROKE_SIZE);
                    delay(sleepTime);
                }
                isDrawing = false;

            } else if (stage == 6 && isDrawing) {

                for (int x = GAFFLE_X[5], y = GAFFLE_Y[5] + 2 * HEAD_RADIUS + 20;
                        y < prevY - 25; x--, y++) {

                    g2d.drawOval(x, y, STROKE_SIZE, STROKE_SIZE);
                    delay(sleepTime);
                }
                isDrawing = false;

            } else if (stage == 7 && isDrawing) {

                for (int x = GAFFLE_X[5], y = GAFFLE_Y[5] + 2 * HEAD_RADIUS + 20;
                        y < prevY - 25; x++, y++) {

                    g2d.drawOval(x, y, STROKE_SIZE, STROKE_SIZE);
                    delay(sleepTime);
                }
                g2d.setFont(HangmanFrame.GAME_FONT);
                g2d.setColor(Color.blue);
                g2d.drawString("Game Over", WIDTH / 2 - (int) (3.75 * HEAD_RADIUS), HEIGHT / 2);
                isDrawing = false;

            }
        }
    }

    /**
     * Ends the current thread.
     */
    public void end() {
        this.running = false;
    }

    /**
     * Delays the current thread by the specified milliseconds.
     * @param time The sleep time in milliseconds.
     */
    private void delay(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException ex) {
        }
    }

    /**
     * Draws the next body part.
     */
    public void nextStage() {
        if (!isDrawing) {
            stage++;
            isDrawing = true;
        }
    }

    /**
     * Sets the sleep time in between frames for the animation.
     * @param sleepTime The amount of time to sleep between animations.
     */
    public void setSleepTime(final int sleepTime) {
        this.sleepTime = sleepTime;
    }
}
