package hangman.ui;

import hangman.game.Game;
import hangman.game.InvalidInputException;
import hangman.logging.ErrorLog;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * The implementation of the hangman API. Provides a
 * clear UI and allows the user many options
 * to the game.
 * 
 * @author A MacNeil
 */
public class HangmanFrame extends JFrame {

    //CONSTANTS
    protected static final String TITLE = "Hangman";
    protected static final Font GAME_FONT = new Font("Calibri", Font.BOLD, 35);
    private static final Font USED_LETTER_FONT = new Font("Calibri", Font.BOLD, 27);
    private static final File SAVE_LOCATION = new File("src/hangman/ui/Game.ser");
    protected static final Color BACKGROUND_COLOUR = new Color(192, 192, 192);
    protected static final int WIDTH = 425;
    protected static final int HEIGHT = 330;
    protected static final LookAndFeelInfo UI_TYPES[] = UIManager.getInstalledLookAndFeels();
    //VARIABLES
    private Game game;
    private ErrorLog err;
    private EventHandler evt;
    private boolean useCPU = false;
    //GUI COMPONENTS
    private HangmanMenuBar menuBar;
    private AnimationThread animator;
    private JPanel animationPnl;
    private JPanel mainPnl;
    private JPanel boxPnl;
    private JPanel buttonPnl;
    private JLabel currWordLbl;
    private JTextField guessTF;
    private int guessTFSize = 16;
    private JLabel sizeLbl;
    private JLabel usedCharsLbl;
    private JButton restartBtn;
    private JButton setWordBtn;
    private boolean useSliders = false;
    private JSlider minLengthSld;
    private JSlider maxLengthSld;

    /**
     * Default constructor, creates the UI.
     */
    public HangmanFrame() {
        super(TITLE);
        err = new ErrorLog(new File("src/hangman/ui/FrameErrors.log"), true);
        game = initGame();
        try {
            setUI(UI_TYPES[1].getName());
        } catch (Exception ex) {
            err.log(ex);
        } finally {
            setSize(2 * WIDTH, HEIGHT);
            setLocationRelativeTo(null);
        }

    }

    /**
     * Sets the UI to specified look and feel name, and initializes the GUI.
     * @param str The look and feel desired.
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws UnsupportedLookAndFeelException 
     */
    protected final void setUI(String str) throws ClassNotFoundException,
            InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
        try {
            for (int i = 0; i < UI_TYPES.length; i++) {
                if (str.equals(UI_TYPES[i].getName())) {
                    UIManager.setLookAndFeel(UI_TYPES[i].getClassName());
                }
            }
        } finally {
            menuBar = new HangmanMenuBar(this);
            if (isUsingSliders()) {
                initSliders();
            }
            initGUI();
        }
    }

    /**
     * Initializes the sliders used for 
     * changing the length of the words given.
     */
    private void initSliders() {
        minLengthSld = new JSlider(JSlider.HORIZONTAL, Game.MIN_WORD_LENGTH,
                Game.MAX_WORD_LENGTH, 5);
        maxLengthSld = new JSlider(JSlider.HORIZONTAL, Game.MIN_WORD_LENGTH,
                Game.MAX_WORD_LENGTH, 10);

        minLengthSld.setMajorTickSpacing(5);
        minLengthSld.setMinorTickSpacing(1);
        minLengthSld.setSnapToTicks(true);
        minLengthSld.setPaintLabels(true);
        minLengthSld.setPaintTicks(true);
        minLengthSld.setBackground(BACKGROUND_COLOUR);
        minLengthSld.setName("MIN");
        minLengthSld.setToolTipText("Minimum Word Length");
        minLengthSld.addChangeListener(new EventHandler());

        maxLengthSld.setMajorTickSpacing(5);
        maxLengthSld.setMinorTickSpacing(1);
        maxLengthSld.setSnapToTicks(true);
        maxLengthSld.setPaintLabels(true);
        maxLengthSld.setPaintTicks(true);
        maxLengthSld.setBackground(BACKGROUND_COLOUR);
        maxLengthSld.setName("MAX");
        maxLengthSld.setToolTipText("Maximum Word Length");
        maxLengthSld.addChangeListener(new EventHandler());
    }

    /**
     * Initializes the entire UI of the frame.
     */
    protected final void initGUI() {
        setContentPane(new Container());
        evt = new EventHandler();
        mainPnl = new JPanel(new FlowLayout());
        animationPnl = new JPanel();
        animationPnl.setBounds(WIDTH, 0, WIDTH, AnimationThread.HEIGHT);


        boxPnl = new JPanel();
        boxPnl.setLayout(new BoxLayout(boxPnl, BoxLayout.Y_AXIS));
        buttonPnl = new JPanel();
        buttonPnl.setLayout(new BoxLayout(buttonPnl, BoxLayout.X_AXIS));

        currWordLbl = new JLabel(getGame().processTurn(null));
        currWordLbl.setToolTipText(getGame().getHint());
        guessTF = new JTextField(getGuessTFSize());
        if (isUsingCPU()) {
            guessTF.setText("Please hit enter.");
        }
        if (!isUsingSliders()) {
            getGame().setDictionary(menuBar.dictType);
        }
        sizeLbl = new JLabel(getGame().getDictionarySize() + " words");
        sizeLbl.setToolTipText("The number of words currently available.");
        restartBtn = new JButton("Restart");
        restartBtn.setToolTipText("This restarts the game in progress with a new word.(Alt + R)");
        restartBtn.setMnemonic(KeyEvent.VK_R);
        setWordBtn = new JButton("Set Word");
        setWordBtn.setToolTipText("Sets a new word from the textfield.");

        buttonPnl.add(guessTF);
        buttonPnl.add(sizeLbl);
        buttonPnl.add(setWordBtn);
        buttonPnl.add(restartBtn);
        boxPnl.add(buttonPnl);
        if (isUsingSliders()) {
            boxPnl.add(minLengthSld);
            boxPnl.add(maxLengthSld);
        }

        usedCharsLbl = new JLabel(getGame().getIncorrectCharacters());
        usedCharsLbl.setToolTipText("These are the incorrectly guessed letters.");

        mainPnl.add(currWordLbl);
        mainPnl.add(boxPnl);
        mainPnl.add(usedCharsLbl);
        mainPnl.setBounds(0, 0, WIDTH, HEIGHT);
        add(mainPnl);
        add(animationPnl);


        guessTF.addActionListener(evt);
        setWordBtn.addActionListener(evt);
        restartBtn.addActionListener(evt);
        addWindowListener(evt);

        currWordLbl.setFont(GAME_FONT);
        usedCharsLbl.setFont(USED_LETTER_FONT);
        usedCharsLbl.setForeground(Color.red);
        buttonPnl.setBackground(BACKGROUND_COLOUR);
        boxPnl.setBackground(BACKGROUND_COLOUR);
        mainPnl.setBackground(BACKGROUND_COLOUR);
        animationPnl.setBackground(BACKGROUND_COLOUR);
        setBackground(BACKGROUND_COLOUR);


        setJMenuBar(menuBar);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
    }

    /**
     * Initializes the game via the serialization process,
     * if the {@code Game} cannot be loaded, it returns a new {@code Game}.
     * @return The  {@code Game} to be played.
     */
    private Game initGame() {
        Game g = loadGame();

        return (g == null) ? new Game() : g;
    }

    /**
     * Saves the current {@code Game} via the serialization process.
     */
    protected void saveGame() {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(SAVE_LOCATION));
            oos.writeObject(this.getGame());
            oos.close();
        } catch (Exception ex) {
            err.log(ex);
        }
    }

    /**
     * Loads a new game {@code Game} via the serialization process.
     * @return The {@code Game} saved from the previous play,
     *         if the game cannot be loaded it returns null.
     */
    private Game loadGame() {
        ObjectInputStream ois = null;
        Game g = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(SAVE_LOCATION));
            g = (Game) ois.readObject();
            ois.close();
        } catch (Exception ex) {
            err.log(ex);
            return null;
        }
        return g;
    }

    /**
     * Sets whether or not to use the 
     * {@code CPU} to process turns.
     * @param bool The state of the {@code CPU}.
     */
    protected void setCPU(boolean bool) {
        setUseCPU(bool);
        System.out.println(isUsingCPU());
        if (bool) {
            guessTF.setText("Please hit enter.");
        } else {
            guessTF.setText("");
        }
    }

    /**
     * Sets the range for minimum and maximum word length.
     */
    private void setRange() {
        System.out.println("setRange");
        try {
            if (minLengthSld.getValue() > maxLengthSld.getValue()) {
                guessTF.setText("Incorrect Range.");
                return;
            }
            game = new Game(minLengthSld.getValue(), maxLengthSld.getValue(), menuBar.dictType);
            initGUI();

        } catch (InvalidInputException ex) {
            guessTF.setText(ex.getMessage());
        }
    }

    /**
     * Resets the current game in progress.
     */
    protected void resetGame() {
        if (!isUsingSliders()) {
            game = new Game(menuBar.dictType);
            initGUI();
        } else {
            setRange();
        }
    }

    /**
     * Resets the current thread used for animating.
     */
    private void resetAnimator() {
        if (animator != null) {
            getAnimator().end();
        }
        animator = new AnimationThread(animationPnl);
        getAnimator().start();
    }

    /**
     * Gets the current size of the text field.
     * @return the guess Text Field Size
     */
    protected int getGuessTFSize() {
        return guessTFSize;
    }

    /**
     * Sets the size of the text field.
     * @param guessTFSize the guessTFSize to set
     */
    protected void setGuessTFSize(int guessTFSize) {
        this.guessTFSize = guessTFSize;
    }

    /**
     * Whether or not to use the CPU to process turns.
     * @return Whether or not to use the CPU
     */
    protected boolean isUsingCPU() {
        return useCPU;
    }

    /**
     * Whether or not to use the CPU to process turns.
     * @param useCPU Whether or not to use the CPU
     */
    protected void setUseCPU(boolean useCPU) {
        this.useCPU = useCPU;
    }

    /**
     * Whether or not to show the sliders for max and min word length.
     * @return Whether or not to show the sliders for max and min word length.
     */
    protected boolean isUsingSliders() {
        return useSliders;
    }

    /**
     * Whether or not to show the sliders for max and min word length.
     * @param useSliders Whether or not to show the sliders for max and min word length.
     */
    protected void useSliders(boolean useSliders) {
        this.useSliders = useSliders;
    }

    /**
     * Gets the current thread used for animation.
     * @return the current animation thread.
     */
    protected AnimationThread getAnimator() {
        return animator;
    }

    /**
     * Gets the game currently in progress.
     * @return the game currently in progress.
     */
    protected Game getGame() {
        return game;
    }

    /**
     * Handles events generated in the frame.
     */
    private class EventHandler extends WindowAdapter implements ActionListener, ChangeListener {

        /**
         * A {@code TimerTask} used for clearing the Text field.
         */
        class ClearTF extends TimerTask {

            @Override
            public void run() {
                guessTF.setText("");
            }
        }

        @Override
        public void windowClosing(WindowEvent e) {
            saveGame();
            animator.end();
        }

        @Override
        public void windowOpened(WindowEvent e) {
            resetAnimator();
            repaint();
        }

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == guessTF) {
                try {
                    String temp = null;
                    if (isUsingCPU()) {
                        try {
                            temp = getGame().processCPUTurn();
                            guessTF.setText("Please hit enter.");
                        } catch (IndexOutOfBoundsException ex) {
                            resetGame();
                            return;
                        }
                    } else {
                        temp = getGame().processTurn(guessTF.getText());
                    }

                    guessTF.setText("");
                    if (getGame().isOver()) {
                        if (getGame().getUnknownWord().indexOf("Lost:") != -1) {
                            getAnimator().nextStage();
                        }
                        guessTF.setText("Game over.");
                        guessTF.setEditable(false);
                        guessTF.removeActionListener(this);
                    }
                    currWordLbl.setText(temp);

                } catch (InvalidInputException ex) {
                    guessTF.setText(ex.getMessage());
                    if (ex.getMessage() != null) {
                        if (ex.getMessage().indexOf("in the word") != -1) {
                            getAnimator().nextStage();
                        }
                        if (!isUsingCPU()) {
                            Timer t = new Timer();
                            ClearTF task = new ClearTF();
                            t.schedule(task, 1000);
                        }
                    }

                }
                usedCharsLbl.setText(getGame().getIncorrectCharacters() + "");
                if (isUsingCPU()) {
                    guessTF.setText("Please hit enter.");
                }
            } else if (ae.getSource() == setWordBtn) {
                try {
                    game = new Game(guessTF.getText());
                    initGUI();
                } catch (InvalidInputException ex) {
                    guessTF.setText(ex.getMessage());
                }
            } else if (ae.getSource() == restartBtn) {
                resetGame();
                resetAnimator();
            }
        }

        @Override
        public void stateChanged(ChangeEvent e) {
            setRange();
        }
    }

    public static void main(String[] args) {
        HangmanFrame frame = new HangmanFrame();
    }
}
