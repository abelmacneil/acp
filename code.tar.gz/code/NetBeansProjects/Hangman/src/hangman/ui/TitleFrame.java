package hangman.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Math.cos;
import static java.lang.Math.PI;
import static java.lang.Math.sin;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * Greets the user with an attractive animation.
 * @author A MacNeil
 */
public class TitleFrame extends JFrame {

    private static final int WIDTH = 425;
    private static final int HEIGHT = 380;
    private static JButton startBtn;

    /**
     * Main constructor to create a new welcoming screen.
     */
    public TitleFrame() {
        super(HangmanFrame.TITLE);
        setLayout(null);
        startBtn = new JButton("Start");
        startBtn.setVisible(false);
        startBtn.setBounds(30, 300, 100, 30);
        startBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {

                HangmanFrame hangmanFrame = new HangmanFrame();
                dispose();
            }
        });

        add(startBtn);

        setBackground(Color.BLACK);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(WIDTH, HEIGHT);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
    }

    /**
     * Draws an opening animation concurrently.
     */
    private static class Animator extends Thread {

        private Graphics2D g2d;
        private static final int STROKE_SIZE = 10;
        private BasicStroke stroke = new BasicStroke(STROKE_SIZE, 1, 1);
        private boolean running = true;
        private final double INC = 0.0025;
        private final Random RNG = new Random();
        private final int COEFFICIENT = 65;
        private final Font TITLE_FONT = new Font("Calibri", Font.BOLD, 55);

        /**
         * Creates a new Animator with a specified component to draw on.
         * @param comp THe component to draw on.
         */
        private Animator(Component comp) {
            g2d = (Graphics2D) comp.getGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON); //allows for better graphics

            g2d.setStroke(stroke);
            g2d.setFont(TITLE_FONT);
        }

        /**
         * Begins the thread.
         */
        @Override
        public void run() {
            Color randCol1, randCol2;
            GradientPaint randPaint;
            int count = 0;
            g2d.setColor(Color.lightGray);
            g2d.fillRect(0, 0, WIDTH + 10, HEIGHT + 10);
            while (running) {

                //sets random colours.
                randCol1 = new Color(RNG.nextInt(255), RNG.nextInt(255), RNG.nextInt(255));
                randCol2 = new Color(RNG.nextInt(255), RNG.nextInt(255), RNG.nextInt(255));
                randPaint = new GradientPaint(0, 0, randCol1, WIDTH, HEIGHT, randCol2, false);
                g2d.setPaint(randPaint);
                //draws a sine function and two circles using trigonometry.
                for (double x = 0; x <= 2.2 * PI; x += INC) {

                    g2d.fillOval((int) (COEFFICIENT * (x)), 200 + (int) (COEFFICIENT * sin(x)), STROKE_SIZE, STROKE_SIZE);
                    g2d.fillOval(100 + (int) (COEFFICIENT * cos(x)), 150 + (int) (COEFFICIENT * sin(x)),
                            STROKE_SIZE, STROKE_SIZE);
                    g2d.fillOval(300 + (int) (COEFFICIENT * cos(x)), 250 + (int) (COEFFICIENT * sin(x)),
                            STROKE_SIZE, STROKE_SIZE);
                }

                if (count == 0) {
                    g2d.setColor(Color.black);
                    g2d.fillRect(0, 0, WIDTH + 10, HEIGHT + 10);
                    g2d.setPaint(randPaint);
                    count++;
                    startBtn.setVisible(true);
                }
                g2d.drawString(HangmanFrame.TITLE, 190, 100);
            }
        }
    }

    /**
     * Initializes the frame.
     */
    public static void init() {
        TitleFrame frame = new TitleFrame();
        Animator animator = new Animator(frame);
        animator.start();
    }

    public static void main(String args[]) {
        init();
    }
}
