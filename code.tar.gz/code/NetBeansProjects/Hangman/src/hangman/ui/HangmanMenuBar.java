package hangman.ui;

import hangman.game.Game;
import hangman.linguistics.WordDatabase;
import hangman.logging.ErrorLog;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * The menu bar containing options and help pages.
 * @author A MacNeil
 * @version Jan 27.2012
 */
public class HangmanMenuBar extends JMenuBar {

    //VARIABLES
    private WordDatabase database = WordDatabase.getInstance();
    protected int dictType;
    private static int currUIType = 1;
    private ErrorLog err;
    //GUI COMPONENTS
    private HangmanFrame frame;
    private JMenu fileMenu;
    private JMenuItem saveItem;
    private JMenu optionMenu;
    private JCheckBoxMenuItem cpuBox;
    private JCheckBoxMenuItem slidersBox;
    private JCheckBoxMenuItem animationBox;
    private JMenu sleepTimeMenu;
    private JSlider sleepTimeSld;
    private JMenu setDictMenu;
    private ButtonGroup dictBtnGrp;
    private JRadioButtonMenuItem[] dictOptionItems = new JRadioButtonMenuItem[Game.DICT_TYPES.length];
    private String[] dictOptionText = {
        "Simple: " + database.getSize(Game.DICT_TYPES[0]) + " words.",
        "Complex: " + database.getSize(Game.DICT_TYPES[1]) + " words.",
        "Food: " + database.getSize(Game.DICT_TYPES[2]) + " words."};
    private JMenu setUIMenu;
    private ButtonGroup UIBtnGrp;
    private JRadioButtonMenuItem[] UIOptionItems = new JRadioButtonMenuItem[HangmanFrame.UI_TYPES.length];
    private JMenu searchMenu;
    private JLabel searchLbl;
    private JTextField searchTF;
    private JTextArea searchTA;
    private JScrollPane searchSP;
    private JMenuItem helpBtn;

    /**
     * Main constructor to create a new menu bar.
     * @param frame The frame used to change the state of certain Components.
     */
    public HangmanMenuBar(HangmanFrame frame) {
        super();
        err = new ErrorLog("src/hangman/ui/MenuBarErrors.log");
        this.frame = frame;
        dictType = frame.getGame().getDictionaryType();
        initMenu();
    }

    /**
     * Initializes the bar and adds components to the screen.
     */
    private void initMenu() {
        fileMenu = new JMenu("File");
        saveItem = new JMenuItem("Save and exit");
        saveItem.addActionListener(new EventHandler());
        fileMenu.add(saveItem);

        optionMenu = new JMenu("Options");
        cpuBox = new JCheckBoxMenuItem("Computer");
        cpuBox.setSelected(frame.isUsingCPU());
        cpuBox.addItemListener(new EventHandler());

        slidersBox = new JCheckBoxMenuItem("Show word length sliders");
        slidersBox.setSelected(frame.isUsingSliders());
        slidersBox.addItemListener(new EventHandler());

        animationBox = new JCheckBoxMenuItem("Show animation");
        animationBox.setSelected(true);
        animationBox.addItemListener(new EventHandler());

        sleepTimeMenu = new JMenu("Set animation sleep time");
        sleepTimeSld = new JSlider(JSlider.HORIZONTAL, 0, 20, 10);
        sleepTimeSld.setMajorTickSpacing(5);
        sleepTimeSld.setMinorTickSpacing(1);
        sleepTimeSld.setSnapToTicks(true);
        sleepTimeSld.setPaintLabels(true);
        sleepTimeSld.setPaintTicks(true);
        sleepTimeSld.setToolTipText("Sleep time for animations.");
        sleepTimeSld.addChangeListener(new EventHandler());
        sleepTimeMenu.add(sleepTimeSld);

        setDictMenu = new JMenu("Set Dictionary");
        dictBtnGrp = new ButtonGroup();
        for (int i = 0; i < dictOptionItems.length; i++) {
            dictOptionItems[i] = new JRadioButtonMenuItem(dictOptionText[i]);
            setDictMenu.add(dictOptionItems[i]);
            dictBtnGrp.add(dictOptionItems[i]);
            dictOptionItems[i].addActionListener(new EventHandler());
        }
        dictOptionItems[frame.getGame().getDictionaryType()].setSelected(true);

        setUIMenu = new JMenu("Set Interface");
        UIBtnGrp = new ButtonGroup();
        for (int i = 0; i < HangmanFrame.UI_TYPES.length; i++) {
            UIOptionItems[i] = new JRadioButtonMenuItem(HangmanFrame.UI_TYPES[i].getName());
            setUIMenu.add(UIOptionItems[i]);
            UIBtnGrp.add(UIOptionItems[i]);
            UIOptionItems[i].addActionListener(new EventHandler());
        }
        UIOptionItems[currUIType].setSelected(true);

        optionMenu.add(cpuBox);
        optionMenu.add(slidersBox);
        optionMenu.add(animationBox);
        optionMenu.add(sleepTimeMenu);
        optionMenu.add(setDictMenu);
        optionMenu.add(setUIMenu);

        searchMenu = new JMenu("Search");
        searchLbl = new JLabel("Enter the word you want to look up.");
        searchTF = new JTextField(10);
        searchTF.addActionListener(new EventHandler());
        searchTA = new JTextArea(2, 2);
        searchTA.setEditable(false);
        searchTA.setLineWrap(true);
        searchSP = new JScrollPane(searchTA);
        searchMenu.add(searchLbl);
        searchMenu.add(searchTF);
        searchMenu.add(searchSP);

        helpBtn = new JMenuItem("Help");
        helpBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                HelpFrame helpFrame = new HelpFrame();
            }
        });

        add(fileMenu);
        add(optionMenu);
        add(searchMenu);
        add(helpBtn);
    }

    /**
     * The frame containing instructions on how to play the game.
     */
    private class HelpFrame extends JFrame {

        JTextArea helpTA;
        JScrollPane helpSC;
        final String HELP_TEXT = " Welcome to Hangman!\n\n"
                + "Hangman is a game in which the you given an unknown word to guess. \n"
                + "They are given series of empty spaces, each representing a letter in the word. \n"
                + "The player must try to guess this word before the “hangman” is drawn. \n"
                + "A piece of the man’s body is drawn every time the player incorrectly guesses a word.\n"
                + "If you guess a correct word, the letter will appear in the word,\n"
                + "along with all of the other empty spaces. \n\n"
                + "In the options menu there are several choices to enhance your game!\n"
                + "\t 1.Turn the computer on or off.\n"
                + "\t    The computer will make logiacal guesses.\n"
                + "\t 2.Show the word length sliders.\n"
                + "\t    Displays sliders that allow you to change\n"
                + "\t    the length of the words given.\n"
                + "\t 3.Show the hangman animation.\n"
                + "\t    Turning this off increases performence.\n"
                + "\t 4.Set animation sleep time.\n"
                + "\t    This changes the speed at which the animation is performed\n"
                + "\t    A higher setting is slower, while a lower settin gis faster.\n"
                + "\t 5.Set Dictionary\n"
                + "\t    Select the type of words you wish to guess.\n"
                + "\t 6.Set interface.\n"
                + "\t    Select the look and feel of the buttons, sliders and textfields.\n"
                + "In the Search bar you can look up certain words in a dictionary.\n"
                + "Enjoy!";

        /**
         * Main constructor to create a new Help screen.
         */
        HelpFrame() {
            super("Help");

            helpTA = new JTextArea(HELP_TEXT, 15, 50);
            helpTA.setEditable(false);
            helpTA.setBackground(HangmanFrame.BACKGROUND_COLOUR);
            helpTA.setFont(new Font("Calibri", Font.PLAIN, 12));
            helpSC = new JScrollPane(helpTA);

            add(helpSC);

            setLayout(new FlowLayout());
            setSize(550, 300);
            setLocationRelativeTo(null);

            setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            setResizable(false);
            setVisible(true);
        }
    }

    /**
     * Handles events generated in the menu bar.
     */
    private class EventHandler implements ActionListener, ChangeListener, ItemListener {

        Object source;

        /**
         * Handles events fired by the click of a button.
         * @param e The event fired.
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            source = e.getSource();
            if (source == saveItem) {
                frame.saveGame();
                frame.dispose();
            } else if (source == searchTF) {
                searchTA.setText(frame.getGame().getDefinition(searchTF.getText().toLowerCase()));
            }
            for (int i = 0; i < dictOptionItems.length; i++) {
                if (source == dictOptionItems[i]) {
                    dictType = Game.DICT_TYPES[i];
                    frame.getGame().setDictionary(dictType);
                    frame.resetGame();
                    frame.initGUI();
                }
            }
            for (int i = 0; i < UIOptionItems.length; i++) {
                if (source == UIOptionItems[i]) {
                    try {
                        currUIType = i;
                        if (i < 2) {
                            frame.setGuessTFSize(16);
                        } else if (i == 2) {
                            frame.setGuessTFSize(18);
                        } else {
                            frame.setGuessTFSize(25);
                        }

                        frame.setUI(HangmanFrame.UI_TYPES[i].getName());
                    } catch (Exception ex) {
                        err.log(ex);
                    }
                }
            }

        }

        /**
         * Handles events fired by radio buttons or check boxes.
         * @param e The event fired.
         */
        @Override
        public void itemStateChanged(ItemEvent e) {
            source = (JComponent) e.getItemSelectable();
            if (source == cpuBox) {
                if (e.getStateChange() == ItemEvent.DESELECTED) {
                    frame.setCPU(false);
                } else {
                    frame.setCPU(true);
                }
            } else if (source == slidersBox) {
                if (e.getStateChange() == ItemEvent.DESELECTED) {
                    frame.useSliders(false);

                } else {
                    frame.useSliders(true);
                }
                try {
                    frame.setUI(HangmanFrame.UI_TYPES[currUIType].getName());
                } catch (Exception ex) {
                    err.log(ex);
                }
            } else if (source == animationBox) {
                if (e.getStateChange() == ItemEvent.DESELECTED) {
                    frame.setSize(HangmanFrame.WIDTH, HangmanFrame.HEIGHT);
                } else {
                    frame.setSize(2 * HangmanFrame.WIDTH, HangmanFrame.HEIGHT);

                }
            }
        }

        /**
         * Handles events fired by the sliders.
         * @param e The event fired.
         */
        @Override
        public void stateChanged(ChangeEvent e) {
            frame.getAnimator().setSleepTime(sleepTimeSld.getValue());
        }
    }
}
