package hangman.game;

import hangman.linguistics.Parser;
import hangman.linguistics.WordDatabase;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import static java.util.Collections.sort;
import java.util.LinkedList;
import java.util.List;

/**
 * Provides a set of tools for implementing Hangman,
 * and is an interface to all of the classes in the hangman API.
 * 
 * @author A MacNeil
 * @see WordDatabase
 */
public class Game implements Serializable {

    private static final long serialVersionUID = 0x64ca5c730faad569L;
    /**
     * The maximum word length for the words to be guessed.
     */
    public static final int MAX_WORD_LENGTH = WordDatabase.MAX_WORD_LENGTH;
    /**
     * The minimum word length for the words to be guessed.
     */
    public static final int MIN_WORD_LENGTH = WordDatabase.MIN_WORD_LENGTH;
    /**
     * An array of the possible dictionaries to be used.
     */
    public static final int[] DICT_TYPES = {
        WordDatabase.SIMPLE, WordDatabase.COMPLEX, WordDatabase.FOOD};
    private static int MAX_GUESSES = 7;
    private transient WordDatabase database;
    private transient CPU cpu;
    private String currWord;
    private String unknownWord;
    private int badGuesses;
    private List<String> correctChars;
    private List<String> incorrectChars;
    private int dictionaryType;

    /**
     * Default constructor, creates a new game with a random word.
     */
    public Game() {
        this(null);
    }

    /**
     * Creates a new Game with the specified word.
     * @param word The word to be guessed, selected by the user.
     * @throws InvalidInputException If the specified word is not found 
     *                               in the {@code WordDatabase}.
     */
    public Game(String word) throws InvalidInputException {
        this(word, MIN_WORD_LENGTH, MAX_WORD_LENGTH, 0);
    }

    /**
     *  Creates a new Game with a specified dictionary for reference.
     * @param dictionaryType The type of dictionary to be used.
     */
    public Game(int dictionaryType) {
        this(null, MIN_WORD_LENGTH, MAX_WORD_LENGTH, dictionaryType);
    }

    /**
     * Creates a new Game with a specified minimum and maximum 
     * word length and specified dictionary for reference.
     * @param min The minimum word length.
     * @param max The maximum word length.
     * @param dictionaryType The type of dictionary to be used.
     */
    public Game(int min, int max, int dictionaryType) {
        this(null, min, max, dictionaryType);
    }

    /**
     * Main constructor for building a new game.
     * @param word The word to be guessed, selected by the user.
     * @param min The minimum word length.
     * @param max The maximum word length.
     * @param dictionaryType The type of dictionary to be used.
     */
    protected Game(String word, int min, int max, int dictionaryType) {
        database = WordDatabase.getInstance();
        if (word == null) {
            currWord = database.getRandomWord();
        } else {
            if (database.indexOf(word) != -1) {
                currWord = word.toLowerCase();
            } else {
                throw new InvalidInputException("Word not found");
            }
        }
        setDictionary(dictionaryType);
        this.setRange(min, max);
        unknownWord = "";
        badGuesses = 0;
        correctChars = new LinkedList<String>();
        incorrectChars = new LinkedList<String>();
        unknownWordInit();
        cpu = new CPU(this);

    }

    /**
     * Gets the list of characters, as a {@code String}, that the user has guessed and are incorrect
     * @return String of characters previously guessed by the user.
     */
    public String getIncorrectCharacters() {
        sort(incorrectChars);
        String list = incorrectChars.toString();
        list = list.replace("[", "");
        list = list.replace("]", "");
        return list;
    }

    /**
     * Gets the word to be guessed by the user in the current game.
     * @return Current word used in the game.
     */
    public String getUnknownWord() {
        return this.unknownWord;
    }

    /**
     * Processes the user's input, and checks for 
     * corresponding characters in the current word.
     * 
     * @param guess The user's guess.
     * @return The unknown string that is displayed for the user's benefit,
     *         contains correctly guessed characters and spaces in between letters.
     * @throws InvalidInputException If the user enters incorrect input or 
     *                               makes an incorrect guess.
     */
    public final String processTurn(String guess) throws InvalidInputException {

//checks for valid input
        if (guess == null) {
            return unknownWord;
        } 
        guess = guess.toLowerCase();
        if (guess.isEmpty()) {
            throw new InvalidInputException("Incorrect Input");
        } else if (guess.indexOf(" ") != -1) {
            throw new InvalidInputException();
        } else if (guess.length() > 1) {
            if (guess.equals(currWord)) {
                badGuesses = MAX_GUESSES;
                unknownWord = "Won: " + currWord;
                return unknownWord;
            } else {
                badGuesses++;
                incorrectChars.add("\"" + guess + "\"");
                if (isOver()) {
                    unknownWord = "Lost: " + currWord;
                    return unknownWord;
                }
                throw new InvalidInputException();
            }
        }
        unknownWord = Parser.trim(unknownWord);
        if (incorrectChars.indexOf(guess) != -1 || correctChars.indexOf(guess) != -1) {
            throw new InvalidInputException("Incorrect Input");
        }
        //if the user made a bad guess.
        if (Parser.numberOfInstances(currWord, guess + "") == 0) {
            if(!isValidGuess(guess.charAt(0)))
                throw new InvalidInputException("Incorrect Input.");
            badGuesses++;
            incorrectChars.add(guess);

            if (badGuesses == MAX_GUESSES) {
                unknownWord = "Lost: " + currWord;
                return unknownWord;
            }
            throw new InvalidInputException(guess + " is not in the word.");
        } else {
            //if the guess is correct add it to the word to guess.
            if(!isValidGuess(guess.charAt(0)))
                throw new InvalidInputException("Incorrect Input.");
            int lastOccurance = -1;
            char[] arr = unknownWord.toCharArray();
            correctChars.add(guess);

            for (int i = 0; i < Parser.numberOfInstances(currWord, guess); i++) {

                lastOccurance = currWord.indexOf(guess, lastOccurance + 1);
                arr[lastOccurance] = guess.charAt(0);
            }
            unknownWord = "";
            for (int i = 0; i < arr.length; i++) {
                unknownWord += arr[i] + " ";
            }
        }
        if (Parser.trim(unknownWord).equals(currWord)) {
            badGuesses = MAX_GUESSES;
            unknownWord = "Won: " + currWord;
            return unknownWord;
        }
        return unknownWord;
    }

    /**
     * Checks if the guess is a letter.
     * @param c The char to check
     * @return Whether or not the char is a letter.
     */
    private boolean isValidGuess(char c) {
        for(char i = 'a'; i < 'z'; i++)
            if(i == c)
                return true;
        return false;
    }

    /**
     * Processes the CPU's guess.
     * 
     * @return The unknown word that the CPU must try to guess.
     * @throws InvalidInputException If the guess is incorrect.
     */
    public String processCPUTurn() throws InvalidInputException {
        return processTurn(cpu.makeGuess());
    }

    /**
     * Keeps track of the current game's progress.
     * @return Whether or not the current game is over.
     */
    public boolean isOver() {
        return badGuesses == MAX_GUESSES;
    }

    /**
     * Gets the hint for the word if possible.
     * @return The definition of the current word,
     *         if the word cannot be found in the dictionary
     *         it returns "Definition not found."
     */
    public String getHint() {
        return database.getDefinition(currWord).replace(currWord + " ", "");
    }

    /**
     * Finds the definition of the specified word.
     * @param word The queried word.
     * @return the definition of the word.
     */
    public String getDefinition(String word) {
        return database.getDefinition(word);
    }

    @Override
    public String toString() {
        return currWord;
    }

    /**
     * Sets the maximum and minimum word length for the word to be guessed.
     * @param min The minimum word length.
     * @param max The maximum word length.
     */
    public final void setRange(int min, int max) {
        database.setWordLength(min, max);
    }

    /**
     * Sets the type of dictionary to be used to generate 
     * random words.
     * @param i The type of dictionary to be used.
     * @see WordDatabase
     */
    public final void setDictionary(int i) {
        dictionaryType = i;
        database.setList(i);
    }

    /**
     * Gets the type of dictionary currently used 
     * to generate random words.
     * @return The dictionary type.
     * @see WordDatabase
     */
    public int getDictionaryType() {
        return dictionaryType;
    }

    /**
     * Gets the number of words available in the game's current dictionary.
     * @return The number of words in the game's current dictionary.
     */
    public int getDictionarySize() {
        return database.size();
    }

    /**
     * Gets the list of characters, as a {@code List}, that the user has guessed.
     * @return List of correct characters previously guessed by the user.
     */
    protected List getCorrectCharacterList() {
        sort(correctChars);
        return this.correctChars;
    }

    /**
     * Gets the list of characters, as a {@code List}, that the user has guessed.
     * @return List of incorrect characters previously guessed by the user.
     */
    protected List getIncorrectCharacterList() {
        sort(incorrectChars);
        return this.incorrectChars;
    }

    /**
     * Initializes the current word that the user must guess,
     * using under spaces.
     */
    private void unknownWordInit() {
        for (int i = 0; i < currWord.length(); i++) {
            unknownWord += "_ ";
        }
    }
    
    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        ois.defaultReadObject();
        this.database = WordDatabase.getInstance();
        this.cpu = new CPU(this);
    }
}
