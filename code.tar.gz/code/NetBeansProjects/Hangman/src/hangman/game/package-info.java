/**
 * A toolkit of classes that provide a set of strategies 
 * towards implementing the game of hangman.
 */
package hangman.game;