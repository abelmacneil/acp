package hangman.game;

import hangman.linguistics.Letter;
import hangman.linguistics.LetterFrequency;
import hangman.linguistics.Parser;
import hangman.linguistics.WordDatabase;
import hangman.logging.Log;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

/**
 * Used to generate educated guesses for hangman.
 * It has about a 95% to 97% win rate.
 * This class is not to be used outside its package,
 * use the {@code  Game} class instead.
 * 
 * @author A MacNeil
 * @see Game#processCPUTurn() 
 */
public class CPU {

    private WordDatabase database;
    private Game game;
    private String wordToGuess;
    private LetterFrequency freq;
    private int counter = 0;
    protected Log log;
    private boolean logResults;

    /**
     * Constructor that creates a new CPU based
     * on the specified {@code Game}.
     * @param game The {@code Game} currently in progress.
     */
    protected CPU(Game game) {
        this(game, false);
    }

    /**
     * Main constructor for creating a new CPU.
     * @param game The {@code Game} currently in progress.
     * @param logResults Whether or not to write the CPU's 
     *                   thinking to a text file.
     */
    protected CPU(Game game, boolean logResults) {
        database = WordDatabase.getInstance();
        this.game = game;
        wordToGuess = Parser.trim(game.getUnknownWord());
        this.logResults = logResults && !game.isOver();
        if (this.logResults) {
            log = new Log(new File("src/hangman/game/cpulogs/Log[" + game + "][" + Log.getDate() + "]"));
        }
    }

    /**
     * Makes an educated guess for hangman.
     * <ul><li>It generates a list of possible choices based on
     * the unknown word's length and the correctly and incorrectly guessed letters.
     * <li>Then it finds the most common letter from that 
     * list to make an educated guess.
     * <li>If there is only one possible word left,
     * it guesses that entire word.</ul>
     * 
     * @return The CPU's guess.
     */
    protected String makeGuess() {
        //inits the vaiables and lists of possible words.
        String guess = null;
        wordToGuess = Parser.trim(game.getUnknownWord());
        List<String> correctLetters = new LinkedList<String>(game.getCorrectCharacterList());
        List<String> incorrectLetters = new LinkedList<String>(game.getIncorrectCharacterList());
        List<String> wordChoices = new LinkedList<String>(getPossibleChoices(correctLetters, incorrectLetters,
                getIndexesOf(wordToGuess, correctLetters)));
        freq = new LetterFrequency(wordChoices);
        List<Letter> choices = new LinkedList<Letter>(freq.getFrequency());

        if (logResults) {
            log.append("Guess#" + counter);
            if (wordChoices.size() > 1000) {
                log.append(wordChoices.toArray().toString().replace("java.lang.Object;", ""));
            } else {
                log.append(wordChoices);
            }
            log.append("Possibilities: " + wordChoices.size());
            log.print("INC:" + incorrectLetters + " ");
            log.append("COR:" + correctLetters);
            log.append("FREQ:" + freq);
        }
        //if there is only one possible choice left guess that word.
        if (wordChoices.size() == 1) {
            guess = wordChoices.get(0);
            if (logResults) {
                log.append(game.getUnknownWord() + ":(" + guess + "):" + counter);
                log.append("Guess:" + guess + "\n");
                log.append("Won: " + guess + "\nNo. Bad Guesses: "
                        + game.getIncorrectCharacterList().size());
            }
            return guess;
        }

        boolean isBadGuess;
        int i = 0;
        //makes sure it doesn't guess the same letter twice.
        do {
            guess = Character.toString(choices.get(i).getCharValue());
            isBadGuess = game.getIncorrectCharacterList().indexOf(guess) != -1
                    ^ game.getCorrectCharacterList().indexOf(guess) != -1;
            if (logResults) {
                log.append("<" + guess + ":" + !isBadGuess + ">");
            }
            i++;
        } while (isBadGuess);
        if (logResults) {
            log.append(game.getUnknownWord() + ":(" + guess + "):" + counter);
            log.append("Guess:" + guess + "\n");
        }
        counter++;
        return guess;
    }

    /**
     * Gets the indexes of the {@code String} for the specified 
     *  {@code List} of Letters.
     * @param str The  {@code String} to be searched.
     * @param keys The  {@code List} of characters to matched against 
     *            the  {@code String}.
     * @return    The indexes of the {@code String} for the specified 
     *            {@code List} of correct letters.
     */
    private int[] getIndexesOf(String str, List<String> keys) {
        int[] indexes = new int[keys.size()];
        for (int i = 0; i < keys.size(); i++) {
            indexes[i] = str.indexOf(keys.get(i));
        }
        return indexes;
    }

    /**
     * Gets a  {@code List} of words that might be the current 
     * word to be guessed.
     * @param goodChars The correctly guessed letters of the current {@code Game}.
     * @param badChars  The incorrectly guessed letters of the current {@code Game}.
     * @param indexes   The indexes of the correct letters.
     * @return A {@code List} of possible choices. 
     */
    private List getPossibleChoices(List<String> goodChars, List<String> badChars, int[] indexes) {
        List<String> choices = new LinkedList<String>();
        for (String possibleChoice : database.getList()) {
            if (possibleChoice.length() == wordToGuess.length()) {
                if (isValidString(possibleChoice, goodChars, badChars, indexes)) {
                    choices.add(possibleChoice);
                }
            }
        }
        return choices;
    }

    /**
     * Checks is the specified {@code String} is a possible choice.
     * @param str The {@code String} to be checked.
     * @param goodChars The correctly guessed letters of the current {@code Game}.
     * @param badChars  The incorrectly guessed letters of the current {@code Game}.
     * @param indexes   The indexes of the correct letters.
     * @return Whether or not the {@code String} is a valid choice.
     */
    private boolean isValidString(String str, List<String> goodChars, List<String> badChars, int[] indexes) {
        for (int j = 0; j < goodChars.size(); j++) {
            if (str.indexOf(goodChars.get(j)) != indexes[j]) {
                return false;
            }
        }
        for (String character : badChars) {
            if (str.indexOf(character) != -1) {
                return false;
            }
        }
        return true;
    }
}
