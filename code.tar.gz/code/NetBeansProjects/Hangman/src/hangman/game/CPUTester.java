package hangman.game;

/**
 *
 * @author Abel_2
 */
public class CPUTester {
    public static void main(String args[]) {

        Game g;
        int lost = 0;
        int i = 0;
        for ( i = 1; i < 200; i++) {
            g = new Game();
            g.setDictionary(0);
            while (!g.isOver()) {
                try {
                    g.processCPUTurn();
                   
                } catch (Exception ex) {
                }
            }
            if (g.getUnknownWord().indexOf("Lost") != -1) {
                lost++;
                System.out.println(g.getUnknownWord()+ ":"+ (Math.round(((double)lost/i)*100))+"%");
            }
        }
        System.err.println((Math.round(((double)lost/i)*100))+"%");
    }
    
}
