package hangman.game;

/**
 * Exception used to catch incorrect input from the user.
 * @author A MacNeil
 */
public class InvalidInputException extends RuntimeException {

    /**
     * Constructs a new  {@code InvalidInputException} with 
     *  a {@code null} detail message.
     */
    public InvalidInputException() {
        super();
    }

    /**
     * Constructs a new {@code InvalidInputException} with 
     *  a specified detail message.
     * @param message The detail message.
     */
    public InvalidInputException(String message) {
        super(message);
    }
}
