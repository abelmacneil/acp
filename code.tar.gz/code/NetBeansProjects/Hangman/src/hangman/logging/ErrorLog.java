package hangman.logging;

import java.io.File;

/**
 * Used to log exceptions to text-files for future reference.
 * @author A MacNeil
 */
public class ErrorLog extends Log {

    /**
     * Creates a new ErrorLog with a specified save location 
     * and whether to append to the file or not.
     * @param saveLocation Where to save the log.
     * @param append Whether or not appending is allowed to the text-file.
     */
    public ErrorLog(File saveLocation, boolean append) {
        super(saveLocation, append);
    }

    /**
     * Creates a new ErrorLog with a specified save location.
     * @param filePath Where to save the log.
     */
    public ErrorLog(String filePath) {
        super(filePath);
    }

    /**
     * Creates a new ErrorLog with a specified save location.
     * @param saveLocation Where to save the log.
     */
    public ErrorLog(File saveLocation) {
        this(saveLocation, true);
    }

    /**
     * Logs the {@code Exception} to a text file, 
     * containing the date and its StackTrace.
     * @param ex 
     */
    public void log(Exception ex) {
        append(Log.getDate() + "\n");
        append(ex.fillInStackTrace());

        for (StackTraceElement element : ex.getStackTrace()) {
            append("\t" + element);
        }
        append("\n");
    }
}
