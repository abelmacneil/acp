package hangman.logging;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Used log results and computations to text files.
 * @author A MacNeil
 */
public class Log {

    private static final Format DATE_FORMAT = new SimpleDateFormat("[yy.MM.dd.HH.mm.ss]");
    protected PrintWriter out;

    /**
     * Creates a new Log with a specified save location 
     * and whether to append to the file or not.
     * @param saveLocation Where to save the log.
     * @param append Whether or not appending is allowed to the text-file.
     */
    public Log(File saveLocation, boolean append) {
        try {
            out = new PrintWriter(new BufferedWriter(new FileWriter(saveLocation, append)));
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    /**
     * Creates a new ErrorLog with a specified save location.
     * @param saveLocation Where to save the log.
     */
    public Log(File saveLocation) {
        this(saveLocation, false);

    }

    /**
     * Creates a new ErrorLog with a specified save location.
     * @param filePath Where to save the log.
     */
    public Log(String filePath) {
        this(new File(filePath), false);
    }

    /**
     * Gets the current date with a specified format.
     * @return The current {@code Date}.
     */
    public static String getDate() {
        return DATE_FORMAT.format(new Date());
    }

    /**
     * Appends to the current text-file.
     * @param obj the Object to be written to the file.
     */
    public void append(Object obj) {
        out.append(obj + "\n");
        out.flush();
    }

    /**
     * Appends to the current text-file without moving to the next line.
     * @param obj the Object to be written to the file.
     */
    public void print(Object obj) {
        out.print(obj);
        out.flush();
    }

    /**
     * Closes the current stream.
     */
    public void close() {
        out.close();
    }
}
