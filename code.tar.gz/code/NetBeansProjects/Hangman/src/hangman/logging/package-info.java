/**
 * A small toolkit for logging computed results
 * and errors to text files.
 */
package hangman.logging;