// The "Main" class.
import hangman.ui.TitleFrame;
public class Main
{
    public static void main (String[] args)
    {
	TitleFrame.init ();
    } // main method
} // Main class
