#include <stdio.h>
#include <stdlib.h>

void q_sort (int arr[], int low, int high);
void print_arr(int arr[], int size);
void quicksort(int *arr, int n);
void mergesort(int *arr, int n);
void insertionsort(int *arr, int n);

int main (int argc, char *argv[])
{
    const int SIZE = atoi(argv[1]);
    int arr[SIZE];
    int i;
    srand(0);
    for (i = 0; i < SIZE; i++)
        arr[i] = rand() % SIZE;
    if (argc > 2)
        print_arr(arr, SIZE);
    quicksort(arr, SIZE);
    if (argc > 2)
        print_arr(arr, SIZE);
    return 0;
}

void insertionsort(int *arr, int n)
{
    int i, j;
    for (i = 1; i < n; i++) {
        int tmp = arr[i];
        for (j = i -1; j >= 0 && arr[j] > tmp; j--){
            arr[j + 1] = arr[j];
        }
        arr[j + 1] = tmp;
    }
}

void merge(int *arr, int lbegin, int lend, int rbegin, int rend)
{
    int llen = lend - lbegin;
    int rlen = rend - rbegin;

    int lhalf[llen];
    int rhalf[rlen];
    int lindex = 0;
    int rindex = 0;
    int i = 0;

    for (i = lbegin; i < lend; i++, lindex++) 
         lhalf[lindex] = arr[i];

    for (i = rbegin; i < rend; i++, rindex++) 
         rhalf[rindex] = arr[i];

    for (i = lbegin, lindex = 0, rindex = 0;
            lindex < llen && rindex < rlen;
            i++) {
        if (lhalf[lindex] < rhalf[rindex])
            arr[i] = lhalf[lindex++];
        else
            arr[i] = rhalf[rindex++];
    }

    for (; lindex < llen; i++, lindex++)
        arr[i] = lhalf[lindex];
    for (; rindex < rlen; i++, rindex++)
        arr[i] = rhalf[rindex];
}

void mergesort_rec(int *arr, int begin, int end)
{
    if (end - begin <= 1)
        return;
    int lbegin = begin;
    int lend = (begin + end)/2;
    int rbegin = lend;
    int rend = end;

    mergesort_rec(arr, lbegin, lend);
    mergesort_rec(arr, rbegin, rend);

    merge(arr, lbegin, lend, rbegin, rend);
}
void mergesort(int *arr, int n)
{
    mergesort_rec(arr, 0, n);
}
void quicksort(int *arr, int n)
{
    if (n < 2)
        return;
    int pivot = arr[n / 2];
    int *low = arr;
    int *high = arr + n - 1;
    while(low <= high) {
        if (*low < pivot) low++;
        else if (*high > pivot) high--;
        else {
            int tmp = *low;
            *low++ = *high;
            *high-- = tmp;
        }
    }
    quicksort(arr, high - arr + 1);
    quicksort(low, arr + n - low);
}

void print_arr(int arr[], int size)
{
    int i;
    for (i = 0; i < size; i++)
        printf("%d, ", arr[i]);
    printf("\n");
}
