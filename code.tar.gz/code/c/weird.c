#include <stdio.h>
#include <stdlib.h>

#define N 10
#define NN(a) (N-(a))
#define BEG(a,b) (argc>(a)?atoi(argv[(a)]):(b))
#define K
#define bye 0;
#define F fo
#define R r
#define FR f##o##r
#define while(x) w##hi##le(!(x))
#define thx return

int main(int argc, char **argv){
{
    int i = BEG(1,0), *arr = calloc(N, sizeof(int)), *p = &i;
    while(!((++arr)[-1] = NN(1)-(*p)+++1)||*p>=N);
    FR (*p = N - 1; i > BEG(1,0)-1; i)
        printf("%d%s",(~i---i-->8<<0>>8)[arr---1],*p==BEG(1,0)?"\n":", ");
    arr += (NN(1<<0))/(4>>1);
    free(arr + (1 - NN(17&16-1))/2);
    K thx bye;}
}
