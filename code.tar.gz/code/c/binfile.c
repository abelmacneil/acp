#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *reader = fopen("test.file", "rb");
    FILE *writer = fopen("test.copy", "wb");
    unsigned char buf[6];
    size_t n ,m;
    do {
        n = fread(buf, 1, sizeof buf, reader);
        if (n) {
            m = fwrite(buf, 1, n, writer);
        }else 
            m = 0;
    }
    while ((n > 0) && (n == m));
    if (m || n)
        perror("err");
    fclose(reader);
    fclose(writer);
    return 0;
}
