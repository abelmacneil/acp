#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main (int argc, char **argv)
{
  const char *filename = "data.txt";
  FILE *file = fopen(filename, "r");
  long double 
	input,
	sum = 0,
	sqsum = 0,
	mean,
	stdev;
  long long *freqs = malloc(sizeof(*freqs));
  long double *data = malloc (sizeof(*data));
  long long n = 0, i, fq, nitems = 0, curlen = 1;

  while(fscanf(file, "%Lf %Ld", &input, &fq) != EOF){
	if(n + 1 > curlen){
	  curlen <<= 1;
	  freqs = realloc(freqs, curlen * sizeof(*freqs));
	  data = realloc(data, curlen * sizeof(*data));
	}
	data[n] = input;
	freqs[n] = fq;
	nitems += fq;
	//printf("%Lf %Ld %Ld\n", data[n], freqs[n], n);
	sum += input * fq;
	n++;
  }
  mean = sum / nitems;
  for (i = 0; i < n; i++){
   	sqsum += freqs[i] * (mean - data[i]) * (mean - data[i]);
  }
  stdev = sqrtl(sqsum / n);
  printf("n = %Ld,\nmean = %.10Lf,\nstdev = %.10Lf\n",nitems, mean, stdev);
  //printf("Q1 = %Lf, \nQ2 = %Lf,\nQ3 = %Lf", data[(nitems + 1)/4], data[(nitems + 1)/2],data[3*(nitems + 1)/4]);
  close(file);
  free(freqs);
  free(data);
  return 0;
}
