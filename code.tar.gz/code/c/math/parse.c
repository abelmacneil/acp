#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define TRUE	 1
#define FALSE 	 0

double parse(char * str);
double parseOp(char * str);
int * get_op_index(char * str, int * nops);
char * edmas(char * str, char * ops, int * op_index, int nops);
int is_num(char c);
int is_all_num(char * str);
char * strip_whitespace(char * str);


int main(int argc, char ** argv)
{
	printf("\n%s = %f\n",argv[1], parse(strip_whitespace(argv[1])));
	return 0;
}

double parse(char * str)
{
	//printf("[%s]", str);
	if(is_all_num(str)){
		return atof(str);
	}
	int i = 0;
	char * buf = malloc(strlen(str));
	char op;
	
	int nops = 0;
	
	int * op_index = get_op_index(str, &nops);

	double num1,num2, result;
	
	
	edmas(str, "^`", op_index, nops);
	op_index = get_op_index(str,&nops);
	edmas(str, "*/", op_index, nops);
	op_index = get_op_index(str,&nops);
	edmas(str, "+-", op_index, nops);	
	return parse(str);
}

int * get_op_index(char * str, int * nops)
{
	int i = 0;
	*nops = 0;
	int * op_index = calloc(2, sizeof(int));

	while (str[i] != '\0'){
		
		if (!(is_num(str[i]) || str[i] == '.')){
			//printf("/%c/",str[i]);
			op_index[*nops] = i;
			(*nops)++;
			op_index = realloc(op_index, (*nops + 1) * sizeof(int));
		}
		i++;
	}
	return op_index;
}
char * edmas(char * str, char ops[static 2], int * op_index, int nops)
{	
	int i, len, begin, end;
	char * buf = malloc(strlen(str));
	for(i = 0; i < nops; i++){
		if (str[op_index[i]] == ops[0] || str[op_index[i]] == ops[1]){
			//printf(":%c:%d:%d:", str[op_index[i]], op_index[i],nops);
			begin = 0, end = 0, len = 1024;
			if (i != 0)
				begin = op_index[i - 1] + 1;

			if (i + 1 >= nops)
				end = len - 1;
			else
		    	end = op_index[i + 1] - 1;

			char * half1 = malloc(len + 1), * half2 = malloc(len + 1);

			strncpy(half1, str, begin);
			strncpy(buf, str + begin, end + 1 );

			strncpy(half2, str + end + 1, len);

			//printf("{%s}{%s}{%s} ",half1, buf,half2);
			sprintf(buf,"%f", parseOp(buf));
			strcat(half1, buf);
			strcat(half1, half2);
			
			strcpy(str, half1);
			//printf("(%s)", str);
			op_index = get_op_index(str, &nops);
			i = 0;
		}
	}
}
double parseOp(char * str)
{
	double result, num1, num2;
	int i = 0;
	char * buf = malloc(1024);
	char op;
	while(is_num(str[i]) || str[i] == '.'){
		i++;
	}
	strncpy(buf, str, i);
	num1 = atof(buf);
	strncpy(buf, str + i + 1, strlen(str));
	num2 = atof(buf);
	op = str[i];
	if (op == '+')
		result = (num1 + num2);
	else if (op == '-')
	  result = (num1 - num2);
	else if (op == '*')
	  result = (num1 * num2);
	else if (op == '/')
	  result = (num1 / num2);
	else if (op == '^')
	  result = pow(num1 , num2);
	return result;
}

int is_num(char c)
{
	int i;
	for (i = 0; i  <= 9; i++){
		if ((c - '0') == i)
			return TRUE;
	}
	return FALSE;
}

int is_all_num(char * str){
	int i;
	for(i = 1; i < strlen(str); i++){
		if(!is_num(str[i]) && str[i] != '.')
			return FALSE;
	}
	return TRUE;
}

char * strip_whitespace(char * str)
{
	char * new = malloc(strlen(str) + 1);
	int i = 0, nwhite = 0;

	while (str[i] != '\0'){
		if (str[i] != ' '){
			new[i - nwhite] = str[i];
		}else{
			nwhite++;
		}
		i++;
	}
	return new;
}


