#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define TRUE	 1
#define FALSE 	 0

long double parse(char * str);
long double parseOp(char * str);
int * get_op_index(char * str, int * nops);
char * edmas(char * str, char * ops, int * op_index, int nops);
int is_num(char c);
int is_all_num(char * str);
char * strip_whitespace(char * str);


int main(int argc, char ** argv){
	//printf("%s = %Lf\n",argv[1], parse(strip_whitespace(argv[1])));
	printf("%Lf\n", parse("2+2"));
	return 0;
}

long double parse(char * str){

	//printf("[%s]\n", str);
	if(is_all_num(str)){
		return strtold(str, NULL);
	}
	int i = 0;
	char * buf = malloc(strlen(str));
	char op;
	
	int nops = 0;
	
	int * op_index = get_op_index(str, &nops);

	long double num1,num2, result;
	
	
	edmas(str, "^`", op_index, nops);
	edmas(str, "*/", op_index, nops);

	edmas(str, "+-", op_index, nops);

	return parse(str);
}
int * get_op_index(char * str, int * nops){
	int i = 0;
	*nops = 0;
	int * op_index = calloc(2, sizeof(int));

	while (str[i] != '\0'){
		
		if (!is_num(str[i]) && str[i] != '.'){
			op_index[*nops] = i;
			(*nops)++;
			op_index = realloc(op_index, (*nops + 1) * sizeof(int));

		}
		i++;
	}
	return op_index;
}
char * edmas(char * str, char * ops, int * op_index, int nops){
	
	int i;
	char * buf = malloc(strlen(str));
	for(i = 0; i < nops; i++){
		printf("%s %c", str, str[op_index[i]]);
		if (str[op_index[i]] == ops[0] || str[op_index[i]] == ops[1]){
			printf("<%s>", ops);
			int begin, end1 = 0, end2;
			if (i == 0)
				begin = 0;
			else
				begin = op_index[i - 1];
			if (i + 1 >= nops){
				end1 = end2 = strlen(str);
			}
			else if(i  + 1< nops){
				end1 = op_index[i + 1] - 2;
                end2 = end1 + 2;
				
			}
			if(i != 0){
					begin++;
				}else
					end1 += 2;
			

			//printf("$%c$", str[begin]);
			
			char * half1 = malloc(20), * half2 = malloc(20);

			strncpy(half1, str, begin);
			//printf("%d-%d", begin, end2);
			//getchar();
			strncpy(buf, str + begin, end1 );

			strncpy(half2,str + end2, strlen(str));

			//printf("{%s}{%s}{%s} ",half1, buf,half2);
			sprintf(buf,"%Lf", parseOp(buf));

       		strcat(half1, buf);

			strcat(half1, half2);

			
			getchar();
			//str = 0;
			str = malloc(strlen(half1) + 1);
			strcpy(str, half1);
			//op_index = get_op_index(str, &nops);
			
			
			//getchar();
		}
		printf("(%s)", str);
		//printf("%c", str[op_index[i]]);
	}
}
long double parseOp(char * str){
	long double result, num1, num2;
	int i = 0;
	char * buf = malloc(256);
	char op;
	while(is_num(str[i]) || str[i] == '.'){
		i++;
	}
	strncpy(buf, str, i);
	num1 = strtold(buf, NULL);
	strncpy(buf, str + i + 1, strlen(str));
	num2 = strtold(buf, NULL);
	op = str[i];
	if (op == '+')
		result = (num1 + num2);
	else if (op == '-')
        result = (num1 - num2);
	else if (op == '*')
        result = (num1 * num2);
	else if (op == '/')
        result = (num1 / num2);
	else if (op == '^')
        result = powl(num1 , num2);
	return result;
}

int is_num(char c){
	int i;
	for (i = 0; i  <= 9; i++){
		if ((c - '0') == i)
			return TRUE;
	}
	return FALSE;
}

int is_all_num(char * str){
	int i;
	for(i = 1; i < strlen(str); i++){
		if(!is_num(str[i]) && str[i] != '.')
			return FALSE;
	}
	return TRUE;
}

char * strip_whitespace(char * str){
	char * new = malloc(strlen(str));
	int i = 0, nwhite = 0;

	while (str[i] != '\0'){
		if (str[i] != ' '){
			new[i - nwhite] = str[i];
		}else{
			nwhite++;
		}
		i++;
	}

	return new;
}


