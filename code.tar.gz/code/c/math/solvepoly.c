#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

double f(double x, double coeff[], int degree);

int main(int argc, char ** argv){

	double coeffs[argc - 1];
	double start = -10, end = 10,x,y;
	int i, nsolutions = 0,count = 0;;
	double error = 0.01;
	double step = 0.01;
	for(i = 1; i < argc ; i++){
	
		if(strcmp(argv[i], "-e") == 0){
			error = atof(argv[i + 1]);
			i++;
		}
		else if (strcmp(argv[i], "-s") == 0){
			step = atof(argv[i + 1]);
			error = step * 3;
			i++;
		}
		else if (strcmp(argv[i], "-se") == 0){
			step = atof(argv[i + 1]);
			error = step;
			i++;
		}
		else if (strcmp(argv[i], "-r") == 0){
			start = atof(argv[i + 1]);
			end = atof(argv[i + 2]);
			i += 2;
		}
		else {
			coeffs[count] = atof(argv[i]);
			count++;
		}
		
	}
	for (x = start; x <= end; x += step){
		y = f(x,coeffs, count - 1);
		if (y < error && y > -error){
			printf("x%d = %+f\n", nsolutions + 1,x);
			nsolutions++;
		}
	}
	if (nsolutions == 0){
		printf("No solutions from %f to %f.\n",start, end);
	}
	return 0;
}
double f(double x, double coeff[], int degree){
	double sum = 0;
	int i;
	for (i = degree; i >= 0; i--){
		sum += coeff[degree - i] * pow(x, i);
	}
	return sum;
}
