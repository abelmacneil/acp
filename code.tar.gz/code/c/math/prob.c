#include <stdio.h>
#include <math.h>

long double factorial (int);
long double C(int,int);
long double plane_prob(int, double, double);
long double powld(long double, long);

int main(int argc, char ** argv){
  printf("%.11Lf\n", plane_prob(8, 0.5,0.5));
  return 0;
}

long double factorial (int n){
  int i;
  if(n == 0)
    return 1;
  long double fac = 1;
  for(i = 2; i <= n; i++)
    fac *= i;
  return fac;
}
long double C(int n, int r){
  return factorial(n)/(factorial(n - r) * factorial(r));
}
long double powld(long double base, long exp){
  long double result = 1;
  long i;
  for(i = 0; i < exp; i++){
    result *= base;
  }
  return result;
}

long double plane_prob(int nengines, double percent_fail, double percent_needed){
  long double prob = 0;
  int i;
  for(i = nengines; i >= nengines * percent_needed; i--){
    prob += C(nengines,nengines - i) *
      powld(1 - percent_fail, i) * 
      powld(percent_fail, nengines - i);
    //printf("%Lf\n",prob);
  }
  return prob;
}
