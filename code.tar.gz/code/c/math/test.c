#include <stdlib.h>
#include <stdio.h>

int main(){
	printf("%Lf", strtold("300000000.0",NULL));
return 0;
}
