#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char ** argv){

	if (argc != 4){
		printf("Incorrect number of args.\n");
		exit(0);
	}
	
	double a = atof(argv[1]),
		b = atof(argv[2]),
		c = atof(argv[3]);
		
	double dis = b * b - 4 * a * c;
	double x;
	if (dis < 0){
		printf("x1 = %lf + %lfi\n",-b/(2 * a), sqrt(-dis)/(2 * a));
		printf("x1 = %lf - %lfi\n",-b/(2 * a), sqrt(-dis)/(2 * a));
	}else {
		x = (-b + sqrt(dis))/(2 * a);
		printf("x1 = %lf\n", x);
		x = (-b - sqrt(dis))/(2 * a);
		printf("x2 = %lf\n", x);
	}
	
	return 0;
}
