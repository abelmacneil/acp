#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char * strrev (char * str);

int main (int argc, char ** argv){
    if (argc == 2){
        strrev(argv[1]);
        printf("%s\n", argv[1]);
    }else{
        printf("USAGE: %s STRING\nReverses the specified string.\n", argv[0]);
    }
    return 0;
}

char * strrev (char * str){
    char * start = str;
    char * end = str + strlen(str) - 1;
    char  tmp;
    while(end > start){
        *start ^= *end;
        *end ^= *start;
        *start ^= *end;
        end--;
        start++;
    }
    return end;
}
