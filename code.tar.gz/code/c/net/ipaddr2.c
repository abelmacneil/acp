#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h> /* for strncpy */

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <arpa/inet.h>


char *get_ip(char *devname)
{

    int fd;
    struct ifreq ifr;


    fd = socket(AF_INET, SOCK_STREAM, 0);

    /* I want to get an IPv4 IP address */
    ifr.ifr_addr.sa_family = AF_INET;

    /* I want IP address attached to "eth0" */
    strncpy(ifr.ifr_name, devname, IFNAMSIZ-1);

    ioctl(fd, SIOCGIFADDR, &ifr);

    close(fd);
    char *res = malloc(INET_ADDRSTRLEN);

    /* display result */
    inet_ntop(AF_INET, &(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr),
            res, INET_ADDRSTRLEN);
    return res;
}

int main(int argc, char **argv)
{
    int fd;
    struct ifreq ifr;
    char *devname = malloc(IFNAMSIZ);

    if (argc != 2) 
        strncpy(devname, "wlan0", IFNAMSIZ);
    else
        strncpy(devname, argv[1], IFNAMSIZ);

    
    /* display result */
    char *ip = get_ip(devname);
    printf("%s\n", ip);

    free(devname);
    free(ip);
    return 0;
}
