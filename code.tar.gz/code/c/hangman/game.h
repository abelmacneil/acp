#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static const int GAME_WON 	= 2;
static const int GAME_LOST 	= 1;

typedef struct Game {
	char *word_to_guess;
	char *hidden_word;
	int word_to_guess_len;
	int status; // GAME_WON, GAME_LOST, OR ZERO
	char bad_guesses[7];
	int num_bad_guesses;
	char *good_guesses;
	int num_good_guesses;
} Game;

char** load_words(char *filename, char **words);
Game * game_initialize(char *word);
void game_process_guess(Game * g, char guess);
int game_check_won(Game *g);
void print_arr(char *arr,int len);


