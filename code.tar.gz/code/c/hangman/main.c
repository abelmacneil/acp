#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "game.h"

int main(int argc, char **argv)
{
	char **w;
	char ** s = load_words("dict.txt",w);
	int i;
	//printf("%s\n",w[15]);
	free(w);
	/*srand(time(NULL));
	Game *g = game_initialize(w[0]);
	char *buf = malloc(g->word_to_guess_len);
	int tmp;
	printf("%s\n",g->hidden_word);
	while(g->status == 0) {
		tmp = getchar();
		getchar();
		game_process_guess(g,(char)tmp);
		printf("%s : ",g->hidden_word);
		print_arr(g->bad_guesses, g->num_bad_guesses);
	}*/
	return 0;
}

