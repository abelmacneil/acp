#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"

char **load_words(char *filename, char **words)
{
	const MAX_LEN = 40;
	FILE * file = fopen(filename, "r");
	words = malloc(2);
	char *buf = malloc(MAX_LEN);
	int i = 0;
	printf("%d\n",sizeof *buf);
	getchar();
	words[0] = malloc(MAX_LEN);
	while(fgets(words[i],MAX_LEN,file) != NULL) {
		char *p;
		if ((p = strchr(buf,'\n')) != NULL)
			*p = '\0';
		//strcpy(words[i],buf);
		words = realloc(words, (i+1)*MAX_LEN + 3);
		//printf("%s\n",words[i]);
		i++;
		words[i] = malloc(MAX_LEN);
	}
	printf("DONE\n");
	free(buf);
	close(file);
	return words;
}



Game *game_initialize(char *word) 
{
	Game *g = malloc(sizeof(*g));
	g->word_to_guess_len = strlen(word);
	g->hidden_word = malloc(g->word_to_guess_len * 2 + 1);
	int i;
	for (i = 0; i < g->word_to_guess_len * 2; i += 2) {
		g->hidden_word[i] = '_';
		g->hidden_word[i+1] = ' ';
	}
	g->word_to_guess = strdup(word);
	g->good_guesses = malloc(1);

	return g;
}

void game_process_guess(Game * g, char guess) 
{
	int i, is_good = 0;
	for (i = 0; i < g->word_to_guess_len; i++) {
		if (g->word_to_guess[i] == guess) {
			is_good = 1;
			g->hidden_word[i*2] = guess;
			/*g->good_guesses  = 
				realloc(g->good_guesses,g->num_good_guesses + 2);
			g->good_guesses[g->num_good_guesses++] = guess; */
		}
	}
	if(is_good == 0) {
		g->bad_guesses[g->num_bad_guesses++] = guess; 
	}
	if (g->num_bad_guesses >= 7) {
		g->status = GAME_LOST;
	} else if (game_check_won(g)) {
		g->status = GAME_WON;
	}
}
int game_check_won(Game *g)
{
	int i;
	for (i = 0; i < g->word_to_guess_len; i++) {
		if (g->word_to_guess[i] != g->hidden_word[i*2])
			return 0;
	}
	return 1;
}
void print_arr(char *arr,int len) 
{
	int i;
	for(i = 0; i < len; i++)
		printf("%c,",arr[i]);
	printf("\n");
}
