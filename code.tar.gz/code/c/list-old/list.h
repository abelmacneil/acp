#ifndef LIST_H_INCLUDED
#define LIST_H_INCLUDED

typedef struct List {
	struct List *next;
	int value;
} List;
/*Pushes the value to begining of the list. O(1)*/
void list_push(List **list, int val);
/*Pops off the first element of the list. O(1)*/
int list_pop(List **lst);
/*Adds and element to the end of the list. O(n)*/
void list_add(List **lst, int val);
/* Removes the last element of the list: O(n)*/
int list_remove(List **lst);
/*Gets the size of the list. O(n)*/
long list_size(List *lst);
/*Gets the element of the lsit at the index. O(n)*/
int list_at(List *lst, int index);
/*Reverses the list. O(n)*/
void list_reverse(List **lst);
/*Appends two lists together, storing the result in the first list. O(n)*/
void list_append(List *lst1, List *lst2);
/*Copies the given list, and returns a dynamically allocated list. O(n)*/
List *list_copy(List *lst);
/*Deletes all the elements in the list. O(n)*/
void list_delete_elements(List **lst);
/*Searches the list for the specified key. O(n)*/
int list_search(List *lst, int key);
void list_sort(List **lst);
#endif

