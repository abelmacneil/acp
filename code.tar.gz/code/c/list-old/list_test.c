#include <stdio.h>
#include <stdlib.h>
#include "list.h"

#define N 100000

int main (){
	/*
	List *lst = NULL, *lst2 = NULL;
	int i, n = 5, *ptr;
	for(i = 1; i < n; i++){
		list_add(&lst, i);
		//list_push(&lst2, n - i - 1);
	}
	lst2 = list_copy(lst);
	list_append(lst, lst2);
	List *tmp = lst;
	printf("Initial list:  ");
	while (tmp != NULL){
		printf("%d, ", tmp->value);
		tmp = tmp->next;
	}

	list_reverse(&lst);
	tmp = lst;
	printf("\nReversed list: ");
	while (tmp != NULL){
		printf("%d, ", tmp->value);
		tmp = tmp->next;
	}

	printf("\nSize: %d\n", list_size(lst));
	list_delete_elements(&lst);
	printf("Size after removal: %d\n", list_size(lst));
	free(lst);
	//*/
//	/*
	List *lst = NULL, *lst2;
	int i;
	while(1){
		for(i = 0; i < N; i++){
			list_push(&lst, i);
		}
		list_reverse(&lst);
		list_delete_elements(&lst);
	}
	//*/
	return 0;
}
