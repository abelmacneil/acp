#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include <assert.h>

static void mem_assert(void *ptr){
	if (ptr == NULL){
		printf("Out of memory");
		exit(EXIT_FAILURE);
	}
}

/*Pushes the value to begining of the list. O(1)*/
void list_push(List **lst, int val){
	if (*lst == NULL){
		*lst = malloc(sizeof(List));
		mem_assert(*lst);
		(*lst)->value = val;
		return;
	}
	List *new_lst = malloc(sizeof(List));
	mem_assert(new_lst);
	new_lst->value = val;
	new_lst->next = *lst;
	*lst = new_lst;
}
/*Pops off the first element of the list. O(1)*/
int list_pop(List **lst){
	List *popped = *lst;
	*lst = popped->next;
	int val = popped->value;
	free(popped);
 	popped = NULL;
	return val;
}
/*Gets the size of the list. O(n)*/
long list_size(List *lst){
	if (lst == NULL)
		return 0;
	List *tmp = lst;
	int i = 1;
	while((tmp = tmp->next) != NULL)
		i++;
	return i;
}
/*Adds and element to the end of the list. O(n)*/
//leaking memory
void list_add(List **lst, int val){
	if (*lst == NULL){
		*lst = malloc(sizeof(List));
		//mem_assert(*lst);
		(*lst)->value = val;
		(*lst)->next = NULL;
		return;
	}
	List *tmp = *lst;
	while (tmp->next != NULL){
		tmp = tmp->next;
	}
	assert(tmp->next == NULL);
	tmp->next = malloc(sizeof(List));
	assert(tmp->next != NULL);
	tmp->next->value = val;
	tmp->next->next = NULL;
}
/*Gets the element of the lsit at the index. O(n)*/
int list_at(List *lst, int index){
	if (lst == NULL){
		return 0;
	}
	int i = 0;
	List *tmp = lst;
	while (i++ < index){
		tmp = tmp->next;
		if (tmp == NULL){
			printf("\nList index out of bounds! Exiting!\n");
			exit(EXIT_FAILURE);
		}
	}
	return tmp->value;
}

/* Removes the last element of the list and returns its value. O(n)*/
int list_remove(List **lst){
	if((*lst)->next == NULL){
		int val = (*lst)->value;
		free(*lst);
		*lst = NULL;
		return val;
	}
	List *tmp = *lst;
	while (tmp->next->next != NULL){
		tmp = tmp->next;
	}
	int val = tmp->next->value;
	free(tmp->next);
	tmp->next = NULL;
	return val;
}
/*Reverses the list. O(n)*/
void list_reverse(List **lst){
	List *prev = NULL, *next;
	while (*lst != NULL){
		next = (*lst)->next;
		(*lst)->next = prev;
		prev = *lst;
		*lst = next;
	}
	*lst = prev;
}
/*Appends two lists together, storing the result in the first list. O(n)*/
void list_append(List *lst1, List *lst2){
	List *last1 = lst1;
	while (last1->next != NULL)
		last1 = last1->next;

	last1->next = lst2;
}
List *list_copy(List *lst){
	List *new_lst = NULL, *prev = NULL, *tmp = NULL;
	while (lst != NULL){
		tmp = malloc(sizeof(List));
		mem_assert(tmp);
		tmp->value = lst->value;
		if (new_lst == NULL){
			new_lst = tmp;
			prev = tmp;
		}else {
			prev->next = tmp;
			prev = tmp;
		}

		lst = lst->next;
	}
	return new_lst;
}

void list_delete_elements(List **lst){
	while (*lst != NULL){
		list_remove(lst);
	}
}
int list_search(List *lst, int key){
	int i = 0;
	while (lst != NULL){
		if (lst->value == key){
			return i;
		}
		lst = lst->next;
		i++;
	}
	return -1;
}

void list_sort(List **lst){
	if ((*lst)->next == NULL){
		return;
	}
	List *lesser = NULL, *greater = NULL, *tmp = *lst;
	int pivot = tmp->value;
	while (tmp != NULL){
		if (tmp->value < pivot){
			List *new_lst = malloc(sizeof(List));
			new_lst->value = tmp->value;
			new_lst->next = lesser;
			lesser = new_lst;
		}else if (tmp->value <= pivot){
			List *new_lst = malloc(sizeof(List));
			new_lst->value = tmp->value;
			new_lst->next = greater;
			greater = new_lst;
		}
	}
	list_sort(&lesser);
	list_sort(&greater);
	list_append(lesser, greater);
	*lst = lesser;
}
