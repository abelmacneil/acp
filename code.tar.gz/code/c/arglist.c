#include <stdio.h>
#include <stdlib.h>
#include <string.h>


char * pop(char ** arr, int size, int index){
	int i;
	char * popped = arr[index];
	for (i = 0; i < size - 1; i++){
		if(i >= index){
			arr[i] = arr[i + 1];
		}
	}
	return popped;
}
int haschar(char * str, char c){
	int i;
	int len = strlen(str);
	for(i = 0; i < len; i ++)
		if(str[i] == c)
			return 1;
	return 0;
}

int main (int argc, char ** argv){
	int i;
	char * dir;
	int removed = 0;
	int showall = 0;
	int dirdepth = 0;
	if (haschar(argv[1], '/')){
		dir = pop(argv, argc,1);
		removed++;
	}
	else
		dir = "/home/abel/code";
	for(i = 1; i < argc - removed; i++){
		if (strcmp(argv[i], "-a") == 0)
			showall = 1;
		if(strcmp(argv[i], "-d") == 0)
			dirdepth = atoi(argv[i + 1]);
		printf("%s\n", argv[i]);
	}
	return 0;
}
