#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>

#define FILE_T 8
#define DIR_T  4

#define TRUE   1
#define FALSE  0

int is_specialdir(char * name){
	return strcmp(name,".") == 0 || strcmp(name,"..") == 0;
}
long long get_file_size(char * name){
	FILE * f = fopen(name ,"r");
	long long size = 0;
	if (f == NULL)
		return -1;
	
	while (fgetc(f) != EOF)
		size++;
		
	fclose(f);
	return size;
}

long long get_dir_size(char * dirname, int depth, int maxdepth){
	if(depth >= maxdepth)
		return 0;
	long long size = 0;
	char * temp  = malloc(PATH_MAX);
	DIR * d;
	struct dirent * file;
	
	d = opendir(dirname);
	
	if (d){
		
		while (d != NULL && (file = readdir(d)) != NULL){
			strcpy(temp,dirname);
			strcat(temp,"/");
			strcat (temp, file->d_name);
			

			if (file->d_type == FILE_T){
				size += get_file_size(temp);			
			}
			else if (file->d_type == DIR_T && strcmp(file->d_name, ".") != 0 &&
				 strcmp(file->d_name, "..") != 0 && file->d_name[0] != '.'){
				 size += get_dir_size(temp, depth + 1, maxdepth);
			}
			//strcpy(dirname, temp);
		}
	}else{
		printf("Error opening directory. %s\n", dirname);
	}
	closedir(d);
	free(temp);
	return size;
}
/*
 * Returns the subtring of str from the string's index at begin,
 * up to but not inlcuding end.
 */
char * sub_str(char * str, int begin, int end){
	char * cpy = calloc(end - begin,1);
	int i = 0;
	for(i = begin; i < end; i++)
		cpy[i - begin] = str[i];
	return cpy;
}
/*
 * Returns the name of the user given their uid.
 * 
 * Expects a file pointer to /etc/passwd, this 
 * shortens time when multiple openings of 
 * /etc/passwd are needed.
 */
char * get_user(uid_t uid, FILE * fpasswd){
	char * buf, *tmp;
	if (fpasswd == NULL){
		printf ("%d", errno);
		return "ERROR";
	}
	int i = 0, flag = 0;
	int * index;
	while(!flag){
		i = 0;
		index = calloc(3, sizeof(int));
		buf = malloc(100);
		while((buf[i] = getc(fpasswd)) != '\n' && buf[i] != EOF){
			
			if (buf[i] == ':' && !index[0]){
				index[0] = i;
			}
			else if (buf[i] == ':' && index[0] && !index[1]){
				index[1] = i;
			}
			else if (buf[i] == ':' && index[0] && index[1] && !index[2]){
				index[2] = i;
				tmp = sub_str(buf,index[1] +1, index[2]);
				
				if (atoi(tmp) == uid){
					rewind(fpasswd);
					return sub_str(buf,0,index[0]);
				}
			}
			i++;
		}
		if(buf[i] == EOF){
			flag = 1;
			free(buf);
			free(index);
		}
	}
	rewind(fpasswd);
	return "NULL";
}

char * get_month(int m){
	switch (m){
		case 0: return "Jan";
		case 1: return "Feb";
		case 2: return "Mar";
		case 3: return "Apr";
		case 4: return "May";
		case 5: return "Jun";
		case 6: return "Jul";
		case 7: return "Aug";
		case 8: return "Sep";
		case 9: return "Oct";
		case 10: return "Nov";
		case 11: return "Dec";		
	}
	return "---";
}

char * add_leading_zero(int n){
	char * buf = malloc(10);
	sprintf(buf,"%d",n);
	int len = strlen(buf);
	char * str = calloc (len+1,sizeof(char));
	
	str[0] = '0';
	int i;
	for( i = 1; i < len + 1; i++){
		str[i] = buf[i - 1];
	}
	return str;
}
struct filedata {
	char * fd_usr;
	char * fd_name;
	char * fd_path;
	char fd_type;
	long long fd_size;
	struct tm * fd_date;
};

void print_filedata(struct filedata data){
	char * sizestr = malloc(20);
	if (data.fd_type == 'd' && data.fd_size == 0){
		sizestr = "";
	}else{
		sprintf(sizestr,"%lld",data.fd_size);
	}
	printf("%7s %20s %c %10s %s %2d %02d:%02d", 
					data.fd_usr,
					data.fd_name, 
					data.fd_type,
					sizestr, 
					get_month(data.fd_date->tm_mon),
					data.fd_date->tm_mday,
					data.fd_date->tm_hour,
					data.fd_date->tm_min);
}
int get_filedata(struct dirent * file, char * dirname,FILE * fpasswd,int maxdepth, struct filedata * data){
	struct stat filestat;
	char  * temp = malloc(strlen(dirname));
	
	strcpy(temp, dirname);
	
	data->fd_path = malloc(PATH_MAX);
	data->fd_name = file->d_name;
	strcpy(data->fd_path, strcat(strcat(dirname,"/") ,data->fd_name));
	stat(data->fd_path, &filestat);
	data->fd_date = localtime(&filestat.st_ctime);
	data->fd_usr = get_user(filestat.st_uid, fpasswd);
	
	
	if(file->d_type == FILE_T){
			data->fd_type = 'f';
			data->fd_size = get_file_size(data->fd_path);
	}
	else if (file->d_type == DIR_T){
		data->fd_type = 'd';
		
		if (!is_specialdir(data->fd_name) && data->fd_name[0] != '.') {
			data->fd_size = get_dir_size(data->fd_path, 0 ,maxdepth);
		}
	} else{
		data->fd_type = '0' + file->d_type;
	}

	strcpy(dirname,temp);
	return 0;
}
char * pop(char ** arr, int size, int index){
	int i;
	char * popped = arr[index];
	for (i = 0; i < size - 1; i++){
		if(i >= index){
			arr[i] = arr[i + 1];
		}
	}
	return popped;
}
int haschar(char * str, char c){
	int i;
	int len = strlen(str);
	for(i = 0; i < len; i ++)
		if(str[i] == c)
			return TRUE;
	return FALSE;
}

void sort(struct filedata * fdarr, int size){
	int swapped = TRUE, i;
	struct filedata temp;
	while (swapped){
		swapped = FALSE;
		for(i = 0; i < size - 1; i++){
			
			if(!is_specialdir(fdarr[i].fd_name) && !is_specialdir(fdarr[i + 1].fd_name) && strcmp(fdarr[i].fd_name, fdarr[i + 1].fd_name) > 0)
				printf("%s, %s", fdarr[i].fd_name, fdarr[i + 1].fd_name);
				temp = fdarr[i];
				fdarr[i] = fdarr[i + 1];
				fdarr[i + 1] = temp;
				swapped = TRUE;
		}
		printf("%d\n",swapped);
	}
}
int compare(const void * a, const void * b){
	return strcmp(*(const char **) a, *(const char **) b);
}

int main(int argc,char ** argv){
	
	char * dirname = malloc(PATH_MAX);
	int showall = FALSE, ishidden = TRUE, numfiles = 0, removed = 0, dirdepth = 0, i;
	DIR * d;
	FILE * fpasswd = fopen("/etc/passwd", "r");
	struct dirent *file;
	struct filedata * data = malloc(sizeof(struct filedata));
	
	//handle command line args
	if (argc >= 2 && haschar(argv[1], '/')){
		strcpy(dirname, pop(argv, argc,1));
		removed++;
	}
	else{
		getcwd(dirname, PATH_MAX);
	}
	for(i = 1; i < argc - removed; i++){
		if (strcmp(argv[i], "-a") == 0)
			showall = TRUE;
		else if(strcmp(argv[i], "-d") == 0)
			dirdepth = atoi(argv[i + 1]);
	}
	
	d = opendir(dirname);
	
	if (d){
		//main loop, retrieves the files and their attributes
		while (d != NULL && (file = readdir(d)) != NULL){
			
			get_filedata(file, dirname, fpasswd,dirdepth, &data[numfiles]);
			numfiles++;
			data = realloc(data, (numfiles + 1) * sizeof(struct filedata));
		}
		
		printf("Total %d files in %s\n", numfiles, dirname);
		/*char ** arr = malloc(numfiles * sizeof(char *));
		for(i = 0; i < numfiles; i++){
			arr[i] = data[i].fd_name;
		}
		qsort(arr, numfiles, sizeof(char *), compare);*/
		for (i = 0; i < numfiles; i++){
			if (!showall){
				if (data[i].fd_name[0] != '.'){
					ishidden = 1;
				}else
					ishidden = 0;
			}
			if (ishidden){
				
				print_filedata(data[i]);
				printf("\n");
			}
			free(data[i].fd_path);
			//printf("%s\n",arr[i]);
		}
	}else {
		printf("Error opening %s", dirname);
	}
	
	
	closedir(d);
	fclose(fpasswd);
	free(data);
	free(dirname);
	return 0;
}
