#include "hashmap.h"
#include "hash.h"
#include "vector.h"
#include <stddef.h>
#include <stdio.h>

#define NUMBER_OF_BUCKETS 32

#define HASHMAP_FOREACH(set, node) \
    VECTOR_FOREACH(set->buckets, bucket) \
        for( ;bucket != NULL; bucket = bucket->next)

struct HashMap {
    struct Vector *buckets;
    uint32_t (*hash) (void *val);
    int (*compare) (void *val1, void *val2);
    size_t size;
    size_t capacity;
};

struct Node {
    void *key;
    void *val;
    struct Node *next;
};

static void rehash(struct HashMap *map, size_t size);

inline size_t hashmap_size(struct HashMap *map)
{
    return map->size;
}
struct HashMap *hashmap_new(uint32_t (*hash_fct) (void *val),
        int (*cmp_fct) (void *val1, void *val2))
{
    struct HashMap *map = malloc(sizeof(struct HashMap));
    map->hash = hash_fct == NULL ? str_hash : hash_fct;
    map->compare = cmp_fct == NULL ? str_cmp : cmp_fct;
    map->size = 0;
    map->capacity = NUMBER_OF_BUCKETS;
    map->buckets = vector_new(map->capacity);
    vector_expand(map->buckets);
    return map;
}

static struct Node *hashmap_node_new(void *key, void *val)
{
    struct Node *node = malloc(sizeof(struct Node));
    node->key = key;
    node->val = val;
    node->next = NULL;
    return node;
}

int hashmap_insert(struct HashMap *map, void *key, void *val)
{
    if (map->size + 1 >= 3 * map->capacity / 4)
        rehash(map, map->capacity << 1);
    uint32_t hash = map->hash(key); 
    size_t index = hash % map->capacity;
    //printf("[%d] = %d\n", index, *(int*)key);
    struct Node *node = vector_get(map->buckets, index);
    if (node == NULL) {
        node = hashmap_node_new(key, val);
        vector_set(map->buckets, index, node);
    } else {
        struct Node *prev;
        while (node != NULL) {
            if (map->compare(node->key, key) == 0) {
                return BAD_INSERT;
            }
            prev = node;
            node = node->next;
        }
        prev->next = hashmap_node_new(key, val);
    }
    map->size++;
    return GOOD_INSERT;
}

void *hashmap_get(struct HashMap *map, void *key)
{
    if (map->size + 1 >= 3 * map->capacity / 4)
        rehash(map, map->capacity << 1);
    uint32_t hash = map->hash(key); 
    size_t index = hash % map->capacity;
    //printf("[%d] = %d\n", index, *(int*)key);
    struct Node *node = vector_get(map->buckets, index);
    if(node) {
        while (node != NULL) {
            if (map->compare(node->key, key) == 0) {
                return node->val;
            }
            node = node->next;
        }
    }
    return NULL;
}
void *hashmap_remove(struct HashMap *map, void *key)
{
    uint32_t hash = map->hash(key); 
    size_t index = hash % map->capacity;
    //printf("[%d] = %d\n", index, *(int*)key);
    struct Node *node = vector_get(map->buckets, index);
    if (node == NULL) {
        return NULL;
    } else if (map->compare(node->key, key) == 0){
        void *val = node->val;
        vector_set(map->buckets, index, node->next);
        free(node);
        map->size--;
        return val;
    }
    else {
        struct Node *prev;
        while (node != NULL) {
            if (map->compare(node->key, key) == 0) {
                void *val = node->val;
                prev->next = node->next;
                free(node);
                map->size--;
                return val;
            }
            prev = node;
            node = node->next;
        }
    }
    return NULL;
}

void hashmap_foreach(struct HashMap *map,
        void (*fct) (void *key, void *val))
{
    struct Node *bucket;
    HASHMAP_FOREACH(map, bucket) {
        fct(bucket->key, bucket->val);
    }
}

void hashmap_copy(struct HashMap *dest, struct HashMap *src)
{
    struct Node *bucket;
    HASHMAP_FOREACH(src, bucket) {
        hashmap_insert(dest, bucket->key, bucket->val);
    }
}

static void rehash(struct HashMap *map, size_t size)
{
    struct Vector *oldbuckets = map->buckets;
    map->buckets = vector_new(size);
    map->capacity = size;
    map->size = 0;
    vector_expand(map->buckets);
    struct Node *bucket, *prev;
    VECTOR_FOREACH(oldbuckets, bucket) {
        while (bucket != NULL) {
            hashmap_insert(map, bucket->key, bucket->val);
            prev = bucket;
            bucket = bucket->next;
            free(prev);
        }
    }
    vector_destroy_vec(oldbuckets);
}

void hashmap_destroy_keys(struct HashMap *map)
{
    struct Node *bucket;
    HASHMAP_FOREACH(map, bucket) {
        if (bucket->key)
            free(bucket->key);
    }
}

void hashmap_destroy_values(struct HashMap *map)
{
    struct Node *bucket;
    HASHMAP_FOREACH(map, bucket) {
        if (bucket->val)
            free(bucket->val);
    }
}

static void hashmap_destroy_nodes(struct HashMap *map)
{
    struct Node *bucket, *prev;
    VECTOR_FOREACH(map->buckets, bucket) {
        while(bucket != NULL) {
            prev = bucket;
            bucket = bucket->next;
            free(prev);
        }
    }
}
void hashmap_destroy(struct HashMap *map)
{
    hashmap_destroy_nodes(map);
    vector_destroy_vec(map->buckets);
    free(map);
}

