#ifndef HASHMAP_H_INCLUDED
#define HASHMAP_H_INCLUDED
#include <stdint.h>
#include <stddef.h>
#define BAD_INSERT 0
#define GOOD_INSERT 1
/**
 * A representation of a struct HashMap (or Hashtable), that maps keys to values.
 * Values can be retrieved and set based on their key.
 */
typedef struct HashMap HashMap;


#define DEFAULT_NUM_BUCKETS 64
/**
 * Gets the number of key to value mappings in the hashtable.
 * @param map the hashmap.
 * @return the size of the hashmap
 */
inline size_t hashmap_size(struct HashMap *map);
/**
 * Creates a new struct HashMap.
 * @param hash_fct the function to generate hashcode from a given key.
 * If NULL, the default is used, using char pointers.
 * @param hash_cmp the function to compare keys.
 * If NULL, the default is used, using strcmp from <string.h>.
 * @return a newly allocated hashmap.
 */
struct HashMap *hashmap_new(uint32_t (*hash_fct) (void *val),
        int (*hash_cmp) (void *v1, void *v2));
/**
 * Destroys the hashmap, by freeing all allocated memory.
 * @param map the hashmap to destroy.
 */
void hashmap_destroy(struct HashMap *map);
void hashmap_destroy_keys(struct HashMap *map);
void hashmap_destroy_values(struct HashMap *map);
/**
 * Sets a new entry in the hashmap, mapping the key to the value.
 * @param map the hashmap.
 * @param key the key to set.
 * @param value the value the key maps to.
 */
int hashmap_insert(struct HashMap *map, void *key, void *value);
/**
 * Gets the value corresponding to the given key in the hashmap.
 * @param map the hasmap. If the 
 * @param key the key of the value to retrieve.
 * @return the value corresponding to the given key.
 */
void *hashmap_get(struct HashMap *map, void *key);
/**
 * Checks if the given key is stored in the hashmap.
 * @param map the hasmap to check.
 * @param key the key to check for.
 * @return 1 if the key is found, 0 if it is not.
 */
int hashmap_contains_key(struct HashMap *map, void *key);
/**
 * Deletes the entry in the hashmap.
 * @param map the hashmap.
 * @param key the key of the node to delete.
 */
void *hashmap_remove(struct HashMap *map, void *key);
/**
 * Traverses the hashmap, applying the given function
 * to each key and node in the hashmap.
 * @param map the map to taverse.
 * @param fct the function to be applied
 */
void hashmap_foreach(struct HashMap *map, void (*fct) (void *key, void *value));
/**
 * Generates the hash for a given key, based on Bob Jenkins' 
 * one-at-a-time hash function. This is the defualt hashing 
 * function for all hashmaps.
 * (see http://en.wikipedia.org/wiki/Jenkins_hash_function)
 * @param key the key to hash.
 * @return the hash of the key.
 */
#endif /*HASHMAP_H_INCLUDED*/

