#include "hashset.h"
#include "hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

void print_int(void *val)
{
    printf("%d, ", *(int*)val);
}

void print_int_set(char *name, struct HashSet *set)
{
    printf("%s = {", name);
    hashset_foreach(set, &print_int);
    printf("}\n");
}
void *add(void *acc, void *data)
{
    int *tmp = acc;
    *tmp += *(int*)data;
    return tmp;
}
void *inc(void *data)
{
    int *ptr = malloc(sizeof(int));
    *ptr = *(int*)data + 10000;
    return ptr;
}

bool bool_test_result(char *str, bool res, bool expected) 
{
    bool is_good = res == expected; 
    assert(is_good);
    printf("%-40s %10s <= %5s\n", 
            str,
            res ? "true" : "false",
            is_good ? "PASSED" : "FAILED");
    return is_good;
}
bool int_test_result(char *str, int res, int expected) 
{
    bool is_good = res == expected; 
    //assert(is_good);
    printf("%-40s %10d <= %5s\n", 
            str,
            res,
            is_good ? "PASSED" : "FAILED");
    return is_good;
}
int main()
{
    const int N = 20;
    struct HashSet *setA = hashset_new(int_hash, int_cmp);
    struct HashSet *setB = hashset_new(int_hash, int_cmp);
    int *ptr, i;
    srand(0);
    for(i = 0; i < N; i++) {
        ptr = malloc(sizeof(int));
        *ptr = rand() % (N * N);
        if (*ptr < (N * N) / 2)
            hashset_insert(setA, ptr);
        else 
            hashset_insert(setB, ptr);

        if (*ptr >  5 * N * N / 7 && *ptr < 6 * N * N / 7){
            int tmp = *ptr;
            ptr = malloc(sizeof(int));
            *ptr = tmp;
            hashset_insert(setA, ptr);
            hashset_insert(setB, ptr);
        }
    }
    struct HashSet *tmp = hashset_map(setA, &inc);
    hashset_destroy(setA);
    setA = tmp;
    ptr = malloc(sizeof(int));
    *ptr = 0;
    hashset_fold(setB, ptr, &add);
    struct HashSet *intersection_set = hashset_intersection(setA, setB);
    struct HashSet *union_set = hashset_union(setA, setB);
    struct HashSet *diff_set = hashset_difference(setA, setB);
    print_int_set("Set A", setA);
    print_int_set("Set B", setB);
    print_int_set("Intersection of A and B", intersection_set);
    print_int_set("Union of A and B", union_set);
    print_int_set("Difference of A and B", diff_set);
    printf("\n");
    int_test_result("Sum of B's elements:", *ptr, 2758);
    bool_test_result("Intersection of A and B subset of A:",
            hashset_subset(intersection_set,setA), true);
    bool_test_result("Difference of A and B subset of A:",
            hashset_subset(diff_set,setA), true);
    bool_test_result("Union of A and B subset of A:",
            hashset_subset(union_set,setA), false);
    bool_test_result("A subset of Union of A and B:",
            hashset_subset(setA, union_set), true);
    hashset_destroy(setA);
    hashset_destroy(setB);
    hashset_destroy_set(intersection_set);
    hashset_destroy_set(union_set);
    hashset_destroy_set(diff_set);
    free(ptr);
    return 0;
}
