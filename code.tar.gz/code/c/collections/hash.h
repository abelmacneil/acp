#ifndef HASH_H_INCLUDED
#define HASH_H_INCLUDED
#include <stdint.h>
int str_cmp(void *v1, void *v2);
uint32_t str_hash(void *key);
int int_cmp(void *v1, void *v2);
uint32_t int_hash(void *key);
#endif /* HASH_H_INCLUDED */
