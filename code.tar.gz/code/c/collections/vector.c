#include "vector.h"
#include <stdlib.h>
#include <stdio.h>

struct Vector {
	void **data;	/**< The internal array managed by the vector.*/
	size_t size;	/**< The current size of the vector.*/
	size_t capacity;/**< The current capacity the vector has to store data.*/
} ;


inline size_t vector_size(struct Vector *vec)
{
	return vec->size;
}
inline size_t vector_capacity(struct Vector *vec)
{
	return vec->capacity;
}
struct Vector *vector_new(size_t capacity)
{
	struct Vector *vec = malloc(sizeof(struct Vector));
	if (vec == NULL)
		return NULL;
	vec->capacity = capacity;
	vec->size = 0;
	vec->data = calloc(capacity, sizeof(void*));
	return vec;
}


void vector_clear(struct Vector *vec)
{
	size_t i;
	for (i = 0; i < vec->capacity; i++){
		if (vec->data[i]){
			free(vec->data[i]);
		}
	}
}
void vector_destroy_vec(struct Vector *vec)
{
	if (vec){
		if (vec->data){
			/*size_t i;
			for (i = 0; i < vec->capacity; i++){
				if (vec->data[i]){
					free(vec->data[i]);
				}
			}*/
			free(vec->data);
		}
		free(vec);
	}
}

void vector_destroy(struct Vector *vec)
{
    vector_clear(vec);
    vector_destroy_vec(vec);
}

inline void *vector_get(struct Vector *vec, size_t index)
{
	if (vec != NULL && index < vec->size)
		return vec->data[index];
	else
		return NULL;
}

inline void vector_set(struct Vector *vec, size_t index, void *val)
{
	if (index < vec->capacity)
		vec->data[index] = val;
}

void vector_push(struct Vector *vec, void *element)
{
	if (vec == NULL || element == NULL)
		return;
	if (vec->capacity <= vec->size){
		vector_resize(vec, vec->capacity << 1);
	}
	vec->data[vec->size] = element;
	vec->size++;
}

void *vector_pop(struct Vector *vec)
{
	void *val = vec->data[vec->size - 1];
	free(vec->data[vec->size - 1]);
	vec->data[vec->size - 1] = NULL;
	vec->size--;
	return val;
}


void vector_resize(struct Vector *vec, size_t n) 
{
	if (n < vec->size){
		vec->size = n;
	}
	vec->capacity = n;
	vec->data = realloc(vec->data, (n + 1) * sizeof(void*));
}

void vector_expand(struct Vector *vec)
{
	vec->size = vec->capacity;
}
void vector_shink_to_fit(struct Vector *vec)
{
	vector_resize(vec, vec->size);
}
void vector_insert(struct Vector *vec, size_t index, void *val) 
{
	size_t i;
	if (vec->size + 1 > vec->capacity) {
		vector_resize(vec, vec->capacity * 2);
	}
	for (i = vec->size; i > index; i--)
		vec->data[i] = vec->data[i - 1];
	vec->data[index] = val;
	vec->size++;
}
void *vector_delete_at(struct Vector *vec, size_t index)
{
	size_t i;
	void *val;
	if (vec == NULL || index >= vec->size)
		return NULL;

	val = vec->data[index];
	//free(vec->data[index]);
	for (i = index; i  < vec->size; i++)
		vec->data[i] = vec->data[i + 1];
	vec->size--;
	return val;
}
int vector_delete(struct Vector *vec, void *value)
{
	size_t i;
	for(i = 0; i < vector_size(vec); i++){
		if (value == vector_get(vec, i)) {
			(void) vector_delete_at(vec,i);
			return 0;
		}
	}
	return 1;
}
void vector_qsort(struct Vector *vec, int (*cmp) (const void*,const void*))
{
	qsort(vec->data, vec->size, sizeof(void*), cmp);
}
inline void **vector_begin(struct Vector *vec)
{
	return vec->data;
}
inline void **vector_end(struct Vector *vec)
{
	return vec->data + vec->size;
}
