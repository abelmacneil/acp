#include "hash.h"
#include <string.h>
#include <math.h>
int str_cmp(void *v1, void *v2)
{
    return strcmp((char*) v1, (char*) v2);
}

uint32_t str_hash(void *key)
{
    char *keystr = (char*) key;
    size_t len = strlen(keystr);
    uint32_t hash, i;

    for(hash = i = 0; i < len; i++){
        hash += keystr[i];
        hash += (hash << 10);
        hash ^= (hash >> 6);
    }
    hash += (hash << 3);
    hash ^= (hash >> 11);
    hash += (hash << 15);
    return hash;
}
int int_cmp(void *v1, void *v2)
{
//    printf("%d : %d\n", (*(int*)v1), (*(int*)v2));
    return (*(int*)v1) - (*(int*)v2);
}

uint32_t int_hash(void *key)
{
    return abs(*(int*)key) * 2654435761 % ((uint64_t)1l << 32);
}

