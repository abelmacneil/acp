#ifndef HASHSET_H_INCLUDED
#define HASHSET_H_INCLUDED
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#define GOOD_INSERT 0
#define BAD_INSERT  1


struct HashSet;

struct HashSet *hashset_new(uint32_t (*hash_fct) (void *val),
                            int (*hash_cmp) (void *v1, void *v2));

void hashset_destroy_contents(struct HashSet *set);

void hashset_destroy_set(struct HashSet *set);

void hashset_destroy(struct HashSet *set);

int hashset_insert(struct HashSet *set, void *data);

void *hashset_remove(struct HashSet *set, void *data);

bool hashset_contains(struct HashSet *set, void *data);

void hashset_foreach(struct HashSet *set, void (*fct) (void *val));

struct HashSet *hashset_map(struct HashSet *set, void *(*fct) (void *val));

void *hashset_fold(struct HashSet *set, void *init, 
                   void *(*fct) (void *acc, void *data));

struct HashSet *hashset_union(struct HashSet *setA, struct HashSet *setB);

struct HashSet *hashset_intersection(struct HashSet *setA,
                                     struct HashSet *setB);

struct HashSet *hashset_difference(struct HashSet *setA, 
                                   struct HashSet *setB);

bool hashset_subset(struct HashSet *setA, struct HashSet *setB);


#endif /* HASHSET_H_INClUDED */
