#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

enum color {black, red};
struct Node {
    enum color color;
    int data;
    struct Node *children[2];
};

struct TreeSet {
    struct Node *root;
    int (*compare) (int v1, int v2);
};

struct TreeSet *treeset_new(int (*compare) (int v1, int v2))
{
    struct TreeSet *set = malloc(sizeof(*set));
    set->compare = compare;
    return set;
}

static struct Node *make_node(int data)
{
    struct Node *node = malloc(sizeof(*node));
    if (node) {
        node->children[0] = NULL;
        node->children[1] = NULL;
        node->data = data;
        node->color = red;
    }
    return node;
}


static bool is_red(struct Node *node)
{
    return node != NULL && node->color == red;
}
static struct Node *single_rotation(struct Node *root, int dir)
{
    struct Node *newroot = root->children[!dir];
    root->children[!dir] = newroot->children[dir];
    newroot->children[dir] = root;
    root->color = red;
    newroot->color = black;
    return newroot;
}

static struct Node *double_rotation(struct Node *root, int dir)
{
    root->children[!dir] = single_rotation(root->children[!dir], !dir);
    return single_rotation(root, dir);
}
static struct Node *insert_node(struct Node *root, int data)
{
    if (root == NULL) {
        root = make_node(data);
    } else if (root->data != data) {
        int dir = root->data < data;
        root->children[dir] = insert_node(root->children[dir], data);

        /* Balancing */
        if (is_red(root->children[dir])) {
            if (is_red(root->children[!dir])) {
                root->color = red;
                root->children[0]->color = black;
                root->children[1]->color = black;
            } else {
                if (is_red(root->children[dir]->children[dir]))
                    root = single_rotation(root, !dir);
                else if (is_red(root->children[dir]->children[!dir]))
                    root = double_rotation(root, !dir);
            }
        }
    }
    return root;
}

void treeset_insert(struct TreeSet *set, int data)
{
    set->root = insert_node(set->root, data);
    set->root->color = black;
}

static void print_all(struct Node *node)
{
    if (node) {
        print_all(node->children[0]);
        printf("%d, ", node->data);
        print_all(node->children[1]);
    }
}
int main() 
{
    struct TreeSet *set = treeset_new(NULL);
    int i;
    srand(0);
    for (i = 0; i < 10; i++){
        int t = rand() % 1000;
        printf("%d, ", t);
        treeset_insert(set, t);
    }
    printf("\n");
    print_all(set->root);
    printf("\n");
    return 0;
}
