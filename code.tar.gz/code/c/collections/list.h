#ifndef	LIST_H_INCLUDED
#define LIST_H_INCLUDED

#include <stdio.h>
typedef struct Node {
	struct Node *next;
	struct Node *prev;
	void *value;
} Node;

typedef struct List {
	int size; 
	Node *first;
	Node *last;
} List;

/*Creates a new Double Linked List*/
List *list_new();
/*Destroys the list*/
void list_destroy(List *list);
/*Frees each value of each node*/
void list_clear(List *list);
/*Destroys the list and its contents.*/
void list_clear_destroy(List *list);
/*Pushes the value to end of the list. O(1)*/
void list_push(List *list, void *val);
/*Pops off the last element of the list. O(1)*/
void *list_pop(List *list);
/*Adds and element to the front of the list. O(1)*/
void list_unshift(List *list, void *val);
/*Removes and element from the front of the list. O(1)*/
void *list_shift(List *list);
/*Removes the specified node from the list. O(1)*/
void *list_remove(List *list, Node *node);
/*Copies the specified list into a newly allocated list*/
List * list_copy(List *list);
/*Joins the second list to the end of the first*/
void list_join(List *list1, List *list2);
void list_bubble_sort(List *list, int (*cmpfct) (const void*, const void*));

#define LIST_FOREACH(L,S,M,V) \
	Node *V = NULL;\
	for(V = L->S;  V != NULL; V = V->M)

#endif
