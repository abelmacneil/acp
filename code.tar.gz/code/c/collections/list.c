#include "list.h"
#include <stdlib.h>
#define check_mem(PTR) do {\
	if (PTR == NULL){\
		fprintf(stderr, "\"" #PTR "\" is NULL, out of memory, exiting.\n");\
		exit(EXIT_FAILURE);\
	} }while(0)

List *list_new() {
	List *list = malloc(sizeof(List));
	check_mem(list);
	list->first = NULL;
	list->last = NULL;
	return list;
}

void list_destroy(List *list){
	LIST_FOREACH(list, first, next, node){
		if (node->prev){
			free(node->prev);
			node->prev = NULL;
		}
	}
	free(list->last);
	list->last = NULL;
	free(list);
}

void list_clear(List *list){
	LIST_FOREACH(list, first, next, node){
		free(node->value);
		node->value = NULL;
	}
}

void list_clear_destroy(List *list){
	list_clear(list);
	list_destroy(list);
}

void list_push(List *list, void *val){
	Node *node = malloc(sizeof(Node));
	check_mem(node);
	node->value = val;

	if (list->last == NULL){
		list->first = node;
		list->last = node;
	}else {
		list->last->next = node;
		node->prev = list->last;
		list->last = node;
	}
	list->size++;
}

void *list_pop(List *list){
	Node *node = list->last;
	return node == NULL ? NULL : list_remove(list, node);
}

void list_unshift(List *list, void *val){
	Node *node = malloc(sizeof(Node));
	check_mem(node);
	node->value = val;
	if (list->first == NULL){
		list->first = node;
		list->last = node;
	}else{
		node->next = list->first;
		list->first->prev = node;
		list->first = node;
	}
	list->size++;
}
void *list_shift(List *list){
	Node *node = list->first;
	return node == NULL ? NULL : list_remove(list, node);
}

void *list_remove(List *list, Node *node){
	if (node == NULL){
		return NULL;
	}
	void *val = node->value;
	if (node == list->first && node == list->last){
		list->first = NULL;
		list->last = NULL;
	}else if (node == list->first){
		list->first = node->next;
		list->first->prev = NULL;
	}else if (node == list->last){
		list->last = node->prev;
		list->last->next = NULL;
	}else {
		Node *before = node->prev;
		Node *after = node->next;
		before->next = after;
		after->prev = before;
	}
	list->size--;
	free(node);
	return val;
}
List * list_copy(List *list) {
	List *new_lst = list_new();
	LIST_FOREACH(list, first, next, tmp){
		list_push(new_lst, tmp->value);
	}
	return new_lst;
}
void list_join(List *list1, List *list2) {
	list1->last->next = list2->first;
	list2->first->prev = list1->last;
	list1->last = list2->last;
	list2->first = list1->first;
	list1->size += list2->size;
	list1->size = list1->size;
	printf("Size join: %d, ",list1->size);
}
void list_bubble_sort(List *list, int (*cmpfct) (const void*, const void*)){
	int isGood = 0;
	Node *tmp;
	void *swapper = NULL;
	while (!isGood){
		isGood = 1;
		tmp = list->first;
		while (tmp != list->last){
			if (cmpfct(tmp->value, tmp->next->value) > 0){
				isGood = 0;
				swapper = tmp->value;
				tmp->value = tmp->next->value;
				tmp->next->value = swapper;
			}
			tmp = tmp->next;
		}
	}
}
