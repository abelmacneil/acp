#include <stdio.h>
#include <stdlib.h>
#include "vector.h"

#define N 10
void dump_vec(struct Vector *vec){
	void **iter;
	int *ptr;
	VECTOR_FOREACH(vec, ptr)
		printf("%d, ", *ptr);
	printf("\n");
}
int intcmp(const void *p1, const void*p2){
	int v1 = *(int*)p1;
	int v2 = *(int*)p2;
	if (v1 < v2)
		return 1;
	else if (v1 == v2)
		return 0;
	else
		return -1;
}

int main(){
	struct Vector *vec = vector_new(N);
	int i, *ptr;
	for(i = 0; i < N; i++){
		ptr = malloc(sizeof(int));
		*ptr =  N - i;
		vector_push(vec, ptr);
	}
	//dump_vec(vec);
	/*while (vec-> size > 1){
		vector_pop(vec);
	}*/
	void **iter;
	//vector_qsort(vec, intcmp);
	vector_resize(vec,2* N);
	vector_push(vec, NULL);
	VECTOR_FOREACH(vec, ptr){
		if (ptr != NULL){
			*ptr = 3;
			printf("%d, ", *ptr);
		}
		else 
			printf("null");
	}
	printf("\n");
	//ptr = malloc(sizeof(int));
	//*ptr = 100;
	//vector_insert(vec, 2, ptr);
	//vector_delete(vec, 3);
	//vector_delete(vec, ptr);
	dump_vec(vec);
	vector_destroy(vec);
	return 0;
}
