#ifndef VECTOR_H_INCLUDED
#define VECTOR_H_INCLUDED
#include <stdlib.h>
/**
 * A representation of a dynamic array. As elements are added to the vector,
 * the vector will allocate memory as needed, by allocating double the 
 * current size of the array.
 */
//typedef struct struct Vector struct Vector;
struct Vector;
/**
 * Gets the size of the vector.
 * @param V the vector.
 */
//#define vector_size(V) ((V)->size)
inline size_t vector_size(struct Vector *vec);
/**
 * Gets the capacity of the vector, 
 * the number of items that have been allocated.
 * @param V the vector.
 */
//#define vector_capacity(V) ((V)->capacity)
inline size_t vector_capacity(struct Vector *vec);
/**
 * Creates a new struct Vector.
 * @param capacity the intial capacity of the vector.
 * @return a newly allocated vector.
 */
struct Vector *vector_new(size_t capacity);
/**
 * Clears and frees all the elements in the vector.
 * @param vec the vector.
 */
void vector_clear(struct Vector *vec);
/**
 * Destroys the vector, and frees all its contents.
 * @param vec the vector.
 */
void vector_destroy(struct Vector *vec);
/**
 * Gets an element from the vector at the specified index.
 * @param vec the vector.
 * @param index the index of the item to get.
 */
inline void *vector_get(struct Vector *vec, size_t index);
/**
 * Sets the element of the vector at the specified index.
 * @param vec the vector.
 * @param index the index of the element to set.
 * @param val the value of the element to be set.
 */
inline void vector_set(struct Vector *vec, size_t index, void *val);
/**
 * Pushes an element onto the end of the vector.
 * @param vec the vector.
 * @param element the element to append to the vector.
 */
void vector_push(struct Vector *vec, void *element);
/**
 * Pops off the last element of the vector and returns it.
 * @param vec the vector.
 * @return the element that has been removed.
 */
void *vector_pop(struct Vector *vec);
/**
 * Resizes the vector to hold the specified number of elements.
 * @param vec the vector.
 * @param n the number of elements the vector should hold.
 */
void vector_resize(struct Vector *vec, size_t n);
void vector_expand(struct Vector *vec);
/*
 * Shinks the vector to hold as many elements have been set.
 * @param vec the vector.
 */
void vector_shink_to_fit(struct Vector *vec);
/**
 * Inserts an item into the vector before the index,
 * increasing the size, relocating elements after.
 * @param vec the vector.
 * @param index the index to insert at.
 * @param val the value to store at the index.
 */
void vector_insert(struct Vector *vec, size_t index, void *val);
/**
 * Deletes the element of the vector at the specified index.
 * @param vec the vector.
 * @param index the index of the value to delete
 * @return the value of the deleted element (not freed).
 */
void *vector_delete_at(struct Vector *vec, size_t index);
int vector_delete(struct Vector *vec, void *value);
/**
 * Sorts the data of the vector using the quicksort found int stdlib.h
 * @param vec the vector.
 * @param the comparison function by which to sort elements.
 *      Negative if the first value is lower, zero if they are equal,
 *		positive if this first value is of a higher rank.
 */
void vector_qsort(struct Vector *vec, int (*cmp) (const void*,const void*));
/**
 * Gets a pointer to the first element in the vector.
 * @param vec the vector.
 * @return a pointer to the first element in the vector.
 */
inline void **vector_begin(struct Vector *vec);
/**
 * Gets a pointer to one past the last element in the vector.
 * @param vec the vector.
 * @return a pointer to the fone past the last element in the vector.
 */
inline void **vector_end(struct Vector *vec);
/**
 * A control construct for iterating over a vector.
 * @param vector the vector.
 * @param iter the iterator of type void**.
 * @param elem a pointer to the type of element in the vector.
 */
#define VECTOR_FOREACH_(vec, iter, elem) \
	for (iter = vector_begin(vec), elem = *iter; \
			iter != vector_end(vec);\
			++iter, elem = *iter)

#define VECTOR_FOREACH(vec, elem) \
	void **iter__##elem##__; \
VECTOR_FOREACH_(vec, iter__##elem##__,elem)

#endif
