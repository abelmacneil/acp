#include "hashset.h"
#include "hash.h"
#include "vector.h"
#include <stddef.h>
#include <stdio.h>

#define NUMBER_OF_BUCKETS 32

#define HASHSET_FOREACH(set, node) \
    VECTOR_FOREACH(set->buckets, bucket) \
        for( ;bucket != NULL; bucket = bucket->next)

struct HashSet {
    struct Vector *buckets;
    uint32_t (*hash) (void *val);
    int (*compare) (void *val1, void *val2);
    size_t size;
    size_t capacity;
};

struct HashSetNode {
    void *data;
    struct HashSetNode *next;
};

static void rehash(struct HashSet *set, size_t size);

struct HashSet *hashset_new(uint32_t (*hash_fct) (void *val),
        int (*cmp_fct) (void *val1, void *val2))
{
    struct HashSet *set = malloc(sizeof(struct HashSet));
    set->hash = hash_fct == NULL ? str_hash : hash_fct;
    set->compare = cmp_fct == NULL ? str_cmp : cmp_fct;
    set->size = 0;
    set->capacity = NUMBER_OF_BUCKETS;
    set->buckets = vector_new(set->capacity);
    vector_expand(set->buckets);
    return set;
}

static struct HashSetNode *hashset_node_new(void *data)
{
    struct HashSetNode *node = malloc(sizeof(struct HashSetNode));
    node->data = data;
    node->next = NULL;
    return node;
}

int hashset_insert(struct HashSet *set, void *data)
{
    if (set->size + 1 >= 3 * set->capacity / 4)
        rehash(set, set->capacity << 1);
    uint32_t hash = set->hash(data); 
    size_t index = hash % set->capacity;
    //printf("[%d] = %d\n", index, *(int*)data);
    struct HashSetNode *node = vector_get(set->buckets, index);
    if (node == NULL) {
        node = hashset_node_new(data);
        vector_set(set->buckets, index, node);
    } else {
        struct HashSetNode *prev;
        while (node != NULL) {
            if (set->compare(node->data, data) == 0) {
                return BAD_INSERT;
            }
            prev = node;
            node = node->next;
        }
        prev->next = hashset_node_new(data);
    }
    set->size++;
    return GOOD_INSERT;
}
void *hashset_remove(struct HashSet *set, void *data)
{
    uint32_t hash = set->hash(data); 
    size_t index = hash % set->capacity;
    //printf("[%d] = %d\n", index, *(int*)data);
    struct HashSetNode *node = vector_get(set->buckets, index);
    if (node == NULL) {
        return NULL;
    } else if (set->compare(node->data, data) == 0){
        void *val = node->data;
        vector_set(set->buckets, index, node->next);
        free(node);
        set->size--;
        return val;
    }
    else {
        struct HashSetNode *prev;
        while (node != NULL) {
            if (set->compare(node->data, data) == 0) {
                void *val = node->data;
                prev->next = node->next;
                free(node);
                set->size--;
                return val;
            }
            prev = node;
            node = node->next;
        }
    }
    return NULL;
}

bool hashset_contains(struct HashSet *set, void *data)
{
    struct HashSetNode *bucket;
    HASHSET_FOREACH(set, bucket) {
        if (set->compare(bucket->data, data) == 0)
            return true;
    }
    return false;
}

void hashset_foreach(struct HashSet *set, void (*fct) (void *val))
{
    struct HashSetNode *bucket;
    HASHSET_FOREACH(set, bucket) {
        fct(bucket->data);
    }
}

struct HashSet *hashset_map(struct HashSet *set, void *(*fct) (void *val))
{
    struct HashSet *res = hashset_new(set->hash, set->compare);
    struct HashSetNode *bucket;
    HASHSET_FOREACH(set, bucket) {
        hashset_insert(res, fct(bucket->data));
    }
    return res;
}

void *hashset_fold(struct HashSet *set, void *init, 
        void *(*fct) (void *acc, void *data))
{
    void *acc = init;
    struct HashSetNode *bucket;
    HASHSET_FOREACH(set, bucket) {
        acc = fct(acc, bucket->data);
    }
    return acc;
}
void hashset_copy(struct HashSet *dest, struct HashSet *src)
{
    struct HashSetNode *bucket;
    HASHSET_FOREACH(src, bucket) {
        hashset_insert(dest, bucket->data);
    }
}

struct HashSet *hashset_union(struct HashSet *setA, struct HashSet *setB)
{
    struct HashSet *setC = hashset_new(setA->hash, setA->compare);
    hashset_copy(setC, setA);
    hashset_copy(setC, setB);
    return setC;
}
struct HashSet *hashset_intersection(struct HashSet *setA, struct HashSet *setB)
{
    struct HashSet *res = hashset_new(setA->hash, setA->compare);
    struct HashSetNode *bucket;
    HASHSET_FOREACH(setB, bucket) {
        if (hashset_contains(setA, bucket->data)){
            hashset_insert(res, bucket->data);
        }
    }
    return res;
}

struct HashSet *hashset_difference(struct HashSet *setA, struct HashSet *setB)
{
    struct HashSet *res = hashset_new(setA->hash, setA->compare);
    struct HashSetNode *bucket;
    HASHSET_FOREACH(setA, bucket) {
        if (!hashset_contains(setB, bucket->data)){
            hashset_insert(res, bucket->data);
        }
    }
    return res;
}

bool hashset_subset(struct HashSet *setA, struct HashSet *setB)
{
    bool res = true;
    struct HashSetNode *bucket;
    HASHSET_FOREACH(setA, bucket) {
        res = res && hashset_contains(setB, bucket->data);
        if (!res)
            return false;
    }
    return res;
}

static void rehash(struct HashSet *set, size_t size)
{
    struct Vector *oldbuckets = set->buckets;
    set->buckets = vector_new(size);
    set->capacity = size;
    set->size = 0;
    vector_expand(set->buckets);
    struct HashSetNode *bucket, *prev;
    VECTOR_FOREACH(oldbuckets, bucket) {
        while (bucket != NULL) {
            hashset_insert(set, bucket->data);
            prev = bucket;
            bucket = bucket->next;
            free(prev);
        }
    }
    vector_destroy_vec(oldbuckets);
}

void hashset_destroy_contents(struct HashSet *set)
{
    struct HashSetNode *bucket, *prev;
    VECTOR_FOREACH(set->buckets, bucket) {
        while(bucket != NULL) {
            if (bucket->data)
                free(bucket->data);
            prev = bucket;
            bucket = bucket->next;
            free(prev);
        }
    }
}

void hashset_destroy_set(struct HashSet *set)
{
    vector_destroy_vec(set->buckets);
    free(set);
}

void hashset_destroy(struct HashSet *set)
{
    hashset_destroy_contents(set);
    hashset_destroy_set(set);
}

