#include <stdio.h>
#include "hash.h"
#include <stdlib.h>
#include "hashmap.h"
#include <string.h>
#include <assert.h>
#define N 10
void print_node(void *key, void *val)
{
	printf("%-10s => %2d\n", (char*)key, *(int*)val);
}
void dump_hashmap(struct HashMap *map)
{
	hashmap_foreach(map, &print_node);
}
int main(){
	struct HashMap *map = hashmap_new(NULL,NULL);
	printf("struct HashMap Test:\n");
	const size_t n = 23;
	size_t i, *ptr;
	char *keys[] = {"zero", "one", "two", "three", "four", "five", "six",
		"seven","eight","nine","ten","eleven","twelve","thirteen",
		"fourteen", "fifteen", "sixteen","seventeen","eighteen","nineteen",
	"twenty", "twenty-one","twenty-two"};
	for(i = 0; i < n; i++){
		ptr = malloc(sizeof(size_t));
		*ptr = i;
		hashmap_insert(map, keys[i],ptr);
	}
	hashmap_remove(map, "three");
	assert(hashmap_get(map,"three") == NULL);
	ptr = malloc(sizeof(int));
	*ptr = 33;
	hashmap_insert(map, "three", ptr);
	dump_hashmap(map);
	i = 17;
	assert(*(int*)hashmap_get(map, keys[i]) == i);
	for(i = 0; i < n; i++){
		ptr = hashmap_get(map,keys[i]);
		if (ptr != NULL)
			printf("%-10s => %2d : 0x%08X\n", keys[i], *ptr,
					str_hash(keys[i]));
		else printf("null\n");
	}
	printf("size :%u\n", hashmap_size(map));
  hashmap_destroy_values(map);
	hashmap_destroy(map);

	map = NULL;
	return 0;
}
