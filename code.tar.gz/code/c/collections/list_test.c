#include <stdio.h>
#include <stdlib.h>
#include "list.h"

#define N 100000

int intcmp(const void *p1, const void*p2){
	int v1 = *(int*)p1;
	int v2 = *(int*)p2;
	if (v1 < v2)
		return -1;
	else if (v1 == v2)
		return 0;
	else
		return 1;
}
void dump_list(List * lst){
	LIST_FOREACH(lst,first, next,node){
		printf("%d, ",*(int*)node->value);
	}
	printf("\n");
}

int main (){
	//*
	List *lst = list_new();
	int i, n = 5, *ptr;
	for(i = 0; i < n; i++){
		ptr = malloc(sizeof(int));
		*ptr =  n - i;
		list_push(lst, ptr);
	}
	List *lst2 = list_copy(lst);
	list_join(lst,lst2);
	printf("Size: %d\n", lst->size);
	printf("Initial list:\n");
	dump_list(lst);
	printf("Sorted list:\n");
	list_bubble_sort(lst,&intcmp);
	dump_list(lst);
	printf("Size: %d\n", lst->size);
	while (lst->size != 0) {
		*(int*)list_pop(lst);
	}

	printf("Size after removal: %d\n", lst->size);
	list_clear_destroy(lst);
	//*/
	/*
	List *lst = list_new();
	void *vp;
	int i, *ptr;
	while(1){
		for(i = 0; i < N; i++){
			ptr = malloc(sizeof(int));
			*ptr = i;
			vp = ptr;
			list_push(lst, vp);
		}
		list_clear_destroy(lst);
		lst = list_new();
	}
	//*/
	return 0;
}
