#include <stdio.h>

char * tobin (char);

int main (int argc, char ** argv){
  tobin ((char)atoi(argv[1]));
  //printf("%d\n", 5 & 1<<2);
  return 0;
}

char * tobin (char num){
  char i;
  for(i = 0; i < 8; i++){
	printf ("%d", num>>7 & 1);
	num = num << 1;
  }
  printf("\n");
}
