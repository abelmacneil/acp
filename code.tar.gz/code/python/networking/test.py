import pcapy, math

print len(str(math.factorial(1000)))

