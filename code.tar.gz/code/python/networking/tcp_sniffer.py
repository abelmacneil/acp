#TCP Packet Sniffer

import socket, sys, struct

s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)

while True:
	try:
		packet =  s.recvfrom(65565)
		packet = packet[0]
		
		ip_header = packet[0:20]
		
		iph = struct.unpack('!BBHHHBBH4s4s', ip_header);
		
		version_ihl = iph[0]
		version = version_ihl >> 4
		ihl = version_ihl & 0xF
		
		iph_length = ihl * 4
		ttl = iph[5]
		protocol = iph[6]
		if protocol == 6:
			protocol = 'TCP'
		#converts 4 byte string to ip address
		sock_addr = socket.inet_ntoa(iph[8])
		try:
			sock_name = socket.gethostbyaddr(sock_addr)[0]
		except socket.herror as e:
			sock_name = sock_addr
		
		d_addr = socket.inet_ntoa(iph[9])
		try:
			dest_name = socket.gethostbyaddr(d_addr)[0]
		except socket.herror as e:
			dest_name = d_addr

		tcp_header = packet[iph_length:iph_length + 20]
		
		tcph = struct.unpack('!HHLLBBHHH', tcp_header)
		
		source_port = tcph[0]
		dest_port = tcph[1]
		sequence = tcph[2]
		acknowledgement = tcph[3]
		doff_reserved = tcph[4]
		tcph_length = doff_reserved >> 4 	
		
		#Data
		h_size = iph_length + tcph_length * 4
		data_size = len(packet) - h_size
		
		#get data from packet
		data = packet[h_size:]
		
		if data_size > 2:
			print 'Version:' + str(version) + ', IP Header Len:' + str(ihl) + \
			', TTL:' + str(ttl) + ', Protocol:' + str(protocol) + \
			', Source:' + str(sock_name) + ', Destination:' + str(dest_name)
			
			print 'Source Port : ' + str(source_port) + ' Dest Port : ' + str(dest_port) +\
			' Sequence Number : ' + str(sequence) + ' Acknowledgement : ' + str(acknowledgement) +\
			' TCP header length : ' + str(tcph_length)
			
			print 'Data size (' + str(data_size) + ')'
			print
	
	except KeyboardInterrupt as e:
		print "\nExiting..."
		s.close()
		quit()
