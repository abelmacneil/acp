import socket, sys

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_addr = ('192.168.1.101', 10000)

print '%s on %s' % server_addr
sock.connect(server_addr)
message = ' '
try:
    # Send data
    while True:
		print 'Enter the message you would like to send: '
		message = raw_input()
		
		if message == '_EXIT': break
		message += '\n'
		print  'sending "%s"' % message
		sock.sendall(message)

		# Look for the response 
		amount_received = 0
		amount_expected = len(message)
		
		while amount_received < amount_expected:
			data = sock.recv(16)
			amount_received += len(data)
			#print 'received "%s"' % data

finally:
    print 'closing socket'
    sock.close()
