import socket, sys

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_addr = ('192.168.1.101', 10000)

print '%s on %s' % server_addr
sock.bind(server_addr)


while True:
	sock.listen(1)
	print 'Waiting...'
	connection, client_addr = sock.accept()
	try:
		print 'connection from', client_addr

        # Receive the data in small chunks and retransmit it
		while True:
			data = connection.recv(16)
			sys.stderr.write(data)
			if data:
				#Send the data back to the client
				connection.sendall(data)
			else:
				print '\nno more data from', client_addr
				break
            
	finally:
		# Clean up the connection
		connection.close()
