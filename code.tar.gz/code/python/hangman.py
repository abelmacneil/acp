#-------------------------------------------------------------------------------
# Name:        hangman
# Purpose:
#
# Author:      Abel_2
#
# Created:     17/02/2013
# Copyright:   (c) Abel_2 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
def trim(string):
    newstring = ''
    for char in string:
        if char != ' ':
            newstring += char
    return newstring

def replace(guesses,text,word):
    newstring = ''
    text = list(text)
    for guess in guesses:
        for i in range(len(word)):
            if word[i] == guess:
                text[i] = guess
    for i in text:
        newstring += i
    return newstring

def addspaces(string):
    newstring = ''
    for char in string:
        newstring += char + ' '
    return newstring
import random

def main():
    words = []
    with open('simpleList.txt') as f:
        words = f.readlines()
    word = random.choice(words)[:-1]
    text = ''
    for i in range(len(word)):
        text += '_ '
    correctGuesses = []
    wrongGuesses = []
    maxGuesses = 6
    while trim(text) != word and len(wrongGuesses) < maxGuesses:
        guess = raw_input(text + ' :' +str(maxGuesses - len(wrongGuesses)))
        if guess in word:
            correctGuesses.append(guess)
            text = addspaces(replace(correctGuesses,trim(text),word))
        else:
            wrongGuesses.append(str(guess))
            print wrongGuesses
    if trim(text) == word:
        print 'You won!', word
    else:
        print 'You lost',word

if __name__ == '__main__':
    main()
