
def sumN(start, stop):
	if start == stop:
		return start
	return sumN(start, stop - 1) + stop

def pascal(n):
	if n == 0:
		print([1])
		return [1]
	prev_row = pascal(n - 1)
	new_row = [1]
	for i in range(1,len(prev_row)):
		new_row.append(prev_row[i - 1] + prev_row[i])
	new_row.append(1)
	print (new_row)
	return new_row
	
def sumEven(start, stop):
	if stop % 2 != 0:
		stop -= 1
	if start == stop:
		return stop
	elif start > stop:
		return 0
	else:
		return sumEven(start, stop - 2) + stop
		
def sumOdd(start, stop):
	if stop % 2 == 0:
		stop -= 1
	if start == stop:
		return stop
	elif start > stop:
		return 0
	else:
		return sumOdd(start, stop - 2) + stop

def printTri(n, char):
	if n == 1:
		print (char)
		return
	printTri(n - 1, char)
	for i in range(n):
		print(char,end = '')
	print()
	
def printEmptyTri(n, char):
	if n == 1:
		print (char)
		return
	printEmptyTri(n - 1, char)
	for i in range(n):
		if i == 0 or i == n - 1:
			print(char,end='')
		else:
			print(' ', end='')
	print()
		
		
def main():
	printEmptyTri(10, '#')
	
if __name__ == "__main__":
	main()
