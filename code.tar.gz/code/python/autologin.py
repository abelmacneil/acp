#!/usr/bin/env python
import os, subprocess, sys

def set_auto_login(user):
    path = "/etc/systemd/system/autologin@.service"
    if user != "":
        user = "-a " + user
    inf = open(path)
    lines = inf.readlines()
    inf.close()
    with open(path, "w") as outf:
        for line in lines:
            if "ExecStart" in line:
                outf.write("ExecStart=-/sbin/agetty --noclear " + user + " %I 38400 linux\n")
            else:
                outf.write(line)

def main():
    if os.getuid() != 0:
        print ("Must be root...")
        return
    if len(sys.argv) > 1:
        username = sys.argv[1]
    else:
        username = ''
    set_auto_login(username)
    subprocess.call(['systemctl', 'daemon-reload'])

if __name__ == "__main__":
    main()
