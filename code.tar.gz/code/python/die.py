#!/usr/bin/env python
import os
while True:
	try:
		print(os.urandom(16), end='')
	except KeyboardInterrupt:
		print()
		exit(0)
