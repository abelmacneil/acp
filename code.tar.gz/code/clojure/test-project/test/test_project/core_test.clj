(ns test-project.core-test
  (:require [clojure.test :refer :all]
            [test-project.core :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
