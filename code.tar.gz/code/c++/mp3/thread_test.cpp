#include <iostream>
#include "timer.hpp"
void foo(int bar)
{
	std::cout << bar << "!\n";
}
int main(void)
{
	Timer t(false, 4,foo, 40);
	std::chrono::milliseconds millis{2*1000};
	t.updateTime(1);
	t.start();
	std::this_thread::sleep_for(millis);
	t.stop();
	std::cout << "Main Finished\n";
	t.restart(2,foo, 41);
	return 0;
}
