#include "audio.hpp"
#include <iostream>
#include <cstdlib>
//CLASS VARS
bool Audio::isInit = false;
FMOD::System *Audio::system;
FMOD_RESULT Audio::result;
uint32_t Audio::version;
int Audio::ndrivers;
FMOD_SPEAKERMODE Audio::speaker_mode;
FMOD_CAPS Audio::caps;
char Audio::name[256];
FMOD::Sound *Audio::audioStream;
FMOD::Channel *Audio::channel;

void Audio::errorCheck(FMOD_RESULT r)
{
	if (r != 0) {
		std::cerr << "error (" << r << ")" << std::endl;
		exit(1);
	}
}

void Audio::init(void)
{
	if (!isInit) {
		result = FMOD::System_Create(&system);
		errorCheck(result);
		result = system->getVersion(&version);
		errorCheck(result);
		result = system->getNumDrivers(&ndrivers);
		errorCheck(result);
		if (ndrivers == 0){
			result = system->setOutput(FMOD_OUTPUTTYPE_NOSOUND);
			errorCheck(result);
		} else {
			//capabilities of card 0
			result = system->getDriverCaps(0, &caps, 0, &speaker_mode);
			errorCheck(result);
			result = system->setSpeakerMode(speaker_mode);
			errorCheck(result);
		}
		// Increase buffer size if user has Acceleration slider set to off
		if (caps & FMOD_CAPS_HARDWARE_EMULATED) {
			result = system->setDSPBufferSize(1024, 10);
			errorCheck(result);
		}
		result = system->getDriverInfo(0, name, 256, 0);
		errorCheck(result);
		//finally init the system
		result = system->init(100, FMOD_INIT_NORMAL, 0);
		// If the selected speaker mode isn't supported by this sound card, switch it back to stereo
		if (result == FMOD_ERR_OUTPUT_CREATEBUFFER) {
			result = system->setSpeakerMode(FMOD_SPEAKERMODE_STEREO);
			errorCheck(result);
			result = system->init(100, FMOD_INIT_NORMAL, 0);
		}
		errorCheck(result);
		isInit = true;
	}
}

void Audio::load(std::string filename)
{
	system->createStream(filename.c_str() , FMOD_DEFAULT, 0, &audioStream);
}

void Audio::unload(void)
{
	if (isInit && audioStream != nullptr) {
		audioStream->release();
	}
}

void Audio::play(bool pause)
{
	if (isInit && audioStream != nullptr) {
		system->playSound(FMOD_CHANNEL_FREE, audioStream, pause, &channel);
	}
}

bool Audio::isPaused(void)
{
	bool isPause = false;
	if (isInitialized() && channel != nullptr)
		channel->getPaused(&isPause);
	return isPause;
}
void Audio::pause(void)
{
	bool isPause = isPaused();
	if (!isPause) {
		setPause(true);
	}
}

void Audio::setPause(bool pause)
{
	if (isInitialized() && channel != nullptr)
		channel->setPaused(pause);
}

void Audio::togglePause(void)
{
	setPause(!isPaused());
}

bool inline Audio::isInitialized(void)
{
	return isInit;
}

void Audio::setVolume(float vol)
{
	if (channel != nullptr) {
		channel->setVolume(vol);
	}
}
void Audio::release(void)
{
	unload();
	system->release();
	isInit = false;
}

uint32_t Audio::getPosition(void)
{
	uint32_t curPos = 0;
	if (isInitialized() && channel != nullptr) {
		channel->getPosition(&curPos,FMOD_TIMEUNIT_MS);
	}
	return curPos;
}
void Audio::fastForward(uint32_t timeMs)
{
	uint32_t curPos = getPosition();
	if (isInitialized() && channel != nullptr) {
		channel->setPosition(curPos + timeMs, FMOD_TIMEUNIT_MS);
	}
}
void Audio::rewind(uint32_t timeMs)
{
	uint32_t curPos = getPosition();
	if (curPos < timeMs){
		curPos = 0;
		timeMs = 0;
	}
	if (isInitialized() && channel != nullptr) {
		channel->setPosition(curPos - timeMs, FMOD_TIMEUNIT_MS);
	}
}

void Audio::replay(void)
{
	if (isInitialized() && channel != nullptr) {
		channel->setPosition(0,FMOD_TIMEUNIT_MS);
	}
}

void Audio::loop(void)
{
	channel->setMode(FMOD_LOOP_NORMAL);
	channel->setLoopCount(-1);
}
