#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <bitset>
#include <id3/tag.h>
#include <taglib/tag.h>
#include <taglib/fileref.h>


int main()
{
	/*ID3_Tag myTag {"test.mp3"};
	ID3_Tag::Iterator* iter = myTag.CreateIterator();
	ID3_Frame* myFrame = NULL;
	while (NULL != (myFrame = iter->GetNext()))
	{
		std::cout << myFrame << '\n';
		/*ID3_Frame::Iterator* iter2 = myFrame->CreateIterator();
		ID3_Field *myField;
		while ((myField = iter2->GetNext()) != NULL) {
			//ID3_Field *myField = myFrame->GetField(ID3FN_TEXT);
			std::cout << myField->GetRawText() << '\n';
		}
		delete iter2;

	}
	myFrame = myTag.Find(ID3FID_ALBUM);
	ID3_Frame::Iterator* iter2 = myFrame->CreateIterator();
	ID3_Field *myField;
	while ((myField = iter2->GetNext()) != NULL) {
	//ID3_Field *myField = myFrame->GetField(ID3FN_TEXT);
		std::cout << myField->GetRawText() << '\n';
	}
	delete iter;
	//delete iter2;*/
	TagLib::FileRef f("test.mp3");
	std::cout << f.tag()->artist() << '\n';
	std::cout << f.tag()->album() << '\n';
	std::cout << f.tag()->title() << '\n';
	std::cout << f.tag()->comment() << '\n';
	std::cout << f.tag()->genre() << '\n';
	std::cout << f.tag()->year() << '\n';
	std::cout << f.tag()->track() << '\n';
	return 0;

}
