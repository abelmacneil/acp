#include "inc/fmod.hpp"
#include "inc/fmod_errors.h"
#include <stdint.h>
#include <string>
class Audio {
	private:
		Audio();
		static bool isInit;
		static FMOD::System *system;
		static FMOD_RESULT result;
		static uint32_t version;
		static int ndrivers;
		static FMOD_SPEAKERMODE speaker_mode;
		static FMOD_CAPS caps;
		static char name[256];
		static FMOD::Sound *audioStream;
		static FMOD::Channel *channel;
		static void errorCheck(FMOD_RESULT result);
		static bool isPlayable(void);
	public:
		static void init(void);
		static void release(void);
		static bool isInitialized(void);
		static void load(std::string filename);
		static void unload(void);
		static void play(bool pause = false);
		static bool isPaused(void);
		static void pause(void);
		static void setPause(bool pause);
		static void togglePause(void);
		static void setVolume(float vol);
		static uint32_t getPosition(void);
		static void fastForward(uint32_t timeMs);
		static void rewind(uint32_t timeMs);
		static void replay(void);
		static void loop(void);
};

