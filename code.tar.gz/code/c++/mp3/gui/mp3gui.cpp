#include "mp3gui.hpp"
#include <iostream>

Mp3Gui::Mp3Gui(): 
	mainBox{Gtk::ORIENTATION_VERTICAL,5},
	infoLbl("Artist - Title"),
	prevBtn{"Previous"},
	rewindBtn("Rewind"),
	playBtn("Play"),
	fastFwdBtn("Fast Forward"),
	nextBtn{"Next"}
{
	// Sets the border width of the window.
	set_border_width(10);

	playBtn.signal_clicked().connect(sigc::mem_fun(*this,
				&Mp3Gui::onPlayBtnClicked));

	// This packs the button into the Window (a container).
	mainBox.add(infoLbl);
	btnBox.add(prevBtn);
	btnBox.add(rewindBtn);
	btnBox.add(playBtn);
	btnBox.add(fastFwdBtn);
	btnBox.add(nextBtn);
	mainBox.add(btnBox);
	add(mainBox);
	// The final step is to display this newly created widget...
	infoLbl.show();
	prevBtn.show();
	rewindBtn.show();
	playBtn.show();
	fastFwdBtn.show();
	nextBtn.show();
	btnBox.show();
	mainBox.show();
}

Mp3Gui::~Mp3Gui()
{
}

void Mp3Gui::onPlayBtnClicked()
{
	std::cout << "Play" << std::endl;
}
