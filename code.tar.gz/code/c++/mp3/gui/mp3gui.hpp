#ifndef INCLUDED_MP3GUI_H
#define INCLUDED_MP3GUI_H

#include <gtkmm/button.h>
#include <gtkmm/window.h>
#include <gtkmm/box.h>
#include <gtkmm/label.h>

class Mp3Gui : public Gtk::Window
{

	public:
		Mp3Gui();
		virtual ~Mp3Gui();

	protected:
		//Signal handlers:
		void onPlayBtnClicked();

		//Member widgets:
		Gtk::Box mainBox;
		Gtk::Box btnBox;

		Gtk::Label infoLbl;
		Gtk::Button prevBtn;
		Gtk::Button rewindBtn;
		Gtk::Button playBtn;
		Gtk::Button fastFwdBtn;
		Gtk::Button nextBtn;
};

#endif // INCLUDED_MP3GUI_H
