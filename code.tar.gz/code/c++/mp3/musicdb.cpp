#include "musicdb.hpp"
#include <boost/filesystem.hpp>
#include <algorithm>


MusicDB::MusicDB(const std::vector<std::string>& dirs):
	songs{},
	cmp{}
{
	std::vector<boost::filesystem::path> files;
	for (const auto& dir : dirs) {
		copy(boost::filesystem::directory_iterator(boost::filesystem::path(dir)),
				boost::filesystem::directory_iterator(),
				std::back_inserter(files));
	}
	for(const auto& file : files) {
		if (file.string().substr(file.string().find_last_of(".") + 1) == "mp3") {
			songs.push_back(TagLib::FileRef(file.string().c_str()));
		}
	}
	sortBy(Field::Artist);
}

size_t MusicDB::size(void) const 
{
	return songs.size();
}

void MusicDB::sortBy(Field f)
{
	cmp.setField(f);
	std::sort(songs.begin(), songs.end(), cmp);
}

void MusicDB::reverseOrder(void)
{
	cmp.isNegated = !cmp.isNegated;
	std::sort(songs.begin(), songs.end(), cmp);
}
std::vector<TagLib::FileRef>::const_iterator MusicDB::begin(void) const
{
	return songs.cbegin();
}

std::vector<TagLib::FileRef>::const_iterator MusicDB::end(void) const
{
	return songs.cend();
}

const TagLib::FileRef& MusicDB::operator[](size_t index)
{
	return songs[index];
}

MusicDB::Comparator::Comparator() :
	isNegated{false}
{
}

bool MusicDB::Comparator::cmpArtist(const TagLib::FileRef& s1, 
		const TagLib::FileRef& s2)
{
	if (s1.tag()->artist() != s2.tag()->artist()) {
		return s1.tag()->artist() < s2.tag()->artist();
	} else if (s1.tag()->title() != s2.tag()->title()) {
		return s1.tag()->title() < s2.tag()->title();
	} else {
		return s1.tag()->album() < s2.tag()->album();
	}
}

bool MusicDB::Comparator::cmpTitle(const TagLib::FileRef& s1, const TagLib::FileRef& s2)
{
	if (s1.tag()->title() != s2.tag()->title()) {
		return s1.tag()->title() < s2.tag()->title();
	} else if (s1.tag()->artist() != s2.tag()->artist()) {
		return s1.tag()->artist() < s2.tag()->artist();
	} else {
		return s1.tag()->album() < s2.tag()->album();
	}
}

void MusicDB::Comparator::setField(Field f)
{
	switch(f) {
		case MusicDB::Field::Artist: 
			curFct = &Comparator::cmpArtist; 
			break;
		case MusicDB::Field::Title: 
			curFct = &Comparator::cmpTitle; 
			break;
	}
}

bool MusicDB::Comparator::operator()(const TagLib::FileRef& s1, const TagLib::FileRef& s2)
{
	bool val = (this->*curFct)(s1, s2);
	if (isNegated)
		return !val;
	else
		return val;
}


