#ifndef MUSIC_DB_H_INCLUDED
#define MUSIC_DB_H_INCLUDED
#include <taglib/fileref.h>
#include <string>

class MusicDB {
	public:
		MusicDB(const std::vector<std::string> &dirs);
		enum class Field {
			Artist, Title
		};
		size_t size(void) const;
		void sortBy(Field f);
		void reverseOrder();
		const TagLib::FileRef& operator[](size_t index);
		std::vector<TagLib::FileRef>::const_iterator begin(void) const;
		std::vector<TagLib::FileRef>::const_iterator end(void) const;
	private:
		class Comparator {
			public:
				Comparator();
				void setField(Field field);
				bool operator()(const TagLib::FileRef &s1, const TagLib::FileRef &s2);
				bool isNegated;
			private:
				bool (MusicDB::Comparator::*curFct) (const TagLib::FileRef &s1, const TagLib::FileRef &s2);
				
				bool cmpArtist(const TagLib::FileRef &s1, const TagLib::FileRef &s2);
				bool cmpTitle(const TagLib::FileRef &s1, const TagLib::FileRef &s2);
		};
		std::vector<TagLib::FileRef> songs;
		Comparator cmp;
};
#endif //MUSIC_DB_H_INCLUDED
