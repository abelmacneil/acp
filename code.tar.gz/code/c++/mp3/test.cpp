#include "music_manager.hpp"
#include <chrono>
using namespace std::chrono;

int main (int argc, char **argv) 
{
	auto t0 = high_resolution_clock::now();
	MusicManager m("/media/0/music/");
	auto t1 = high_resolution_clock::now();
	std::cout << (duration_cast<nanoseconds>(t1-t0).count()/(10e9)) << "\n";
	
	return 0;
}
