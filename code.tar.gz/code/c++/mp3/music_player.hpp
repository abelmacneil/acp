#ifndef MUSIC_PLAYER_H_INCLUDED
#define MUSIC_PLAYER_H_INCLUDED
#include "musicdb.hpp"
#include "timer.hpp"
#include <vector>
#include <string>
#include <taglib/fileref.h>
#include <thread>
class MusicPlayer {
	public:
		MusicPlayer(const std::vector<std::string>& dirs);
		~MusicPlayer();
		const TagLib::FileRef& currentSong(void);
		const TagLib::FileRef& playCurrentSong(void);
		const TagLib::FileRef& playNextSong(void);
		const TagLib::FileRef& playPreviousSong(void);
		const TagLib::FileRef& playSongAt(size_t index);
		const MusicDB& db() const;
		bool isPaused(void);
		void pause(void);
		void setPause(bool pause);
		void togglePause(void);
		uint32_t getPosition(void);
		void fastForward(uint32_t timeMs);
		void rewind(uint32_t timeMs);
		void replay(void);
		void loop(void);

	private:
		MusicDB musicDB;
		size_t curIndex;
		Timer timer;

		const TagLib::FileRef& playSong(const TagLib::FileRef& song);
		const TagLib::FileRef& nextSong(void);
		const TagLib::FileRef& previousSong(void);
		const TagLib::FileRef& setCurrentSong(size_t index);
		void timedNextSong(int time);
};

#endif //MUSIC_PLAYER_H_INCLUDED
