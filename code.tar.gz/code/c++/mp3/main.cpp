#include "music_player.hpp"
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <taglib/fileref.h>

constexpr uint32_t DEFAULT_RATE = 2;
constexpr uint32_t SECOND = 1000;


std::string getHelpString(void)
{
	std::stringstream s;
	s << "Help Intructions" << std::endl;
	s << "p to play/pause." << std::endl;
	s << "q to quit." << std::endl;
	s << "f to fast forward 2 seconds." << std::endl;
	s << "f[n] to fast forward n seconds." << std::endl;
	s << "\tex. f10 fast forwards 10 seconds." << std::endl;
	s << "r to rewind 2 seconds." << std::endl;
	s << "r[n] to rewind n seconds." << std::endl;
	s << "\tex. r10 rewinds 10 seconds." << std::endl;
	s << "rr to replay the file." << std::endl;
	return s.str();
}
void printInfo(const TagLib::FileRef& info)
{
	std::cout << info.tag()->artist() << " - ";
	std::cout << info.tag()->title() << " ("; 
	std::cout << (info.audioProperties()->length() /60) << ":";
	std::cout << std::setfill('0') << std::setw(2);
	std::cout << (info.audioProperties()->length() %60) << ")\n";
}

void printNewSong(const TagLib::FileRef& song)
{
	std::cout << "Now Playing: ";
	printInfo(song);
}

int main (int argc, char **argv)
{
	MusicPlayer player{std::vector<std::string>{"./files"}};
	std::cout << "hello";
	std::string input;
	const std::string EXIT_STR ("q");
	constexpr char EXIT_CHAR = 'q';
	uint32_t ffTime;
	TagLib::FileRef curSong = player.playCurrentSong();
	printNewSong(curSong);
	do {
		std::cin >> input;
		if (input[0] == 'n'){
			if (input.length() == 1){
				printNewSong(player.playNextSong());
			}else {
				size_t index;
				std::istringstream(input.substr(1)) >> index;
				if (index <= player.db().size()){
					printNewSong(player.playSongAt(index - 1));
				}
				else
					std::cout << "Track " << index << " not available.\n";
			}
		} else if (input == "N") {
			printNewSong(player.playPreviousSong());
		} else if (input == "p") {
			player.togglePause();
		} else if (input[0] == 'h') {
			std::cout << getHelpString() << std::endl;
		} else if (input == "loop") {
			player.loop();
		} else if (input == "list") {
			std::cout << "Total " << player.db().size() << " songs:\n";
			size_t i = 0;
			for (const auto& song : player.db()) {
				std::cout << ++i << ": ";
				printInfo(song);
			}
		} else if (input == "rr"){
			player.replay();
		} else if (input[0] == 'f' || input[0] == 'r') {
			ffTime = DEFAULT_RATE * SECOND;
			if (input.length() > 1) {
				std::istringstream(input.substr(1)) >> ffTime;
				ffTime *= SECOND;
			}
			if (input[0] == 'f')
				player.fastForward(ffTime);
			else 
				player.rewind(ffTime);
		}
	} while (input[0] != EXIT_CHAR);
	return 0;
}
