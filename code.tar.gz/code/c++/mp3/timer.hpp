#ifndef TIMER_H_INCLUDED
#define TIMER_H_INCLUDED
#include <thread>
#include <mutex>
#include <chrono>
#include <cstdint>
#include <iostream>
class Timer {
	private:
		bool isStopped;
		bool isStarted;
		uint32_t time;
		std::thread thd;
		std::mutex mm;
		void doTime(void);
	public:
		template <typename Func, typename... Args>
		Timer(bool start, uint32_t seconds, Func fct, Args... args) :
			isStopped{false},
			isStarted{start},
			time{seconds},
			thd{[this](Func fct, Args... args) {doTime();fct(args...);}, fct, args...}
		{

		}
		template <typename Func, typename... Args>
		void restart(uint32_t seconds, Func fct, Args... args)
		{
			start();
			stop();
			time = seconds;
			isStopped = false;
			isStarted = true;
			thd = std::thread([this](Func fct, Args... args) {
					while(!isStarted);
					for (int i = 0; !isStopped && i < time; i++) {
					std::chrono::milliseconds t{1000};
					std::this_thread::sleep_for(t);
					}

					if (!isStopped) {
					fct(args...);
					std::cout << "stopped normally\n";
					} else {
					std::cout << "stopped early\n";
					}
					}, fct, args...);
		}
		~Timer(void);
		void start(void);
		void stop(void);
		void updateTime(uint32_t time);
		uint32_t timeLimit(void);
		
};

#endif //TIMER_H_INCLUDED
