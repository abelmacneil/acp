#ifndef AUDIO_H_INCLUDED
#define AUDIO_H_INCLUDED

#include "inc/fmod.hpp"
#include "inc/fmod_errors.h"
#include <stdint.h>
#include <string>

class Audio {
	private:
		Audio(void);
		Audio(Audio const&);
		void operator=(Audio const&);
		FMOD::System *system;
		FMOD_RESULT result;
		uint32_t version;
		int ndrivers;
		FMOD_SPEAKERMODE speaker_mode;
		FMOD_CAPS caps;
		char name[256];
		FMOD::Sound *audioStream;
		FMOD::Channel *channel;
		static void errorCheck(FMOD_RESULT result);
	public:
		static Audio& instance(void);
		~Audio(void);
		void load(std::string filename);
		void unload(void);
		void play(bool pause = false);
		bool isPaused(void);
		void pause(void);
		void setPause(bool pause);
		void togglePause(void);
		void setVolume(float vol);
		uint32_t getPosition(void);
		void fastForward(uint32_t timeMs);
		void rewind(uint32_t timeMs);
		void replay(void);
		void loop(void);
};
#endif /*AUDIO_H_INCLUDED*/
