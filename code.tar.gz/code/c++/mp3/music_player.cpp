#include "music_player.hpp"
#include "audio.hpp"
#include <thread>
#include <chrono>

MusicPlayer::MusicPlayer(const std::vector<std::string>& dirs):
	musicDB{dirs},
	curIndex{0},
	timer{true,0,[]{}}
{
	std::cout << "hello1";
	this->pause();
}
MusicPlayer::~MusicPlayer(void)
{
	timer.stop();
}
const MusicDB& MusicPlayer::db() const 
{
	return musicDB;
}
const TagLib::FileRef&MusicPlayer::playSong(const TagLib::FileRef& song)
{
	timer.restart(/*song.audioProperties()->length()*/ 5, [this] {playNextSong();});
	Audio::instance().load(song.file()->name());
	Audio::instance().play();
	return song;
}
void MusicPlayer::timedNextSong(int time)
{
	std::chrono::milliseconds t{time*1000};
	std::this_thread::sleep_for(t);
	playNextSong();
}
const TagLib::FileRef& MusicPlayer::currentSong(void)
{
	return musicDB[curIndex];
}

const TagLib::FileRef& MusicPlayer::playCurrentSong(void)
{
	return playSong(currentSong());
}

const TagLib::FileRef& MusicPlayer::playNextSong(void)
{
	return playSong(nextSong());
}

const TagLib::FileRef& MusicPlayer::playPreviousSong(void)
{
	return playSong(previousSong());
}

const TagLib::FileRef& MusicPlayer::playSongAt(size_t index)
{
	return playSong(setCurrentSong(index));
}

const TagLib::FileRef& MusicPlayer::nextSong(void)
{
	if (curIndex + 1 == musicDB.size())
		curIndex = 0;
	else 
		++curIndex;

	return musicDB[curIndex];
}

const TagLib::FileRef& MusicPlayer::previousSong(void)
{
	if (curIndex == 0)
		curIndex = musicDB.size() - 1;
	else 
		--curIndex;

	return musicDB[curIndex];
}

const TagLib::FileRef& MusicPlayer::setCurrentSong(size_t index)
{
	curIndex = index;
	return musicDB[index];
}
bool MusicPlayer::isPaused(void)
{
	return Audio::instance().isPaused();
}

void MusicPlayer::pause(void)
{
	Audio::instance().pause();
}

void MusicPlayer::setPause(bool pause)
{
	Audio::instance().setPause(pause);
}

void MusicPlayer::togglePause(void)
{
	Audio::instance().togglePause();
}

uint32_t MusicPlayer::getPosition(void)
{
	return Audio::instance().getPosition();
}
void MusicPlayer::fastForward(uint32_t timeMs)
{
	Audio::instance().fastForward(timeMs);
}

void MusicPlayer::rewind(uint32_t timeMs)
{
	Audio::instance().rewind(timeMs);
}

void MusicPlayer::replay(void)
{
	Audio::instance().replay();
}

void MusicPlayer::loop(void)
{
	Audio::instance().loop();
}



