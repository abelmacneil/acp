#include "timer.hpp"
#include <iostream>
Timer::~Timer(void)
{
	stop();
}
void Timer::start(void)
{
	isStarted = true;
}
void Timer::updateTime(uint32_t time)
{
	this->time = time;
}
uint32_t Timer::timeLimit(void)
{
	return time;
}
void Timer::stop(void)
{
	if (!isStopped) {
		isStarted = true;
		isStopped = true;
		thd.join();
	}
}
void Timer::doTime() {
	while(!isStarted);
	for (int i = 0; !isStopped && i < time; i++) {
		std::chrono::milliseconds t{1000};
		std::this_thread::sleep_for(t);
	}
}

