#include <iostream>
#include <cmath>
using namespace std;
bool isPrime (int n){
	if (n == 1)
		return false;

	for(int i = 2; i <= sqrt(n); i++)
		if (n % i == 0)
			return false;
	return true;
}

bool isTruncatable(int n){
	int reversed = 0;
	int n_digits = 0;
	for(int i = n; i > 0; i /= 10){
		if (!isPrime(i))
			return false;
		n_digits++;
	}
	for(int i = n_digits; i > 0; i--){
		if(!isPrime(n % (int) pow(10,i)))
			return false;
	}
	
	return true;
}


int main (void){
	int sum = 0;
	int n = 0;
	for(int i = 11; n < 11; i+=2) {
		if(isTruncatable(i)){
			n++;
			sum += i;
		}
	}
	cout << sum;
	return 0;
}
