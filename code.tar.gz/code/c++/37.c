#include <stdio.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

int isPrime (int n){
	int i;
	if (n == 1)
		return FALSE;

	for(i = 2; i <= sqrt(n); i++)
		if (n % i == 0)
			return FALSE;
	return TRUE;
}

int isTruncatable(int n){
	int reversed = 0;
	int n_digits = 0;
	int i;
	for(i = n; i > 0; i /= 10){
		if (!isPrime(i))
			return FALSE;
		n_digits++;
	}
	for(i = n_digits; i > 0; i--){
		if(!isPrime(n % (int) pow(10,i)))
			return FALSE;
	}
	
	return TRUE;
}


int main (void){
	int sum = 0;
	int n = 0,i;
	for(i = 11; n < 11; i+=2) {
		if(isTruncatable(i)){
			n++;
			sum += i;
		}
	}
	printf("%d\n", sum);
	return 0;
}
