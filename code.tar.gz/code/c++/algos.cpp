#include <iostream>
#include <cmath>
#include <cstdlib>
int *  getNLargest(int n, int len, int arr[]){
	int * largest = new int[n];
	for(int i = 0; i < n ; i++){
		largest[i] = (int) -pow(2,31);
	}
	for(int i = 0; i < len; i++){
		for(int j = 0; j < n; j++){
			if(arr[i] > largest[j]){
				for(int k = n - 1 ; k >= j ; k--){
					largest[k] = largest[k - 1];
				}		
			largest[j] = arr[i];
			break;
			}
		}
	}
	return largest;
}


int main (void){
	const int LEN = 10000;
	int * arr = new int [LEN];
	for(int i = 0 ; i < LEN; i++){
		arr[i] = rand() % 256;
	}
	int n = LEN;
	int * arr2 = getNLargest(n,LEN,arr);
//	for(int i = 0; i < LEN; i++) std::cout << arr2[i] << ", ";
	std::cout << std::endl;
}

