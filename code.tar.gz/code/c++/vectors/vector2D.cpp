#include <cmath>
#include <sstream>
#include "vector2D.hpp"

using namespace std;


double round_num(double num, int precision) {
	double r = pow(10.0, precision);
	return floor((num) * r + 0.5) / r;
}

int length(char * s) {
	int i = 0;
	while (s[i] != '\0')
		i++;
	return i;
}
vector2D::vector2D(double mag, double ang, string dir):magnitude(mag), angle(ang), direction(dir) {
	set_angle();
}

vector2D::vector2D() {
	this->magnitude = 0;
	this->angle = 0;
	this->direction = "  ";
}

void vector2D::set_angle(void) {
	if (direction.length() == 1) {
		if (direction[0] == 'E')
			this->angle = 0;
		else if (direction[0] == 'N')
			this->angle = 90;
		else if (direction[0] == 'W')
			this->angle = 180;
		else if (direction[0] == 'S')
			this->angle = 270;
	} else {
		if (direction[0] == 'E' && direction[1] == 'N')
			this->angle = angle;
		else if (direction[0] == 'N' && direction[1] == 'E')
			this->angle = 90 - angle;
		else if (direction[0] == 'N' && direction[1] == 'W')
			this->angle = 90 + angle;
		else if (direction[0] == 'W' && direction[1] == 'N')
			this->angle = 180 - angle;
		else if (direction[0] == 'W' && direction[1] == 'S')
			this->angle = 180 + angle;
		else if (direction[0] == 'S' && direction[1] == 'W')
			this->angle = 270 - angle;
		else if (direction[0] == 'S' && direction[1] == 'E')
			this->angle = 270 + angle;
		else if (direction[0] == 'E' && direction[1] == 'S')
			this->angle = 360 - angle;
	}
	this->x = magnitude * round_num(cos(this->angle * pi / 180), 10);
	this->y = magnitude * round_num(sin(this->angle * pi / 180), 10);
}

double vector2D::getx() {
	return x;
}

double vector2D::gety() {
	return y;
}

double vector2D::abs() {
	return magnitude;
}

double vector2D::getangle() {
	return angle;
}

vector2D vector2D::operator + (vector2D& v) {
	double xt = x + v.getx();
	double yt = y + v.gety();
	double m = sqrt(xt * xt + yt * yt);
	double angle = atan2(yt, xt) * 180 / pi;
	vector2D temp(m, angle, "EN");
	return temp;

}

ostream& operator<< (ostream& out, vector2D& v){
	out << v.to_string();
	return out;
}

string vector2D::to_string() {
	stringstream s;
	if (angle > 0 && angle < 90)
		s << magnitude << " [E " << angle << " N]";
	else if (angle > 90 && angle < 180)
		s << magnitude << " [W " << angle - 90 << " N]";
	else if (angle < 0 && angle > -90)
		s << magnitude << " [E " << -angle << " S]";
	else if (angle < -90 && angle > -180)
		s << magnitude << " [W " << angle + 180 << " S]";
	else if (angle == 0)
		s << magnitude << " [E]";
	else if (angle == 90)
		s << magnitude << " [N]";
	else if (angle == 180 || angle == -180)
		s << magnitude << " [W]";
	else if (angle == -90)
		s << magnitude << " [S]";
	else
		s << magnitude << " [E " << angle << " N]";
	return s.str();
}

void vector2D::print(ostream& out) {
	out << to_string();
}
