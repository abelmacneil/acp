/* 
 * File:   physics.cpp
 * Author: Abel MacNeil
 * Asks the user to input vector quantities and 
 * prints the resultant of the sum of the vectors
 *
 * Created on February 25, 2013, 6:30 PM
 */

#include <cstdlib>
#include <iostream>
#include <cmath>
#include "vector2D.hpp"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int size, i;
    if (argc == 1) {
        cout << "How many vectors are you adding? ";
        cin >> size;
    } else if (argc == 2) {
        size = atoi(argv[1]);
    }
    vector2D v[size];
    double mag, angle;
    string dir = "  ";
    for (i = 0; i < size; i++) {
		cout << "Vector " << i + 1 << endl;
        cout << "\tMagnitude: ";
        cin >> mag;
        cout << "\tDirections: ";
        cin >> dir;
        angle = 0;
        if (dir.length() != 1){
			cout << "\tAngle: ";
			cin >> angle;
	}
        v[i] = vector2D(mag, angle, dir);
    }
    vector2D sum(0, 0, "  ");
    for (i = 0; i < size; i++) {
        sum = sum + v[i];
    }
 
    cout << sum <<endl;
    return 0;
}


