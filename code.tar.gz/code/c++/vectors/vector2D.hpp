/* 
 * File:   vector2D.h
 * Author: Abel MacNeil
 *
 * The vector class accepts 2D vectors 
 * by their magnitude and direction.
 * 
 * Created on February 25, 2013, 10:26 PM
 */

#ifndef VECTOR2D_H
#define	VECTOR2D_H
#include <iostream>

using namespace std;

class vector2D {
	double magnitude;
	double angle;
	double x;
	double y;
	string direction;
	void set_angle(void);
public:
	vector2D(double, double, string);
	vector2D();
	double getx();
	double gety();
	double abs();
	double getangle();
	vector2D operator +(vector2D&);
	friend ostream& operator<< (ostream&, vector2D&);
	string to_string();
	void print(ostream&);
	static const double pi = 3.141592653589793238462643383279502884;
};

#endif	/* VECTOR2D_H */

