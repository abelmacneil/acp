#include "game.hpp"
#include "cpu.hpp"
#include <algorithm>
#include <sstream>
#include <vector>
using namespace std;
string VectorToString(vector<string> v){
	stringstream s;
	s << "[";
	for (int i = 0; i < v.size(); i++){
		s << v[i];
		if (i != v.size() - 1)
			s << ",";
	}
	s << "]";
	return s.str();
	
}
int main(){
	Game g ("hello");
	CPU cpu (g);
	string guess;
	cout << g.hidden_word();
	while (!(g.HasWon() || g.HasLost())) {
//		cin >> guess;
		cout << " ";
		guess = cpu.MakeGuess();
		
		cout << g.MakeGuess(guess);
		cout << VectorToString(g.bad_guesses());
	}
	cout << endl;
	if(g.HasLost()) {
		cout << "You lost!" << endl;
	} else {
		cout << "You won!" << endl;
	}
}
