#!/usr/bin/ruby

class String 
  def has_chars?(str)
    str.split('').sort == self.split('').sort
  end

  def words
    File.open("dict.txt").inject([]) do |a,w|
      if w.chomp.length == self.length and self.has_chars? w.chomp 
        a << w.chomp
      end
      a
    end
  end
end


puts ARGV[0].words
