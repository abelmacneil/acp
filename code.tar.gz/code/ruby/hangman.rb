#!/usr/bin/ruby
require_relative 'attr_clone'
require_relative 'stats'
class Array
  def to_h
    flatten.each_slice(2).inject({}) do |hash,vals|
      hash[vals[0]] = vals[1]
      hash
    end
  end

  def contains?(other)
    !(self & other).empty?
  end
end

module Hangman
  class Game
    attr_reader :bad_guesses, :good_guesses
    
    @@words = File.open('dict.txt').collect do |l|
      l.chomp if l.chomp[/[a-z]+/] == l.chomp
    end.compact!

    def self.words
      @@words
    end

    def self.play(pre=->g{}, input=->{gets.chomp}, output=->o{puts o})
      game = Game.new
      val = pre.call(game)
      output.call game.hidden_word
      until game.won? or game.lost?
        output.call(game.process_guess(val ? input.call(val): input.call) + 
        " : " + game.bad_guesses.inspect)
      end
      output.call game.word_to_guess
      if game.lost?
        output.call 'You lost...'
        false
      else
        output.call 'You won!!!'
        true
      end
    end

    def initialize
      @word_to_guess = @@words[(rand * @@words.size).to_i]
      @good_guesses = []
      @bad_guesses = []
    end
    
    def process_guess(guess)
      if guess.length == 1 and ('a'..'z') === guess
        (@word_to_guess.include?(guess) ? @good_guesses: @bad_guesses) << guess
      elsif guess == @word_to_guess
        @good_guesses = @word_to_guess.chars.sort 
        return @word_to_guess.each_char.inject(''){|s,c|s+c+' '}
      end
      hidden_word
    end

    def hidden_word
      @word_to_guess.each_char.inject('') do |s,c|
        s + (@good_guesses.include?(c) ? "#{c} ":'_ ')
      end
    end
    
    def won?
      hidden_word.delete(' ') == @word_to_guess
    end
    
    def lost?
      @bad_guesses.length >= 7
    end

    def word_to_guess
      @word_to_guess if won? or lost?
    end
  end

  class CPU

    def initialize(game)
      @game = game
      @word_choices = Game.words.select do |word|
        word.length == @game.hidden_word.length / 2
      end
    end

    def possible_guesses
      word_choices.inject(Hash.new(0)) do |hash,word|
        word.each_char do |ch|
          unless @game.bad_guesses.include?(ch) or 
                 @game.good_guesses.include?(ch)
            hash[ch] += 1 
          end
        end
        hash
      end.sort_by{|k,v|-v}.to_h
    end

    def word_choices
      @word_choices = @word_choices.select do |word|
        word =~ /#{@game.hidden_word.gsub('_','.').delete(' ')}/ and
        (not word.chars.sort.contains?(@game.bad_guesses.sort) or 
        @game.bad_guesses.empty?)
      end
    end

    def make_guess
      if @word_choices.length == 1
        @word_choices[0]
      else
        possible_guesses.shift[0]
      end
    end

    def self.benchmark(iterations=10)
      wins = 0
      v = iterations.times.collect do 
        pre = Time.now
        won = Hangman::Game.play \
                ->g{Hangman::CPU.new g},->c{c.make_guess},->o{o}
        t = Time.now - pre
        wins += 1 if won
        t
      end
      digits = "15.7"
      str_padding = "15"
      pattern = "%#{str_padding}s %#{digits}f\n"
      printf "%#{str_padding}s %#{digits[0..1].to_i + digits[2].to_i}d\n",
                "Iterations:", iterations
      printf pattern, "Total time(s):",  v.sum
      printf pattern, "Mean(s):",  v.mean
      printf pattern, "Stdev(s):", v.stdev
      printf pattern, "Percent Won(%):", wins/iterations.to_f * 100
    end
  end
end

args = []
if not ARGV.nil? and ARGV.size >= 1
  if ARGV[0] == 'cpu'
    args = ->g{Hangman::CPU.new g}, ->c{c.make_guess},->o{puts o}
  elsif ARGV[0] == 'time_cpu'
    Hangman::CPU.benchmark ARGV[1].to_i
    exit
  else
    fail "No such argument '#{ARGV[0]}'"
  end
end
puts Hangman::Game.play *args

