#!/usr/bin/ruby

class Numeric
  def factors
    1.upto(Math.sqrt(self)).inject([]) do |l,i|
      if self % i == 0
        l << [i, self / i]
      end
      l
    end
  end

  def pandigital_product?
    self.factors.map do |a|
      if a[1] != self
        a << self
      else
        a
      end
    end.each do |f|
      return true if f.pandigital?
    end
    false
  end
end        

module Enumerable
  def pandigital?
    inject('') do |s,n|
      s+n.to_s
    end.split('').sort.each_with_index do |c,i|
      return false if c != (i + 1).to_s
    end
    true
  end
end
n = 20
p n.pandigital_product?
#=begin
(2..12345678).each.inject(0) do |s,n|
  s += n if n.pandigital_product?
  s
end
#=end
