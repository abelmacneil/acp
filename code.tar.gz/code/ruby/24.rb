#!/usr/bin/ruby
#slow solution without any gems ~11s
puts (0..9).to_a.permutation.to_a[999999].join
#fast solution with gem ~0.2s
require 'permutation'
puts Permutation.new(10,999999).value.join
