#!/usr/bin/ruby
module Enumerable
  def sum
    inject(0) do |sum,item|
      if block_given?
        sum + yield(item)
      else
        sum + item
      end
    end
  end

  def mean
    sum / size.to_f
  end

  def stdev 
    m = mean
    Math.sqrt(inject(0) {|s,x|s +  (x - m)**2} / size.to_f)
  end
end

