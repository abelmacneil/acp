#!/usr/bin/ruby
class Parser
  def parse(expr)
    op = ''
    num1 = nil
    num2 = nil
    expr.each_char.with_index do |c,i|
      unless c.number?
        op = c
        num1 = expr[0..i-1]
        num2 = expr[i+1..-1]
        puts "#{num1} #{op} #{num2}"
      end
    end
  end
end

class String
  def number?
    self.each_char do |c|
      return false unless ('0'..'9') === c
    end
    true
  end
end
expression = '2+2'
parser = Parser.new
parser.parse expression

