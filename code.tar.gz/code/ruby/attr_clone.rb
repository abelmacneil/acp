#!/usr/bin/ruby
class Class
  def attr_reader(*names)
    names.each do |name|
      define_method(name) do
        var = instance_variable_get("@#{name}")
        begin 
          var.dup
        rescue TypeError
          var
        end
      end
    end
  end
end

