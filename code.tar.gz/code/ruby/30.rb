#!/usr/bin/ruby
p (2..9**5*7).inject(Array.new){|s,n|s<<n if(n.to_s.each_char.inject(0){|s,c|s+c.to_i**5}==n);s}.inject{|s,n|s+n}
