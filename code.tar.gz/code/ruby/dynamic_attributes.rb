#!/usr/bin/ruby
module DynamicAttributes
  def metaclass
    class << self
      self
    end
  end

  def add(name,value=nil)
    instance_variable_set("@#{name.to_sym}",value)
      metaclass.class_eval do
        attr_accessor name 
    end
  end

  def method_missing(name, *args, &block)
    @__values ||= {}
    if name[-1] == '='
      var_name = name[0..-2].intern
      metaclass.instance_exec(name) do |name|
        define_method(name) do |value|
          @__values[var_name] = value
        end
      end
      @__values[var_name] = args[0]
    else
      metaclass.instance_exec(name) do |name|
        define_method(name) do
          @__values[name]
        end
      end
      @__values[name]
    end
  end
end
module Stuff
  def add_attr(*names)
    names.each do |name|
      define_singleton_method("#{name}") do |*args|
        val, = *args
        if val != nil and instance_variable_get("@#{name}") == nil
          instance_variable_set("@#{name}",val) 
        end
        instance_variable_get("@#{name}")
      end
    end
  end
end
class MyClass
  include DynamicAttributes
  extend Stuff
  add_attr :blue,:health,:cool,:stuffs
  health 30
  cool 200
  stuffs ['one','two','three']
  def initialize
  end
end
class Two < MyClass
  health 300
end

puts Two.health
puts MyClass.cool
a = MyClass.new
b = MyClass.new
p a.var = 3
p b.var
