#!/usr/bin/ruby
s = 2
arr = (1..1001**2).inject([]) do |a,i|
  if ((i-1) % s == 0)
    a << i
  elsif (i > (s+1)**2)
    s += 2
  end
  a
end
p arr.inject(0){|s,i|s+i}
