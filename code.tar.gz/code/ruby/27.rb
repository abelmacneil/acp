#!/usr/bin/ruby
maxeq = { a: -1001, b: -1001, n: -1}
class Fixnum
  def prime?
    val = to_s.to_i
    (2..Math.sqrt(val.abs).to_i).each do |i|
      return false if val % i == 0
    end
    return true
  end
end
(-1000..1000).each do |a|
  (-1000..1000).each do |b|
    if b.prime?
      n = 0
      n += 1 while (n ** 2 + a * n + b).prime?
      if n > maxeq[:n]
        maxeq[:a] = a
        maxeq[:b] = b
        maxeq[:n] = n
      end
    end
  end
end
p maxeq
p maxeq[:a] * maxeq[:b]
