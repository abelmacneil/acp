#!/usr/bin/ruby
File.open('22.txt').each do |l| 
  puts(l.chomp.gsub('"','').split(',').sort.each_with_index.inject(0) do |s,(n,i)|
    s + (i + 1) * n.each_char.inject(0) do |ss,c|
      ss + c.ord-'A'.ord+1
    end
  end)
end
