#!/usr/bin/ruby
=begin
p(Enumerator.new do |y|
  a, b = 1, 1
  count = 1
  loop do
    y.yield a, count
    a, b = b, a + b
    count += 1
  end
end.find {|f,i| f.to_s.length == 1000}[1])
=end
p(Enumerator.new{|y|a,b,i=1,1,1;loop{y.yield a,i;a,b=b,a+b;i+=1}}.find{|f,i|f.to_s.length==1000}[1])

